CREATE TABLE APP.person (
     person_id INTEGER NOT NULL
     , user_name VARCHAR(50) NOT NULL
     , first_name VARCHAR(20)
     , last_name VARCHAR(50)
     , address1 VARCHAR(50)
     , address2 VARCHAR(50) 
     , suburb VARCHAR(50)
     , city VARCHAR(50)
     , date_of_birth DATE
     , comment TEXT INDEX_NONE
     , updater_person_id INTEGER  NOT NULL
     , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
     , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
     , PRIMARY KEY (person_id)
);

CREATE TABLE APP.role (
       role_id  INTEGER NOT NULL
     , role_code VARCHAR(10) NOT NULL
     , role VARCHAR(30) NOT NULL
     , is_default BOOLEAN DEFAULT 0 NOT NULL
     , updater_person_id INTEGER  NOT NULL
     , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
     , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
     , UNIQUE (role_code)
     , PRIMARY KEY (role_id)
);

CREATE TABLE APP.person_role (
	person_role_id INTEGER NOT NULL
	, person_id INTEGER NOT NULL
	, role_id INTEGER NOT NULL
	, updater_person_id INTEGER  NOT NULL
	, date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
	, date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
	, PRIMARY KEY (person_role_id)
);

CREATE TABLE APP.occupation (
	occupation_id INTEGER NOT NULL
	, occupation VARCHAR(50) NOT NULL
	, is_default BOOLEAN DEFAULT 0 NOT NULL
	, updater_person_id INTEGER  NOT NULL
	, date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
	, date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
	, PRIMARY KEY (occupation_id)
);

CREATE TABLE APP.title (
    title_id INTEGER NOT NULL
    , title_code VARCHAR(10) NOT NULL
    , title VARCHAR(20) NOT NULL
	, is_default BOOLEAN DEFAULT 0 NOT NULL
	, updater_person_id INTEGER  NOT NULL
    , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , PRIMARY KEY (title_id)
);

CREATE TABLE APP.contact_type (
    contact_type_id INTEGER NOT NULL
    , contact_type VARCHAR(50) NOT NULL
	, is_default BOOLEAN DEFAULT 0 NOT NULL
	, updater_person_id INTEGER  NOT NULL
    , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , PRIMARY KEY (contact_type_id)
);

CREATE TABLE APP.contact_detail (
	contact_detail_id INTEGER NOT NULL
	, client_id INTEGER NOT NULL
    , contact_type_id INTEGER NOT NULL
    , contact_detail VARCHAR(50) NOT NULL
    , comment TEXT INDEX_NONE
	, updater_person_id INTEGER  NOT NULL
    , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , PRIMARY KEY (contact_detail_id)
);

CREATE TABLE APP.insurance_company (
    insurance_company_id INTEGER NOT NULL
    , insurance_company VARCHAR(50) NOT NULL
	, is_default BOOLEAN DEFAULT 0 NOT NULL
	, updater_person_id INTEGER  NOT NULL
    , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , PRIMARY KEY (insurance_company_id)
);


CREATE TABLE APP.prescription(
    prescription_id INTEGER NOT NULL
    , client_id INTEGER NOT NULL
    , prescription VARCHAR(255) INDEX_NONE
    , comment TEXT INDEX_NONE
	, updater_person_id INTEGER  NOT NULL
    , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , PRIMARY KEY (prescription_id)
);

CREATE TABLE APP.invoice(
    invoice_id INTEGER NOT NULL
	, client_id INTEGER NOT NULL
    , invoice_date DATE NOT NULL
    , amount NUMERIC(18,4) NOT NULL
    , comment TEXT INDEX_NONE
	, updater_person_id INTEGER  NOT NULL
    , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , PRIMARY KEY (invoice_id)
);

CREATE TABLE APP.payment(
    payment_id INTEGER NOT NULL
	, invoice_id INTEGER NOT NULL
    , payment_date DATE NOT NULL
    , amount NUMERIC(18,4) NOT NULL
    , tender_id INTEGER not NULL
    , comment TEXT INDEX_NONE
	, updater_person_id INTEGER  NOT NULL
    , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , PRIMARY KEY (payment_id)
);

CREATE TABLE APP.tender(
	tender_id INTEGER not NULL
    , tender VARCHAR(20) NOT NULL
    , is_default BOOLEAN DEFAULT 0 NOT NULL
	, updater_person_id INTEGER  NOT NULL
    , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , PRIMARY KEY (tender_id)
);

CREATE TABLE APP.country(
	country_id INTEGER not NULL
    , country VARCHAR(50) NOT NULL
    , is_default BOOLEAN DEFAULT 0 NOT NULL
	, updater_person_id INTEGER  NOT NULL
    , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , PRIMARY KEY (country_id)
    , UNIQUE (country)
);

CREATE TABLE APP.client (
    client_id INTEGER NOT NULL
    , first_name VARCHAR(20) NOT NULL
    , last_name VARCHAR(30) NOT NULL
    , title_id INTEGER NOT NULL
    , occupation_id INTEGER NOT NULL
    , address1 VARCHAR(30) NOT NULL
    , address2 VARCHAR(30)
    , suburb VARCHAR(30)
    , city VARCHAR(30) NOT NULL
    , postcode VARCHAR(20)
    , country_id INTEGER DEFAULT 1 NOT NULL 
    , date_of_birth DATE
    , name_last_dentist VARCHAR(50) INDEX_NONE
    , referrer VARCHAR(50) INDEX_NONE
    , name_parent VARCHAR(30) INDEX_NONE
    , address_parent VARCHAR(50) INDEX_NONE
    , insurance_company_id INT NOT NULL
    , medical_practicioner VARCHAR(50)
    , comment TEXT INDEX_NONE
	, updater_person_id INTEGER  NOT NULL
    , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , PRIMARY KEY (client_id)
);

CREATE TABLE APP.login (
	user_name INTEGER NOT NULL
	, person_id INTEGER NOT NULL
	, login_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , logoff_date TIMESTAMP
    , PRIMARY KEY (user_name)
);

CREATE TABLE APP.parameter (
    parameter_id INTEGER NOT NULL
    , parameter_key VARCHAR(50) NOT NULL
    , parameter VARCHAR(255) NOT NULL
    , comment VARCHAR(255) INDEX_NONE
	, updater_person_id INTEGER  NOT NULL
    , date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
    , PRIMARY KEY (parameter_id)
    , UNIQUE (parameter_key)
);

