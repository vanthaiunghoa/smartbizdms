insert into APP.insurance_company 
    set insurance_company_id=2
    , insurance_company='State Insurance'
    , updater_person_id=1
;

insert into APP.insurance_company 
	set insurance_company_id=3
    , insurance_company='AMI'
    , updater_person_id=1
;

insert into APP.insurance_company 
	set insurance_company_id=4
    , insurance_company='AMP'
    , updater_person_id=1
;

insert into APP.occupation
	set occupation_id=2
	, occupation='Craftsman'
	, updater_person_id=1
	;

insert into APP.occupation 
	set occupation_id=3
	, occupation='Medical Practitioner'
	, updater_person_id=1
	;

insert into APP.occupation 
	set occupation_id=4
	, occupation='Lawyer'
	, updater_person_id=1
	;

insert into APP.occupation 
	set occupation_id=5
	, occupation='Dentist'
	, updater_person_id=1
	;

insert into APP.person
     set person_id=1
     , user_name='admin'
     , updater_person_id=1
;

insert into APP.person_role
	set person_role_id=uniquekey('APP.person_role')
	, person_id=1
	, role_id=1
    , updater_person_id=1
	;

insert into APP.person_role
	set person_role_id=uniquekey('APP.person_role')
	, person_id=1
	, role_id=2
    , updater_person_id=1
	;

delete from APP.client;
insert into APP.client
    set client_id=1
    , first_name='Joe'
    , last_name='Smith'
    , title_id=1
    , occupation_id=1
    , address1='10 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=2
    , first_name='Jane'
    , last_name='Smith'
    , title_id=2
    , occupation_id=3
    , address1='10 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

delete from APP.client;
insert into APP.client
    set client_id=1
    , first_name='Joe'
    , last_name='Smith'
    , title_id=1
    , occupation_id=1
    , address1='10 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , postcode='6008'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=2
    , first_name='Jane'
    , last_name='Smith'
    , title_id=2
    , occupation_id=3
    , address1='10 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , postcode='6008'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=3
    , first_name='John'
    , last_name='Adams3'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=4
    , first_name='John'
    , last_name='Adams4'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=5
    , first_name='John'
    , last_name='Adams5'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=6
    , first_name='John'
    , last_name='Adams6'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=7
    , first_name='John'
    , last_name='Adams7'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=8
    , first_name='John'
    , last_name='Adams8'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=9
    , first_name='John'
    , last_name='Adams9'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=10
    , first_name='John'
    , last_name='Adams10'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=11
    , first_name='John'
    , last_name='Bear11'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=12
    , first_name='John'
    , last_name='Bear12'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=13
    , first_name='John'
    , last_name='Bear13'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=14
    , first_name='John'
    , last_name='Bear14'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=15
    , first_name='John'
    , last_name='Bear15'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=21
    , first_name='John'
    , last_name='Davids21'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=22
    , first_name='John'
    , last_name='Davids22'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=23
    , first_name='John'
    , last_name='Davids23'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=24
    , first_name='John'
    , last_name='Davids24'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=25
    , first_name='John'
    , last_name='Davids25'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=31
    , first_name='John'
    , last_name='Edwards31'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=32
    , first_name='John'
    , last_name='Edwards32'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=33
    , first_name='John'
    , last_name='Edwards33'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;

insert into APP.client
    set client_id=34
    , first_name='John'
    , last_name='Edwards34'
    , title_id=2
    , occupation_id=4
    , address1='3 Local Road'
    , address2=null
    , suburb='Stokes Valley'
    , city='Wellington'
    , date_of_birth='1980-01-30'
    , name_last_dentist='Last Dentist'
    , referrer='Name referrer'
    , name_parent='Name Parent'
    , address_parent='Address Parent'
    , insurance_company_id=1
    , medical_practicioner='Dr Wong'
    , comment='Some comment'
    , updater_person_id=3
;


insert into APP.contact_detail
	set contact_detail_id=uniquekey('APP.contact_detail')
	, client_id=3
	, contact_type_id=1
	, contact_detail='04-563 1111'
	, updater_person_id=3
;

insert into APP.contact_detail
	set contact_detail_id=uniquekey('APP.contact_detail')
	, client_id=4
	, contact_type_id=1
	, contact_detail='04-563 2222'
	, updater_person_id=3
;

insert into APP.contact_detail
	set contact_detail_id=uniquekey('APP.contact_detail')
	, client_id=4
	, contact_type_id=5
	, contact_detail='me@transparent.co.nz'
	, updater_person_id=3
;

insert into APP.contact_detail
	set contact_detail_id=uniquekey('APP.contact_detail')
	, client_id=1
    , contact_type_id=1
    , contact_detail='04-563 1234'
    , updater_person_id=3
;

insert into APP.contact_detail
	set contact_detail_id=uniquekey('APP.contact_detail')
	, client_id=1
    , contact_type_id=2
    , contact_detail='04-563 4321'
    , updater_person_id=3
;

insert into APP.contact_detail
	set contact_detail_id=uniquekey('APP.contact_detail')
	, client_id=1
    , contact_type_id=3
    , contact_detail='04-563 0001'
    , updater_person_id=3
;

insert into APP.contact_detail
	set contact_detail_id=uniquekey('APP.contact_detail')
	, client_id=1
    , contact_type_id=4
    , contact_detail='04-563 0002'
    , updater_person_id=3
;

insert into APP.contact_detail
	set contact_detail_id=uniquekey('APP.contact_detail')
	, client_id=1
    , contact_type_id=5
    , contact_detail='me@home.com'
    , updater_person_id=3
;

insert into APP.contact_detail
	set contact_detail_id=uniquekey('APP.contact_detail')
	, client_id=1
    , contact_type_id=6
    , contact_detail='me@work.com'
    , updater_person_id=3
;

delete from APP.prescription;
insert into APP.prescription
    set prescription_id=uniquekey('APP.prescription')
    , client_id=1
    , prescription='This is prescription 1'
    , updater_person_id=3
;

insert into APP.prescription
    set prescription_id=uniquekey('APP.prescription')
    , client_id=1
    , prescription='This is prescription 2'
    , updater_person_id=3
;

insert into APP.prescription
    set prescription_id=uniquekey('APP.prescription')
    , client_id=2
    , prescription='This is prescription 1'
    , updater_person_id=3
;

insert into APP.prescription
    set prescription_id=uniquekey('APP.prescription')
    , client_id=2
    , prescription='This is prescription 2'
    , updater_person_id=3
;

delete from APP.invoice;
insert into APP.invoice set
    invoice_id=1
	, client_id=1
    , amount=80.11
    , invoice_date='2003-08-01'
    , updater_person_id=3
;

insert into APP.invoice set
    invoice_id=2
	, client_id=1
    , amount=60.12
    , invoice_date='2003-08-02'
    , updater_person_id=3
;

insert into APP.invoice set
    invoice_id=3
	, client_id=1
    , amount=50
    , invoice_date='2003-08-03'
    , updater_person_id=3
;

delete from APP.payment;
insert into APP.payment set
    payment_id=1
	, invoice_id=1
    , payment_date='2003-09-01'
    , amount=80.11
    , tender_id=1
    , updater_person_id=3
;

insert into APP.payment set
    payment_id=2
	,  invoice_id=2
    , payment_date='2003-09-01'
    , amount=30
    , tender_id=1
    , updater_person_id=3
;

insert into APP.payment set
    payment_id=3
	,  invoice_id=2
    , payment_date='2003-09-02'
    , amount=20
    , tender_id=1
    , updater_person_id=3
;

