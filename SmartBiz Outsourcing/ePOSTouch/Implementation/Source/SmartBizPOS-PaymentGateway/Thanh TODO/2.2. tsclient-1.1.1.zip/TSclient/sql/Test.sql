ALTER TABLE contact_detail ADD CONSTRAINT fk_contact_detail_client_id 
FOREIGN KEY (client_id) REFERENCES client (client_id)
ON UPDATE cascade
ON DELETE cascade;

ALTER TABLE invoice ADD CONSTRAINT fk_invoice_client_id 
FOREIGN KEY (client_id) REFERENCES client (client_id)
ON UPDATE cascade
ON DELETE cascade;
