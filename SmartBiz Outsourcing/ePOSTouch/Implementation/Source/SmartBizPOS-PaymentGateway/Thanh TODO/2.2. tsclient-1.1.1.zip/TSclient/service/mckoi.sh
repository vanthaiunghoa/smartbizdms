#!/bin/sh
#
# mckoi      This shell script takes care of starting and stopping mckoi daemon.
#
# author: John Zoetebier http://www.transparent.co.nz
# chkconfig: 35 99 1
# description: startup script for Mckoi database server
# There are different methods to load a script in the appropriate init levels used during system boot
# Mandrake uses script chkconfig
# SuSE uses script insserv

# INIT INFO is used by script insserv to
### BEGIN INIT INFO
# Provides:       mckoi
# Required-Start: $network $remote_fs
# Required-Stop:
# Default-Start:  3 5
# Default-Stop:
# Description:    Starts and stops the mckoi server
### END INIT INFO

# Set variables : BEGIN
# Change settings according to your environment
mckoi_userid=admin
mckoi_password=client00
mckoi_server=localhost
mckoi_port=9157
tsclient_home=/opt/tsclient-1.0.1/client
mckoi_conf_db=${tsclient_home}/resource/db.conf
java_home=/usr/java/j2sdk1.4.2
java=/usr/java/j2sdk1.4.2/jre/bin/java
# Set variables : BEGIN

# See how we are called.
case "$1" in
  start)
	# Start daemon.
	echo "Starting mckoi:"
	echo ${java} -jar ${tsclient_home}/lib/mckoidb.jar -conf ${mckoi_conf_db}
	${java} -jar ${tsclient_home}/lib/mckoidb.jar -conf ${mckoi_conf_db} &
	echo
	;;
  stop)
	# Stop daemons.
	echo -n "Shutting down mckoi: "
	#kill `ps -aef | awk '/[ \/]mckoi/ { print $2}'`
	${java} -jar ${tsclient_home}/lib/mckoidb.jar -shutdown ${mckoi_server} ${mckoi_port} ${mckoi_userid} ${mckoi_password} &
	echo
	;;
  restart)
	$0 stop
	$0 start
	;;
  status)
	pids=`ps -aef | awk '/[ \/]mckoi/ { print $2}'`
	if test "$pids"
	then
		for p in $pids
		do
			echo "mckoi (pid $p) is running"
		done
	else
		echo "mckoi is stopped"
	fi
	;;
  *)
	echo "Usage: mckoi {start|stop|restart|status}"
	exit 1
esac

exit 0
