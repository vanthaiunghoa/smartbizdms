delete from APP.role;
insert into APP.role
       set role_id=1
     , role_code='admin'
     , role='System administrator'
     , updater_person_id=1
;

insert into APP.role
       set role_id=2
     , role_code='operator'
     , role='Operator'
     , is_default=1
     , updater_person_id=1
;

delete from APP.title;
insert into APP.title 
	set title_id=1
    , title_code='Mr'
    , title='Mister'
	, is_default=1
    , updater_person_id=1
;

insert into APP.title
    set title_id=2
    , title_code='Mrs'
    , title='Misses'
    , updater_person_id=1
;

insert into APP.title
    set title_id=3
    , title_code='Dr'
    , title='Doctor'
    , updater_person_id=1
;

insert into APP.title
    set title_id=4
    , title_code='Ph D'
    , title='Philosophical Doctor'
    , updater_person_id=1
;

delete from APP.contact_type;
insert into APP.contact_type 
	set contact_type_id=1
    , contact_type='phone/home'
	, is_default=1
    , updater_person_id=1
;

insert into APP.contact_type
    set contact_type_id=2
    , contact_type='phone/work'
    , updater_person_id=1
;

insert into APP.contact_type
    set contact_type_id=3
    , contact_type='fax/home'
    , updater_person_id=1
;

insert into APP.contact_type
    set contact_type_id=4
    , contact_type='fax/work'
    , updater_person_id=1
;

insert into APP.contact_type
    set contact_type_id=5
    , contact_type='email/home'
    , updater_person_id=1
;

insert into APP.contact_type
    set contact_type_id=6
    , contact_type='email/work'
    , updater_person_id=1
;

delete from APP.tender;
insert into APP.tender 
	set tender_id=1
    , tender='EFTPOS'
    , is_default=1
    , updater_person_id=1
;

insert into APP.tender 
	set tender_id=2
    , tender='Charge'
    , is_default=0
    , updater_person_id=1
;

insert into APP.tender 
	set tender_id=3
    , tender='Cheque'
    , is_default=0
    , updater_person_id=1
;

insert into APP.tender 
	set tender_id=4
    , tender='VISA'
    , is_default=0
    , updater_person_id=1
;

insert into APP.tender 
	set tender_id=5
    , tender='Mastercard'
    , is_default=0
    , updater_person_id=1
;

insert into APP.tender 
	set tender_id=6
    , tender='American Express'
    , is_default=0
    , updater_person_id=1
;

insert into APP.tender 
	set tender_id=7
    , tender='Cash'
    , is_default=0
    , updater_person_id=1
;

insert into APP.country 
	set country_id=1
    , country='New Zealand'
    , is_default=1
    , updater_person_id=1
;

insert into APP.country 
	set country_id=2
    , country='Australia'
    , is_default=0
    , updater_person_id=1
;

insert into APP.country 
	set country_id=3
    , country='USA'
    , is_default=0
    , updater_person_id=1
;

insert into APP.country 
	set country_id=4
    , country='Canada'
    , is_default=0
    , updater_person_id=1
;

insert into APP.country 
	set country_id=5
    , country='United Kingdom'
    , is_default=0
    , updater_person_id=1
;

insert into APP.country 
	set country_id=6
    , country='The Netherlands'
    , is_default=0
    , updater_person_id=1
;

insert into APP.country 
	set country_id=7
    , country='Germany'
    , is_default=0
    , updater_person_id=1
;

insert into APP.country 
	set country_id=8
    , country='France'
    , is_default=0
    , updater_person_id=1
;

insert into APP.country 
	set country_id=9
    , country='Japan'
    , is_default=0
    , updater_person_id=1
;

insert into APP.country 
	set country_id=10
    , country='China'
    , is_default=0
    , updater_person_id=1
;

insert into APP.occupation 
	set occupation_id=1
    , occupation='Unknown'
    , is_default=1
    , updater_person_id=1
;

insert into APP.insurance_company 
	set insurance_company_id=1
    , insurance_company='Unknown'
    , is_default=1
    , updater_person_id=1
;

insert into APP.parameter
	set parameter_id=1
    , parameter_key='max.records.search'
    , parameter='30'
    , comment='Maximum number of records in search results'
    , updater_person_id=1
;

insert into APP.parameter
	set parameter_id=2
    , parameter_key='format.shortdate'
    , parameter='dd/MM/yyyy'
    , comment='date in short date format'
    , updater_person_id=1
;

insert into APP.parameter
	set parameter_id=3
    , parameter_key='format.timestamp'
    , parameter='yyyy-MM-dd HH:mm:ss.S z'
    , comment='date of timestamp on forms'
    , updater_person_id=1
;

grant ALL on client to PUBLIC;
grant ALL on contact_detail to PUBLIC;
grant ALL on contact_type to PUBLIC;
grant ALL on country to PUBLIC;
grant ALL on insurance_company to PUBLIC;
grant ALL on invoice to PUBLIC;
grant ALL on login to PUBLIC;
grant ALL on occupation to PUBLIC;
grant ALL on parameter to PUBLIC;
grant ALL on payment to PUBLIC;
grant SELECT on person to PUBLIC;
grant ALL on person_role to PUBLIC;
grant ALL on prescription to PUBLIC;
grant ALL on role to PUBLIC;
grant ALL on tender to PUBLIC;
grant ALL on title to PUBLIC;

