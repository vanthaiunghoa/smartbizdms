ALTER TABLE contact_detail ADD CONSTRAINT fk_contact_detail_client_id 
FOREIGN KEY (client_id) REFERENCES client (client_id)
ON UPDATE cascade
ON DELETE cascade;

ALTER TABLE invoice ADD CONSTRAINT fk_invoice_client_id 
FOREIGN KEY (client_id) REFERENCES client (client_id)
ON UPDATE cascade
ON DELETE cascade;

ALTER TABLE payment ADD CONSTRAINT fk_payment_invoice_id 
FOREIGN KEY (invoice_id) REFERENCES invoice (invoice_id)
ON UPDATE cascade
ON DELETE cascade;

ALTER TABLE prescription ADD CONSTRAINT fk_prescription_client_id 
FOREIGN KEY (client_id) REFERENCES client (client_id)
ON UPDATE cascade
ON DELETE cascade;

ALTER TABLE login ADD CONSTRAINT fk_login_person_id 
FOREIGN KEY (person_id) REFERENCES person (person_id)
ON UPDATE cascade
ON DELETE cascade;

ALTER TABLE person_role ADD CONSTRAINT fk_person_role_person_id 
FOREIGN KEY (person_id) REFERENCES person (person_id)
ON UPDATE cascade
ON DELETE cascade;

ALTER TABLE client ADD CONSTRAINT fk_client_country_id
FOREIGN KEY (country_id) REFERENCES country (country_id);

ALTER TABLE client ADD CONSTRAINT fk_client_title_id
FOREIGN KEY (title_id) REFERENCES title (title_id);

ALTER TABLE client ADD CONSTRAINT fk_client_occupation_id
FOREIGN KEY (occupation_id) REFERENCES occupation (occupation_id);

ALTER TABLE client ADD CONSTRAINT fk_client_insurance_company_id
FOREIGN KEY (insurance_company_id) REFERENCES insurance_company (insurance_company_id);

ALTER TABLE contact_detail ADD CONSTRAINT fk_contact_detail_contact_type_id
FOREIGN KEY (contact_type_id) REFERENCES contact_type (contact_type_id);

ALTER TABLE payment ADD CONSTRAINT fk_payment_tender_id
FOREIGN KEY (tender_id) REFERENCES tender (tender_id);

ALTER TABLE person_role ADD CONSTRAINT fk_person_role_role_id 
FOREIGN KEY (role_id) REFERENCES role (role_id);

