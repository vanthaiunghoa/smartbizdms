/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Jan 20, 2004
 *
 */
package nz.co.transparent.client.util;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import nz.co.transparent.client.controller.GenericController;
import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.DataSourceHandler;
import nz.co.transparent.client.db.FinderException;
import nz.co.transparent.client.db.UpdaterException;

/**
 * @author John Zoetebier
 * 
 */
public class Parameter {

	private static Logger log = Logger.getLogger("util");
	private static Map parameterMap = new HashMap();
	
	/**
	 * 
	 */
	private Parameter() {
		super();
	}

	public static String getParameter(String parameterKey, String defaultValue) {

		if (parameterMap.containsKey(parameterKey)) {
			return parameterMap.get(parameterKey).toString();
		}
		
		try {
			Map parameterMapTemp = GenericController.getInstance().findWhere("parameter", "parameter_key='" + parameterKey + "'");
			parameterMap.put(parameterKey, parameterMapTemp.get("parameter"));
			return parameterMapTemp.get("parameter").toString();
		} catch (FinderException fe) {
			return defaultValue;
		} catch (ControllerException fe) {
			String msg = "Parameter: error getting parameter " + parameterKey;
			log.warning(msg);
			Messager.exception(null, msg);
			return defaultValue;
		}
	}
	
	public static boolean setParameter(String parameterKey, String parameterValue) {
		
		// Store in cache
		parameterMap.put(parameterKey, parameterValue);

		// Save parameter to table
		GenericController genericController = GenericController.getInstance();
		
		try {
			Map parameterMap = genericController.findWhere("parameter", "parameter_key='" + parameterKey + "'");
			parameterMap.put("parameter", parameterValue);
			genericController.updateRecord("parameter", "parameter_id", parameterMap);
			return true;
		} catch (FinderException fe) {
			return false;
		} catch (UpdaterException ue) {
			return false;
		} catch (ControllerException fe) {
			String msg = "Parameter: error getting parameter " + parameterKey;
			log.warning(msg);
			Messager.exception(null, msg);
			return false;
		}
	}

	/**
	 * Cache all parameters
	 *
	 */
	public static void loadParameters() {

			QueryRunner queryRunner = new QueryRunner(DataSourceHandler.getDataSource());
			ResultSetHandler rsh = new MapListHandler();
			String sql = "select * from parameter";
			
			try {
				parameterMap = (Map) queryRunner.query(sql, rsh);
			} catch (SQLException se) {
				String msg = "Parameter: error loading parameters.\n" + se.getMessage();
				log.warning(msg);
				Messager.exception(null, msg);
				return;
			}
	}
}