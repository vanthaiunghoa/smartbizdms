/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 *
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

 /*
  * ParameterSearch.java
  *
  * Created on Januari 17, 2004
  */

package nz.co.transparent.client.gui;

import nz.co.transparent.client.gui.util.DialogLayout;

import java.awt.Dimension;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import javax.swing.*;
import nz.co.transparent.client.gui.util.InternalFrameOpenedAdapter;

/**
 *
 * @author John Zoetebier
 *
 */
public class ParameterSearchForm extends javax.swing.JInternalFrame {
    
    private static final int FIELD_LENGTH =20;
    
    private Logger log = Logger.getLogger("nz.co.transparent.client.gui");
    private JLabel parameterCodeLabel = new JLabel("Parameter key:");
    private JLabel parameterLabel = new JLabel("Parameter:");
    private JPanel contentPane = new JPanel();
    private JPanel middlePanel = new JPanel();
    private JPanel dialogPanel = new JPanel();
    private JTextField parameterCodeText = new JTextField();
    private JTextField parameterText = new JTextField();
    private JButton parameterSearchButton = new JButton();
    private JToolBar mainToolBar = new JToolBar();
    private ParameterTableForm parameterTableForm;
    private Map searchMap;
    // End of variables declaration
    
    /** Creates new form ParameterSearch */
    public ParameterSearchForm() {
        setName("Parameter search");
        setTitle("Parameter search");
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        setPreferredSize(new java.awt.Dimension(600, 500));
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
        setContentPane(contentPane);
        try {
            setSelected(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        //setVisible(true);
        addInternalFrameListener(new InternalFrameOpenedAdapter(this, parameterCodeText));
        
        parameterSearchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Find24.gif")));
        parameterSearchButton.setMnemonic(KeyEvent.VK_E);
        parameterSearchButton.setToolTipText("Enter one or more of the search fields. Then click me.");
        parameterSearchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                parameterSearchButton_actionPerformed();
            }
        });
        
        mainToolBar.setBorder(BorderFactory.createEtchedBorder());
        mainToolBar.setFloatable(false);
        mainToolBar.add(Box.createRigidArea(new Dimension(5,0)));
        mainToolBar.add(parameterSearchButton);
        
        mainToolBar.add(Box.createHorizontalGlue());	// make buttons left aligned
        contentPane.add(mainToolBar);
        
        dialogPanel.setLayout(new DialogLayout());
        dialogPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        
        dialogPanel.add(parameterCodeLabel);
        parameterCodeText.setColumns(FIELD_LENGTH);
        parameterCodeText.setText("");
        parameterCodeText.setToolTipText("Parameter key or part of it.");
        parameterCodeText.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    parameterSearchButton.doClick();
                }
            }
        });
        dialogPanel.add(parameterCodeText);
        
        dialogPanel.add(parameterLabel);
        parameterText.setText("");
        parameterText.setColumns(FIELD_LENGTH);
        parameterText.setToolTipText("parameter or part of it.");
        parameterText.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    parameterSearchButton.doClick();
                }
            }
        });
        dialogPanel.add(parameterText);
        
        middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.X_AXIS));
        middlePanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(20, 5, 20, 5)));
        middlePanel.add(dialogPanel);
        middlePanel.add(Box.createHorizontalStrut(700));
        
        contentPane.add(middlePanel);
        
        //===========================================
        // Create parameter table form
        //===========================================
        parameterTableForm = new ParameterTableForm();
        contentPane.add(parameterTableForm);
        
        //===========================================
        // Pack
        //===========================================
        pack();
    }
    
    private void parameterSearchButton_actionPerformed() {
        searchMap = new HashMap();
        searchMap.put("parameter_key", parameterCodeText.getText());
        searchMap.put("parameter", parameterText.getText());
        parameterTableForm.updateTable(searchMap);
    }
}