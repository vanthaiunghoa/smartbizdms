/*
 * Created on Jan 26, 2004
 *  
 */
package test;

import nz.co.transparent.client.gui.util.PasswordOnlyDialog;

/**
 * @author John Zoetebier
 *  
 */
public class TestPasswordOnlyDialog {

	/**
	 *  
	 */
	public TestPasswordOnlyDialog() {
		super();
	}

	public static void main(String[] args) {

		PasswordOnlyDialog p = new PasswordOnlyDialog(null, "Test");
		System.out.println("Pass: " + p.showDialog());
		//p.dispose();
		p = null;
		System.exit(0);
	}
}
