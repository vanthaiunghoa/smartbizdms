/*
 * Created on Dec 13, 2003
 *
 */
package test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.commons.dbutils.DbUtils;

import nz.co.transparent.client.controller.GenericTransactionController;
import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.DataSourceHandler;
import nz.co.transparent.client.db.FinderException;
import nz.co.transparent.client.db.UpdaterException;

/**
 * @author johnz
 * 
 */
public class TestGenericTransactionController {

	private static Connection conn;
	
	/**
	 * 
	 */
	public TestGenericTransactionController() {
		super();
	}
	
	public void findWhere() {
		
		Map columnMap = null;
		try {
			Connection conn = DataSourceHandler.getDataSource().getConnection();
			GenericTransactionController controller = new GenericTransactionController(conn);
			columnMap = controller.findWhere("title", "title_code = 'Mrs'");
			DbUtils.close(conn);
		} catch (FinderException ce) {
			System.out.println(ce.getMessage());
			return;
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}

		Set columnSet = columnMap.keySet();
		Iterator mapIterator = columnSet.iterator();
		String columnName = null;
		 while (mapIterator.hasNext()) {
			columnName = (String) mapIterator.next();
			System.out.println(columnName + "=" + columnMap.get(columnName));
		 }
		
		System.out.println("==> Ready");
	}

	public void insertRecord() {
		
		Map columnMap = new HashMap();
		columnMap.put("title_id", null);	// Force to generate a unique key
		columnMap.put("title_code", "B");
		columnMap.put("title", "Test title for B");
		columnMap.put("date_created", null);
		columnMap.put("date_updated", null);
		columnMap.put("updater_person_id", new Integer(3));
		
		try {
			Connection conn = DataSourceHandler.getDataSource().getConnection();
			GenericTransactionController controller = new GenericTransactionController(conn);
			if (controller.insertRecord("title", "title_id", columnMap) == 0) {
				conn.rollback();
			} else {
				conn.commit();
			}
			DbUtils.close(conn);
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}

		System.out.println("==> Ready");
	}

	public void insertRecord2() {
		
		Map columnMap = new HashMap();
		columnMap.put("role_code", "A");
		columnMap.put("role", "Test title for A");
		columnMap.put("date_created", null);
		columnMap.put("date_updated", null);
		columnMap.put("updater_person_id", new Integer(3));
		
		try {
			Connection conn = DataSourceHandler.getDataSource().getConnection();
			GenericTransactionController controller = new GenericTransactionController(conn);
			int result = controller.insertRecord("role", "role_code", columnMap);
			System.out.println("Number of records affected = " + result);
			conn.commit();
			DbUtils.close(conn);
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			try {
				conn.rollback();
			} catch (SQLException se) {
				System.out.println(ce.getMessage());
			}
			return;
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}

		System.out.println("==> Ready");
	}

	public void updateRecord() {
		
		try {
			Connection conn = DataSourceHandler.getDataSource().getConnection();
			GenericTransactionController controller = new GenericTransactionController(conn);
			Map columnMap = controller.findWhere("role", "role_code='A'");
			columnMap.put("role", "Test title is changed");
//			columnMap.put("role_code", "B");
//			columnMap.put("date_created", new Date());
//			columnMap.put("date_updated", new Date());
//			columnMap.put("updater_person_id", new Integer(3));
			
			controller.updateRecord("role", "role_code", columnMap);
			conn.commit();
			DbUtils.close(conn);
		} catch (FinderException ce) {
			System.out.println("FinderException: " + ce.getMessage());
			return;
		} catch (UpdaterException ce) {
			try {
				conn.rollback();
			} catch (SQLException se) {
				System.out.println(ce.getMessage());
			}
			System.out.println("UpdaterException: " + ce.getMessage());
			return;
		} catch (ControllerException ce) {
			try {
				conn.rollback();
			} catch (SQLException se) {
				System.out.println(ce.getMessage());
			}
			System.out.println(ce.getMessage());
			return;
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}

		System.out.println("==> updateRecord ready ");
	}

	public void deleteRecord() {
		
		try {
			Connection conn = DataSourceHandler.getDataSource().getConnection();
			GenericTransactionController controller = new GenericTransactionController(conn);

			int result = controller.deleteRecord("role", "role_code='A'");
			System.out.println("Number of records affected = " + result);
			conn.commit();
			
			DbUtils.close(conn);
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}

		System.out.println("==> deleteRecord ready ");
	}

	public static void main(String[] args) {
		//new TestGenericTransactionController().findWhere();
		//new TestGenericTransactionController().insertRecord2();
		//new TestGenericTransactionController().updateRecord();
		new TestGenericTransactionController().deleteRecord();
	}
}
