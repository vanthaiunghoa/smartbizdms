/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 *
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

 /*
  * Created on Dec 1, 2003
  *
  * To change the template for this generated file go to
  * Window - Preferences - Java - Code Generation - Code and Comments
  */
package nz.co.transparent.client.gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.logging.Logger;

import nz.co.transparent.client.gui.util.DialogLayout;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;

import nz.co.transparent.client.controller.LoginController;

import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.FinderException;

import nz.co.transparent.client.util.Configuration;
import nz.co.transparent.client.util.Messager;

/**
 * @author johnz
 *
 */
public class PersonLoginForm {
    
    // Instance variables
    private Logger log = Logger.getLogger("nz.co.transparent.client.gui");
    private int loginTries = 0;
    
    private JTextField userNameField = new JTextField("");
    private JPasswordField passwordField = new JPasswordField("");
    
    private JDialog dialog = new JDialog();
    
    /**
     *
     */
    public PersonLoginForm() {
        
        try {
            //UIManager.setLookAndFeel("com.jgoodies.plaf.plastic.PlasticLookAndFeel");
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.out.println(e.getMessage());
            log.warning(e.getMessage());
        }
        
        // Setup form
        dialog.setTitle("TS Client login: " +  Configuration.getProperty("server.mode", "<unknown>"));
        //dialog.setDefaultCloseOperation(JDialog.EXIT_ON_CLOSE);
        Container content = dialog.getContentPane();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.add(Box.createRigidArea(new Dimension(0,10)));
        JPanel panel = new JPanel(new DialogLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JLabel userNameLabel = new JLabel("User name:");
        panel.add(userNameLabel);
        userNameField.setColumns(10);
        
        // For TESTING purposes configuration file can have login.username and login.password
        userNameField.setText(Configuration.getProperty("login.username", ""));
        passwordField.setText(Configuration.getProperty("login.password", ""));
        
        panel.add(userNameField);
        userNameField.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    userNameField.transferFocus();
                }
            }
        });
        
        JLabel passwordLabel = new JLabel("Password:");
        panel.add(passwordLabel);
        passwordField.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    submitButton_actionPerformed();
                }
            }
        });
        panel.add(passwordField);
        content.add(panel);
        content.add(Box.createRigidArea(new Dimension(0,10)));
        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                submitButton_actionPerformed();
            }
        });
        
        content.add(submitButton);
        content.add(Box.createRigidArea(new Dimension(0,10)));
        
        dialog.setResizable(false);
        dialog.setSize(300,170);
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screen = toolkit.getScreenSize();
        int x = (screen.width - dialog.getWidth()) /2;
        int y = (screen.height - dialog.getHeight()) /2;
        dialog.setLocation(x, y);
        dialog.show();
    }
    
    private void submitButton_actionPerformed() {
        
        String message = "Combination LoginID and password not correct.\n" +
        "Please check Caps Lock.";
        
        if (Configuration.getProperty("server.mode", "<unknown>").equalsIgnoreCase("server")) {
            message += "\nPlease check if database server is running";
        }
        
        if (loginTries++ > 3) {
            Messager.information(dialog, message);
            return;
        }
        
        try {
            char [] passwordChar = this.passwordField.getPassword();
            String password = new String(passwordChar);
            LoginController.loginPerson(userNameField.getText(), password);
            dialog.dispose();
            MainFrame.getInstance().go();
        } catch (FinderException fe) {
            Messager.warning(dialog, message);
            return;
        } catch (ControllerException ce) {
            message = "Controller exception: " + ce.getMessage();
            log.warning(message);
            Messager.exception(dialog, message);
            return;
        } catch (Exception e) {
            message = e.getMessage();
            log.warning(message);
            Messager.exception(dialog, message);
            return;
        }
    }
    
    public static void main(String [] args) {
        new PersonLoginForm();
    }
}