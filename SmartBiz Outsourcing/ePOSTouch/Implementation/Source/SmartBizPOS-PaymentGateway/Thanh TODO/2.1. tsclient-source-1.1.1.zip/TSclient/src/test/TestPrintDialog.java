/*
 * Created on Jan 17, 2004
 *  
 */
package test;

import java.io.File;
import java.util.Locale;

import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.HashPrintServiceAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.PrintServiceAttributeSet;
import javax.print.attribute.standard.MediaSizeName;
import javax.print.attribute.standard.OrientationRequested;
import javax.print.attribute.standard.PrinterName;

import nz.co.transparent.client.util.Configuration;

import dori.jasper.engine.JREmptyDataSource;
import dori.jasper.engine.JRException;
import dori.jasper.engine.JRExporterParameter;
import dori.jasper.engine.JasperFillManager;
import dori.jasper.engine.JasperPrint;
import dori.jasper.engine.export.JRPrintServiceExporter;
import dori.jasper.engine.export.JRPrintServiceExporterParameter;
import dori.jasper.view.JasperViewer;

/**
 * @author John Zoetebier
 *  
 */
public class TestPrintDialog {

	/**
	 *  
	 */
	public TestPrintDialog() {
		super();
	}

	public void go() {
		// Check if jasper report is present
		// .jasper file can be created with iReports from xml report file 
		// or java program using JasperCompileManager.compileReportToFile(fileName)
		String fileSeparator = System.getProperty("file.separator");
		String jasperFileName =
			Configuration.getProperty("client.dir", "")
				+ fileSeparator
				+ "resource"
				+ fileSeparator
				+ "EnvelopReport.jasper";
		File jasperFile = new File(jasperFileName);
		String msg = null;

		if (!jasperFile.exists()) {
			msg = "Cannot find jasper file: " + jasperFileName;
			System.out.println(msg);
			return;
		}

		JasperPrint jasperPrint = null;
		try {
			jasperPrint =
				JasperFillManager.fillReport(
					jasperFileName,
					null,
					new JREmptyDataSource());
		} catch (JRException je) {
			System.out.println(
				"Error printing report:\n" + je.getMessage());
			return;
		}

		// For print attributes see API docs: j2sdk-1_4_2/docs/api/index.html
		PrintRequestAttributeSet printRequestAttributeSet =
			new HashPrintRequestAttributeSet();
		printRequestAttributeSet.add(OrientationRequested.LANDSCAPE);
//		printRequestAttributeSet.add(OrientationRequested.PORTRAIT);
		printRequestAttributeSet.add(MediaSizeName.ISO_A4);

		PrintServiceAttributeSet printServiceAttributeSet =
			new HashPrintServiceAttributeSet();
		// Linux: print queues like "draft", "normal", "photo", etc
		// Windows: use physical printername like  "Epson Stylus COLOR 680" or "HP LaserJet 5000 Series PCL"
		PrinterName printerName = new PrinterName("normal", Locale.getDefault());
		printServiceAttributeSet.add(printerName);

		JRPrintServiceExporter exporter = new JRPrintServiceExporter();
		exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
		exporter.setParameter(
			JRPrintServiceExporterParameter.PRINT_REQUEST_ATTRIBUTE_SET,
			printRequestAttributeSet);
		exporter.setParameter(
			JRPrintServiceExporterParameter.PRINT_SERVICE_ATTRIBUTE_SET,
			printServiceAttributeSet);
		exporter.setParameter(
			JRPrintServiceExporterParameter.DISPLAY_PAGE_DIALOG,
			Boolean.FALSE);
		exporter.setParameter(
			JRPrintServiceExporterParameter.DISPLAY_PRINT_DIALOG,
			Boolean.TRUE);
		
		boolean preview = true;

		try {
			if (preview) {
				// preview is started in non_modal
				JasperViewer.viewReport(jasperPrint, false);
			} else {
				exporter.exportReport();
			}
		} catch (JRException je) {
			System.out.println(
				"Error printing report:\n" + je.getMessage());
		}
	}

	public static void main(String[] args) {
		new TestPrintDialog().go();
//		System.exit(0);
	}
}
