/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Jan 21, 2004
 *  
 */
package nz.co.transparent.client.util;

/**
 * @author John Zoetebier
 *  
 */
import javax.crypto.Cipher;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;

import java.security.Key;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class SymmetricEncrypter {

	private static String algorithm = "DESede";
	private static Key key = null;
	private static Cipher cipher = null;

	static {
		try {
			key = KeyGenerator.getInstance(algorithm).generateKey();
			cipher = Cipher.getInstance(algorithm);
		} catch (NoSuchAlgorithmException nse) {
			System.out.println("SymmetricEncrypter:: error:");
			System.out.println(nse.getMessage());
		} catch (NoSuchPaddingException nspe) {
			System.out.println("SymmetricEncrypter:: error:");
			System.out.println(nspe.getMessage());
		}
	}
	
	private SymmetricEncrypter() {
	}

	public static void main(String[] args) throws Exception {

		if (args.length != 1) {
			System.out.println("USAGE: java SymmetricEncrypter " + "[String]");
			System.exit(1);
		}

		byte[] keys = key.getEncoded();
		System.out.println("key=" + keys);
		System.out.println("key length=" + keys.length);
		byte[] encryptionBytes = null;
		String input = args[0];
		System.out.println("Entered: " + input);
		encryptionBytes = encrypt(input);
		System.out.println("Recovered: " + decrypt(encryptionBytes));
	}

	public static byte[] encrypt(String input)
		throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
		cipher.init(Cipher.ENCRYPT_MODE, key);
		byte[] inputBytes = input.getBytes();
		return cipher.doFinal(inputBytes);
	}

	public static String decrypt(byte[] encryptionBytes)
		throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
		cipher.init(Cipher.DECRYPT_MODE, key);
		byte[] recoveredBytes = cipher.doFinal(encryptionBytes);
		String recovered = new String(recoveredBytes);
		return recovered;
	}
}