/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Client.java
 *
 * Created on November 29, 2003, 14:08 PM
 */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

import javax.swing.*;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;


/**
 *
 * @author  John Zoetebier
 */
public class PersonRoleForm extends javax.swing.JInternalFrame {

	// Constants
	private static final int FIELD_LENGTH = 14;

	// Private variables
	private Map personRoleMap = new HashMap();
	private Map personMap = new HashMap();
	private Map updaterMap = new HashMap();
	private List roleList;
	private Logger log = Logger.getLogger("nz.co.transparent.client.gui");
	private GenericController genericController = GenericController.getInstance();
	private SystemDBController systemController = SystemDBController.getInstance();
	
	private JLabel personRoleIDLabel = new JLabel("Person role ID");
	private JLabel personIDLabel = new JLabel("Person");
	private JLabel roleIDLabel = new JLabel("Role");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	private JLabel dateCreatedLabel = new JLabel("Date created");
	private JLabel dateUpdatedLabel = new JLabel("Date updated");
	
	private DateFormat timeStampFormat = new SimpleDateFormat(Parameter.getParameter("format.timestamp", Constants.FORMAT_TIMESTAMP));

	private JTextField personRoleIDField = new JTextField();
	private JTextField personIDField = new JTextField();
	private JComboBox roleIDField = new JComboBox();
	private JTextField updaterPersonIDField = new JTextField();
	private JFormattedTextField dateCreatedField = new JFormattedTextField(timeStampFormat);
	private JFormattedTextField dateUpdatedField = new JFormattedTextField(timeStampFormat);
	
	private JPanel contentPanel = new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();
	
	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public PersonRoleForm() {
		initComponents();
	}
    
	/** This method is called from within the constructor to
	 * initialize the form.
	 */
	private void initComponents() {
		
		setName("Person role form");
		setTitle("Person role form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);

		try {
			setSelected(true);
		} catch (java.beans.PropertyVetoException e1) {
			e1.printStackTrace();
		}

		addInternalFrameListener(new InternalFrameOpenedAdapter(this, personRoleIDField));

		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New person role..");
		newButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				newButton_actionPerformed();
			 }
		});
		
		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		saveButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save person role..");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(saveButton);

		reloadButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh person role..");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		deleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete person role..");
		deleteButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				deleteButton_actionPerformed(evt);
			 }
		});
		
		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));
		
		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setFocusTraversalPolicy(new InputOrderFocusTrafersalPolicy());
		dialogPanel.setFocusCycleRoot(true);	// This will force focus go down the colum

		// Dialog fields
		dialogPanel.add(personRoleIDLabel);
		Dimension fieldDimension = new Dimension(200, personRoleIDLabel.getPreferredSize().height);
		personRoleIDField.setToolTipText("Generated by system.");
		personRoleIDField.setEditable(false);
		personRoleIDField.setColumns(FIELD_LENGTH);
		dialogPanel.add(personRoleIDField);

		dialogPanel.add(personIDLabel);
		personIDField.setEditable(false);
		dialogPanel.add(personIDField);

		dialogPanel.add(roleIDLabel);
		roleIDField.setEditable(false);
		dialogPanel.add(roleIDField);

		dialogPanel.add(updaterPersonIDLabel);
		updaterPersonIDField.setEditable(false);
		dialogPanel.add(updaterPersonIDField);

		dialogPanel.add(dateCreatedLabel);
		dateCreatedField.setEditable(false);
		dialogPanel.add(dateCreatedField);

		dialogPanel.add(dateUpdatedLabel);
		dateUpdatedField.setEditable(false);
		dialogPanel.add(dateUpdatedField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
		
		// Add dialogPanel to content panel 
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);

		pack();
	}

	/**
	 * Populate form using primary key
	 * @param personRoleID primary key
	 */
	public void populateForm(int personRoleID) {

		// Role cannot be changed as this would require keeping previous state
		saveButton.setEnabled(false);

		String msg = null;
		try {
			msg = "PersonRoleForm: Cannot find person role: " + personRoleID;
			personRoleMap = genericController.findWhere("person_role", "person_role_id=" + personRoleID);

			Integer personID = (Integer) personRoleMap.get("person_id");
			msg = "PersonRoleForm: Cannot find person: " + personID;
			personMap = genericController.findWhere("person", "person_id=" + personID);
			
			Integer updaterID = (Integer) personRoleMap.get("updater_person_id");
			updaterMap = Updater.getUpdater(updaterID.intValue());

			msg = "PersonRoleForm: Cannot find roles";
			roleList = genericController.findAll("role", "role");
		} catch (ControllerException ce) {
			Messager.exception(this, msg + "\n" + ce.getMessage());
			return;
		} catch (FinderException fe) {
			Messager.exception(this, msg  + "\n" + fe.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		personRoleIDField.setText(String.valueOf(personRoleMap.get("person_role_id").toString()));
		personIDField.setText(personMap.get("user_name").toString());
		GenericUtils.updateJComboBox(roleIDField, roleList, "role", "role_id", (Integer) personRoleMap.get("role_id"));
		updaterPersonIDField.setText((String) updaterMap.get("user_name"));
		dateCreatedField.setValue(personRoleMap.get("date_created"));
		dateUpdatedField.setValue(personRoleMap.get("date_updated"));
	}
	
	public void populateNewForm(Map personMap) {

		this.personMap = personMap;
		newButton_actionPerformed();
	}

	private void newButton_actionPerformed() {

		// New role can be saved
		saveButton.setEnabled(true);

		try {
			personRoleMap.put("person_role_id", null);
			updaterMap = LoginController.getPerson();
			roleList = genericController.findAll("role", "role"); 
		} catch (ControllerException ce) {
			Messager.exception(this, "PersonRoleForm: Error getting personRole data" + ce.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		Map roleMap = null;
		
		
		personRoleIDField.setText(null);
		personIDField.setText(personMap.get("user_name").toString());
		GenericUtils.updateJComboBox(roleIDField, roleList, "role");
		updaterPersonIDField.setText(LoginController.getPerson().get("user_name").toString());
		dateCreatedField.setValue(new Date());
		dateUpdatedField.setValue(new Date());
	}

	private void saveButton_actionPerformed(ActionEvent evt) {
		
		if (!validateForm()) {
			return;
		}
		
		// Store fields in personRoleMap 
		// Convert display values to foreign keys before passing personRoleMap to nz.co.transparent.client.controller
		personRoleMap.put("person_id", personMap.get("person_id"));
		personRoleMap.put("role_id", GenericUtils.getKey(roleList, "role_id", "role", (String) roleIDField.getSelectedItem()));
		personRoleMap.put("updater_person_id", LoginController.getPerson().get("person_id"));
		personRoleMap.put("date_created", dateCreatedField.getValue());
		personRoleMap.put("date_updated", dateUpdatedField.getValue());

		try {
			// If new person role, then insert, else update
			if (personRoleIDField.getText().equals("")) {
				// Check if role exists for this person
				String where = "person_id=? and role_id=?";
				Object[] params = new Object[2];
				params[0] = personRoleMap.get("person_id");
				params[1] = personRoleMap.get("role_id");

				if (genericController.existsRecord("person_role", where, params)) {
					Messager.information(this, "Person has already role");
					return;
				}

				personRoleMap.put("person_role_id", null); 	// Force to generate key
				genericController.insertRecord("person_role", "person_role_id", personRoleMap);
				
				Map userMap = systemController.getUser(personMap.get("user_name").toString());
				// If role admin
				if (personRoleMap.get("role_id").equals(new Integer(1))) {
					// Grant ALL permission on person table
					genericController.grantPermission("ALL", "person", personMap.get("user_name").toString(), true);
					// Add admin to admin group in System DB
					systemController.alterUser(personMap.get("user_name").toString(), userMap.get("Password").toString(), Constants.SYSTEMDB_ADMIN_GROUP);
				} else {
					// Do nothing: PUBLIC permissions are active
				}
			} else {
				// Never executed: leave for future use
				personRoleMap.put("person_role_id", Integer.valueOf(personRoleIDField.getText()));	// Cast to Integer, otherwise record lookup and update will fail
				genericController.updateRecord("person_role", "person_role_id", personRoleMap);
			}
			
			Integer personRoleID = (Integer) personRoleMap.get("person_role_id");
			populateForm(personRoleID.intValue());
		} catch (UpdaterException ue) {
			String message = "Update warning !\n";
			message += "Changes have been made by an other person or process.\n";
			message += "Form will be refreshed with latest values";
			Messager.warning(this, message);
			populateForm(Integer.parseInt(personRoleMap.get("person_role_id").toString()));
		} catch (ControllerException ce) {
			Messager.exception(this, "Error: " + ce.getMessage());
		}
	}

	private void deleteButton_actionPerformed(ActionEvent evt) {
		String msg = null;

		if (personRoleMap.get("person_role_id") == null) {
			msg = "New personRole cannot be deleted";
			Messager.information(this, msg);
			return;
		}

		msg = "Continue to delete person role ?";
		if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
			return;
		}
			
		try {
			Integer personRoleID = (Integer) personRoleMap.get("person_role_id");
			genericController.deleteRecord("person_role", "person_role_id=" + personRoleID.intValue());
			
			Map userMap = systemController.getUser(personMap.get("user_name").toString());
			// If role admin
			if (personRoleMap.get("role_id").equals(new Integer(1))) {
				// Remove  admin from admin group in System DB
				systemController.dropUser(personMap.get("user_name").toString());
				systemController.createUser(personMap.get("user_name").toString(), userMap.get("Password").toString());
				// Remove all permissions 
				// PUBLIC permissions still valid
				genericController.revokeAllPermissions(personMap.get("user_name").toString());
			} else {
				// No change to permissions as all users are granted SELECT permission
			}

			newButton_actionPerformed();
		} catch (ControllerException ce) {
			Messager.exception(this, "PersonRoleForm: Error deleting person role.\n" + ce.getMessage());
			return;
		}
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogPanel);
		
		if (roleIDField.getSelectedItem().equals("")) {
			roleIDField.getEditor().getEditorComponent().setBackground(Color.YELLOW);
			roleIDField.setToolTipText("Please enter role");
			roleIDField.requestFocus();
			validationOk = false;
		}

		// Check if new item entered in combobox
		String msg = null;
		try {
			if (roleIDField.getSelectedIndex() == -1) {
				// Add new role silently, if required
				personRoleMap.put("role_id", genericController.getForeignKey("role", (String) roleIDField.getSelectedItem(), "role", "role_id", roleList));
				GenericUtils.updateJComboBox(roleIDField, roleList, "role", "role_id", (Integer) personRoleMap.get("role_id"));
			}

			return validationOk;
		} catch (ControllerException ce) {
			msg = "Controller error: " + ce.getMessage();
			log.warning(msg);
			Messager.exception(this, msg);
			return false;
		}
	}
	
	private void reloadButton_actionPerformed(ActionEvent evt) {
		Integer personRoleID = (Integer) personRoleMap.get("person_role_id");
		
		if (personRoleID == null) {
			this.newButton_actionPerformed();
		} else {
			this.populateForm(personRoleID.intValue());
		}
	}

}