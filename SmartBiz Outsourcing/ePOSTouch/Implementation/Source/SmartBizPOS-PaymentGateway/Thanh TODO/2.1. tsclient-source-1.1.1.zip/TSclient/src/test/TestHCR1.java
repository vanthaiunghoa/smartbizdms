/*
 * Focus.java
 *
 * Created on Januari 3, 2004
 */

package test;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.*;

import javax.swing.*;

/**
 *
 * @author  John Zoetebier
 */
public class TestHCR1 extends javax.swing.JFrame {

	// Constants
	private static final int FIELD_LENGTH = 20;

	private JLabel concatLabel = new JLabel("concat");
	
	private JTextField concatField = new JTextField();
	
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();

	private JButton concatButton = new JButton();
	private JButton saveButton = new JButton();
	
	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public TestHCR1() {
		super();

		setName("HCR form");
		setTitle("HCR form");
		setResizable(true);
		addWindowListener(new WindowAdapter() {
			public void windowOpened(WindowEvent e) {
				requestFocusFor(concatField);
			}
		});
		
		Container contentPanel = getContentPane();
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		concatButton.setText("test");
		concatButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				test();
			}
		});
		concatButton.setMnemonic(KeyEvent.VK_N);
		
		toolbarMain.add(concatButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		saveButton.setText("save");
		saveButton.setMnemonic(KeyEvent.VK_S);

		toolbarMain.add(saveButton);

		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new GridLayout(0,2));

		// Dialog fields
		dialogPanel.add(concatLabel);
		concatField.setColumns(FIELD_LENGTH);
		dialogPanel.add(concatField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
		
		// Add dialogPanel to content panel 
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);

		setSize(500, 400);
		pack();
		setVisible(true);
	}
	
	public void test() {
		String s1 = "string1";
		String s2 = "string2";
		String s3 = "string3";
		String s4 = "string4";
		
		// Step 1
		// - start debugger and run
		// - click on button "Test"
		// Step 2: 
		// - comment out step 1, uncomment step 2 and save
		// - click on button "Test"
		concatField.setText(concatString(s1, s2));	// step 1   
		//concatField.setText(concatString(s3, s4));	// step 1   
		
	}
	
	private String concatString(String p1, String p2) {
		String newString = "Hello " + p1 + ", " + p2;
		return newString;
	}
	
	private void requestFocusFor(final JComponent comp) {

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				comp.setRequestFocusEnabled(true);
				comp.requestFocus();
			}
		});
	}
	
	public static void main (String[] args) {
		
		new TestHCR1();
	}
}
