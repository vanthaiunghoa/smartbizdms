/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * ParameterTableForm.java
 *
 * Created on Januari 17, 2004
 */

package nz.co.transparent.client.gui;

import nz.co.transparent.client.gui.util.GenericUtils;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.swing.*;

import nz.co.transparent.client.controller.GenericController;
import nz.co.transparent.client.db.ControllerException;

import nz.co.transparent.client.util.Configuration;
import nz.co.transparent.client.util.Constants;
import nz.co.transparent.client.util.Messager;
import nz.co.transparent.client.util.Parameter;


/**
 * Show table with parameters
 * 
 * @author John Zoetebier
 *
 */
public class ParameterTableForm extends JPanel  {
    
	private static List columnPropertyMapList = new ArrayList();
	private static Map columnPropertyMap;

	static {
		columnPropertyMap = new HashMap(2);
		columnPropertyMap.put("columnName", "parameter_id");
		columnPropertyMap.put("columnHeader", "Parameter ID");
		columnPropertyMapList.add(columnPropertyMap);
		
		columnPropertyMap = new HashMap(2);
		columnPropertyMap.put("columnName", "parameter_key");
		columnPropertyMap.put("columnHeader", "Parameter key");
		columnPropertyMapList.add(columnPropertyMap);
		
		columnPropertyMap = new HashMap(2);
		columnPropertyMap.put("columnName", "parameter");
		columnPropertyMap.put("columnHeader", "Parameter");
		columnPropertyMapList.add(columnPropertyMap);
	}
	
	private Logger log = Logger.getLogger("nz.co.transparent.client.gui");

	private ParameterForm form;
	private Map searchMap;

	private JTable table = new JTable ();
	private JPanel panel;
	private JToolBar toolbar = new JToolBar();
	private JButton newButton = new JButton();
	private JButton updateButton = new JButton();
	private JButton deleteButton = new JButton();
	private JScrollPane scrollPane = new JScrollPane();
	private GenericTableModel tableModel = new GenericTableModel(columnPropertyMapList);
	private GenericController genericController = GenericController.getInstance();

	public ParameterTableForm() {

		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		toolbar.setBorder(BorderFactory.createEtchedBorder());
		toolbar.setFloatable(false);

		newButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif")));
		newButton.setToolTipText("New parameter");
		newButton.setMnemonic(KeyEvent.VK_C);
		newButton.setEnabled(true);
		newButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				form = new ParameterForm();
				form.populateNewForm();
				MainFrame.openFrame(form);
			}
		});
		
		updateButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Edit24.gif")));
		updateButton.setToolTipText("Update parameter");
		updateButton.setMnemonic(KeyEvent.VK_U);
		updateButton.setEnabled(true);
		updateButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Get parameterID from table
				int index = table.getSelectedRow();
				if (index < 0) {
					Messager.information((JFrame) MainFrame.getInstance(), "Please select a row in table");
					return;
				}

				Integer parameterID = (Integer) table.getValueAt(index, 0);
				form = new ParameterForm();
				form.populateForm(parameterID.intValue());
				MainFrame.openFrame(form);
			}
		});
		
		deleteButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setToolTipText("Delete parameter");
		deleteButton.setMnemonic(KeyEvent.VK_L);
		deleteButton.setEnabled(true);
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Get parameterID from table
				int index = table.getSelectedRow();
				if (index < 0) {
					Messager.information((JFrame) MainFrame.getInstance(), "Please select a row in table");
					return;
				}

				if (Messager.question((JFrame) MainFrame.getInstance(), "This will delete this record and all dependent records.\nDo you want to continue ?") != JOptionPane.YES_OPTION) {
					return;
				}

				Integer parameterID = (Integer) table.getValueAt(index, 0);
				int maxRecords = Integer.parseInt(Parameter.getParameter("max.records.search", Constants.MAX_RECORDS_SEARCH));
				StringBuffer maxPassed = new StringBuffer();
				try {
					genericController.deleteRecord("parameter", "parameter_id=" + parameterID);
					updateTable(searchMap);
				} catch (ControllerException ce) {
					String msg = "ParameterTableForm: error deleting parameter. " + ce.getMessage();
					log.warning(msg);
					Messager.exception(null, msg);
					return;
				}
			}
		});

		toolbar.add(newButton);
		toolbar.add(Box.createRigidArea(new Dimension(5,0)));
		toolbar.add(updateButton);
		toolbar.add(Box.createRigidArea(new Dimension(5,0)));
		toolbar.add(deleteButton);
		toolbar.add(Box.createGlue());

		panel = new JPanel(new BorderLayout());
		panel.setBorder(BorderFactory.createCompoundBorder(
						BorderFactory.createEtchedBorder(), 
						BorderFactory.createEmptyBorder(5, 5, 5, 5)
						));
		panel.add(toolbar, BorderLayout.NORTH);
		
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.setToolTipText("Select a row, then click on button in toolbar");
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() >= 2) {
					updateButton.doClick();
				}
			}
		});
		
		scrollPane = new JScrollPane(table);
		scrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

		panel.add(scrollPane, BorderLayout.CENTER);
		tableModel = new GenericTableModel(columnPropertyMapList);
		GenericUtils.updateTable(table, tableModel);
		add(panel);
	}
	
	public void updateTable(Map searchMap) {
		// Create new table model for each search
		//tableModel = new GenericTableModel(columnPropertyMapList);
		this.searchMap = searchMap;
		int maxRecords = Integer.parseInt(Configuration.getProperty("max.records.search", Constants.MAX_RECORDS_SEARCH));

		try {
			Map countMap = new HashMap(2);
			countMap.put("maxRecords", new Integer(30));
			List list = genericController.findAllWhere("parameter", "parameter_key", searchMap, countMap);
			tableModel.setMapList(list);
			GenericUtils.updateTable(table, tableModel);
			
			if (countMap.get("maxPassed").equals(Boolean.TRUE)) {
				Messager.information(getParent(), "Too many records found. Please refine search.");
				//this.messageLabel.setText("Too many records found. Please refine search.");
			} else {
				if (list.size() == 0) {
					Messager.information(this, "No records found. Please widen search by removing search fields, use less characters and check letter case");
				}
			}
		} catch (Exception e) {
			nz.co.transparent.client.util.Messager.exception(this, "ParameterTableForm: Error gettting data: " + e);
		}
	}
}