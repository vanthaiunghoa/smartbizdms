/*
 * Created on Dec 22, 2003
 *
 */
package test;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 * @author johnz
 * 
 */
public class TestComboBox2 extends JFrame {

	/**
	 * 
	 */
	public TestComboBox2() {
		super();
		
		Container content = getContentPane();
		content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
		JLabel comboLabel = new JLabel("Select:");
		content.add(comboLabel);
		
		Vector list = new Vector();
		list.add("Item 1");
		list.add("Item 2");
		list.add("Item 3");
		list.add("Item 4");
		list.add("Item 5");
		JComboBox comboField = new JComboBox(list);
		comboField.setEditable(true);
		Component editorComponent = comboField.getEditor().getEditorComponent();
		editorComponent.setBackground(Color.YELLOW);
		//comboField.setBackground(Color.YELLOW);
		content.add(comboField);

		JLabel otherLabel = new JLabel("Other field:");
		content.add(otherLabel);
		JTextField textField = new JTextField("");
		content.add(textField);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(600, 400);
		pack();
		setVisible(true);
		
	}

	
	public static void main(String[] args) {
		new TestComboBox2();
	}
}
