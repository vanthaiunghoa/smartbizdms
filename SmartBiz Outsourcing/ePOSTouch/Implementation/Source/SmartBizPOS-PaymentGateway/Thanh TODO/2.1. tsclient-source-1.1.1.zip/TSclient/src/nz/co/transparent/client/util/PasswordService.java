/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Dec 1, 2003
 * 
 * To change the template for this generated file go to Window - Preferences -
 * Java - Code Generation - Code and Comments
 */
package nz.co.transparent.client.util;

/**
 * @author johnz
 *  
 */

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import nz.co.transparent.client.db.ControllerException;

import sun.misc.BASE64Encoder;

public final class PasswordService {

	private PasswordService() {
	}

	/**
	 * 
	 * @param passwordInPlainText Passowrd in plain text format
	 * @return Password in encrypted format
	 * @throws ControllerException
	 */
	public static String encrypt(char [] passwordInPlainText) 
		throws ControllerException {
	
		String password = new String(passwordInPlainText);
		return encrypt(password);
	}
	
	/**
	 * 
	 * @param passwordInPlainText Passowrd in plain text format
	 * @return Password in encrypted format
	 * @throws ControllerException
	 */
	public static String encrypt(String passwordInPlainText)
		throws ControllerException {
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("SHA"); //step 2
		} catch (NoSuchAlgorithmException e) {
			throw new ControllerException(e.getMessage());
		}
		try {
			md.update(passwordInPlainText.getBytes("UTF-8")); //step 3
		} catch (UnsupportedEncodingException e) {
			throw new ControllerException(e.getMessage());
		}

		byte raw[] = md.digest(); //step 4
		String hash = (new BASE64Encoder()).encode(raw); //step 5
		return hash; //step 6
	}
}