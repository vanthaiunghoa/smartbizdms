/*
 * Created on Oct 28, 2003
 * 
 * To change the template for this generated file go to Window - Preferences -
 * Java - Code Generation - Code and Comments
 */

package test;

import java.text.NumberFormat;
import java.util.Locale;


class TestNumberFormat {

	public static void main(String[] args) {
		new TestNumberFormat().go();

	}

	TestNumberFormat() {
	}

	private void go() {
		
		double amount = 100.25;
		NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.getDefault());
		String dollarAmount = currencyFormat.format(amount);
		System.out.println("amount = " + dollarAmount);
	}
}	
