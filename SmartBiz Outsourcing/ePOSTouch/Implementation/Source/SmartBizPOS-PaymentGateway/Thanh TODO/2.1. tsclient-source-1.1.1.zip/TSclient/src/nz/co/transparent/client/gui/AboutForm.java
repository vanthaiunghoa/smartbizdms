/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Jan 29, 2004
 *  
 */
package nz.co.transparent.client.gui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Frame;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import nz.co.transparent.client.util.Constants;

/**
 * @author John Zoetebier
 *  
 */
public class AboutForm extends JDialog {

	/**
	 *  
	 */
	public AboutForm(Frame parent, String title) {
		super(parent, title, true);
		
		if (title==null){
			setTitle("");
		}
		if (parent != null){
			setLocationRelativeTo(parent);
		}
	}

	public AboutForm(Frame parent) {
		this(parent, null);
	}

	public AboutForm() {
		this(null, null);
	}

	public void dialogInit() {

		JPanel panel1 = new JPanel();
		panel1.setLayout(new BoxLayout(panel1, BoxLayout.Y_AXIS));
		panel1.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		JLabel logoLabel = new JLabel();
		logoLabel.setIcon(
			new ImageIcon(getClass().getResource("/images/TS_logo.jpg")));
		panel1.add(logoLabel);

		JPanel panel2 = new JPanel();
		panel2.setLayout(new BoxLayout(panel2, BoxLayout.Y_AXIS));
		panel2.setBorder(BorderFactory.createEmptyBorder(20, 5, 5, 5));
		JLabel textLabel1 = new JLabel("TS Client " + Constants.TS_CLIENT_VERSION);
		panel2.add(textLabel1);
		JLabel textLabel2 = new JLabel("Copyright (c) 2004 Transparent Systems Limited");
		panel2.add(textLabel2);
		JLabel textLabel3 = new JLabel("Web site http://www.transparent.co.nz");
		panel2.add(textLabel3);

		JPanel panel3 = new JPanel();
		panel3.setLayout(new BoxLayout(panel3, BoxLayout.X_AXIS));
		panel3.add(Box.createHorizontalGlue());
		panel3.add(panel2);
		panel3.add(Box.createHorizontalGlue());

		super.dialogInit();
		Container content = this.getContentPane();
		content.add(panel1, BorderLayout.NORTH);
		content.add(panel3, BorderLayout.SOUTH);
		pack();
	}
	
	public void showDialog() {
		show();
	}
}