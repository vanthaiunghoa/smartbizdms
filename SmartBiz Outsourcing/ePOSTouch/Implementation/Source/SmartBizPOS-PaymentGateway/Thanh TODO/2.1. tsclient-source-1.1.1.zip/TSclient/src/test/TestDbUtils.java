/*
 * Created on Dec 13, 2003
 *
 */
package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.MapHandler;

import nz.co.transparent.client.util.Constants;


/**
 * @author johnz
 * 
 */
public class TestDbUtils {

	public TestDbUtils() {
		super();
	}
	
	public void go() {
		
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(Constants.JDBC_URL);
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}
		
		QueryRunner runner = new QueryRunner();
		ResultSetHandler rsh = new MapHandler();
		String sql = "select * from Client where (ClientID=1)";
		Map clientMap = null;
		try {
			clientMap = (Map) runner.query(conn, sql, null, rsh);
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}
		
		Set fieldSet = clientMap.keySet();
		Iterator iterator = fieldSet.iterator();
		String fieldName = null;
		
		while (iterator.hasNext()) {
			fieldName = (String) iterator.next();
			System.out.println("Field name = " + fieldName);
			System.out.println("Field value = " + clientMap.get(fieldName));
		}
		
		clientMap = null;
		try {
			clientMap = (Map) runner.query(conn, sql, null, rsh);
			DbUtils.close(conn);
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}

		System.out.println("LastName = " + clientMap.get("lastname"));
	}
	

	public static void main(String[] args) {
		new TestDbUtils().go();
	}
}
