/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Jan 26, 2004
 *
 */
package nz.co.transparent.client.gui.util;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

/**
 * Shows dialog with text box to enter password
 * Returns a string if password has been entered
 * Returns null in case of cancel
 * 
 * <pre>
 * Example:
 * PasswordOnlyDialog dialog = new PasswordOnlyDialog()
 * System.out.println("Password=" + dialog.showDialog();
 * </pre>
 * 
 * @author John Zoetebier
 * 
 */

public class ChangePasswordDialog extends JDialog {

	protected JPasswordField passwordOldField;
	protected JPasswordField password1Field;
	protected JPasswordField password2Field;
	protected JLabel passwordOldLabel;
	protected JLabel password1Label;
	protected JLabel password2Label;
	protected JButton okButton;
	protected JButton cancelButton;

	private boolean isOkPressed = false;
	
	/**
	 * 
	 */
	public ChangePasswordDialog(Frame parent, String title) {
		super(parent, title, true);
		
		if (title==null){
			setTitle("Password");
		}
		if (parent != null){
			setLocationRelativeTo(parent);
		}
		// super calls dialogInit, so we don't need to do it again.
	}
	
	public ChangePasswordDialog(Frame parent) {
		this(parent, null);
	}

	public ChangePasswordDialog() {
		this(null, null);
	}


	protected void dialogInit(){
		
//		setUndecorated(true);
		passwordOldField = new JPasswordField(20);
		password1Field = new JPasswordField(20);
		password2Field = new JPasswordField(20);
		passwordOldLabel = new JLabel("Enter old password:");
		password1Label = new JLabel("Enter password:");
		password2Label = new JLabel("Enter password again:");
		okButton = new JButton("Ok");
		cancelButton = new JButton("Cancel");

		super.dialogInit();

		KeyListener keyListener = (new KeyAdapter() {
			public void keyPressed(KeyEvent e){
				if (e.getKeyCode() == KeyEvent.VK_ESCAPE ||
						(e.getSource() == cancelButton
						&& e.getKeyCode() == KeyEvent.VK_ENTER)){
					isOkPressed = false;
					ChangePasswordDialog.this.setVisible(false);
				}
				
				if (e.getSource() == okButton &&
						e.getKeyCode() == KeyEvent.VK_ENTER){
					isOkPressed = true;
					ChangePasswordDialog.this.dispose();
				}
			}
		});
		
		addKeyListener(keyListener);

		ActionListener actionListener = new ActionListener() {
			public void actionPerformed(ActionEvent e){
				Object source = e.getSource();
				isOkPressed = (source == passwordOldField || source == okButton);
				ChangePasswordDialog.this.dispose();
			}
		};

		passwordOldField.addActionListener(actionListener);
		password1Field.addActionListener(actionListener);
		password2Field.addActionListener(actionListener);
		okButton.addActionListener(actionListener);
		okButton.addKeyListener(keyListener);
		cancelButton.addActionListener(actionListener);
		cancelButton.addKeyListener(keyListener);
		
		Container content = this.getContentPane();
		content.setLayout(new BorderLayout());
		JPanel panel1 = new JPanel(new DialogLayout());
		panel1.setBorder(BorderFactory.createEmptyBorder(5,10,5,10));
		panel1.add(passwordOldLabel);
		panel1.add(passwordOldField);
		panel1.add(password1Label);
		panel1.add(password1Field);
		panel1.add(password2Label);
		panel1.add(password2Field);
		content.add(panel1, BorderLayout.NORTH);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(5,10,5,10));
		buttonPanel.add(Box.createGlue());
		buttonPanel.add(okButton);
		buttonPanel.add(Box.createHorizontalStrut(5));
		buttonPanel.add(cancelButton);
		buttonPanel.add(Box.createGlue());
		content.add(buttonPanel, BorderLayout.CENTER);
		pack();
	}

	/**
	 * Return true of OK is pressed
	 * 
	 * @return isOkPressed
	 */
	public Map showDialog(){
		setVisible(true);
		//show();
		Map returnMap = new HashMap();
		returnMap.put("isOkPressed", new Boolean(isOkPressed));
		returnMap.put("passwordOld", String.valueOf(passwordOldField.getPassword()));
		returnMap.put("password1", String.valueOf(password1Field.getPassword()));
		returnMap.put("password2", String.valueOf(password2Field.getPassword()));
		return returnMap;
	}
}