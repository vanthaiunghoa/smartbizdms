/*
 * Created on Dec 22, 2003
 *
 */
package test;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.*;

import javax.swing.*;

/**
 * @author johnz
 * 
 */
public class TestFrame extends JFrame {

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();
	
	private JToolBar toolbarMain = new JToolBar();

	/**
	 * 
	 */
	public TestFrame() {
		super();
		
		setName("Focus form");
		setTitle("Focus form");
		setResizable(true);
		Container contentPanel = getContentPane();
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);

				toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New occupation.");
		
		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		saveButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save occupation.");

		toolbarMain.add(saveButton);

		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh occupation.");

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		deleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete occupation.");
		
		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));
		
		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);


		
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(600, 400);
		pack();
		setVisible(true);
		
	}

	
	public static void main(String[] args) {
		new TestFrame();
	}
}
