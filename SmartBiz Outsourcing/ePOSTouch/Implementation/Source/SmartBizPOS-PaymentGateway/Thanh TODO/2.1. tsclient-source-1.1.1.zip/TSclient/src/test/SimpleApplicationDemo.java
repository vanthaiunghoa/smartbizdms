package test;

/**
 * This demonstrates a simple stand-alone database application.  This will
 * start up the database that's found in this directory and perform some
 * queries on the data.
 * <p>
 * The demo distribution should contain the database data files already
 * prepared.  However, if the 'data' directory was removed then run
 * 'SimpleDatabaseCreateDemo' to remake it.
 */

import java.sql.*;

public class SimpleApplicationDemo {

  /**
   * The demonstation 'main' method.
   */
  public static void main(String[] args) {

    System.out.println();

    // Register the Mckoi JDBC Driver
    try {
      Class.forName("com.mckoi.JDBCDriver").newInstance();
    }
    catch (Exception e) {
      System.out.println(
	 "Unable to register the JDBC Driver.\n" +
	 "Make sure the classpath is correct.\n" +
	 "For example on Win32;  java -cp ../../mckoidb.jar;. SimpleApplicationDemo\n" +
	 "On Unix;  java -cp ../../mckoidb.jar:. SimpleApplicationDemo");
      return;
    }

    // This URL specifies we are connecting with a local database.  The
    // configuration file for the database is found at './ExampleDB.conf'
    String url = "jdbc:mckoi:local://ExampleDB.conf";

    // The username/password for the database.  This is set when the database
    // is created (see SimpleDatabaseCreateDemo).
    String username = "user";
    String password = "pass1212";

    // Make a connection with the database.
    Connection connection;
    try {
      connection = DriverManager.getConnection(url, username, password);
    }
    catch (SQLException e) {
      System.out.println(
	 "Unable to make a connection to the database.\n" +
	 "The reason: " + e.getMessage());
      return;
    }

    // --- Do some queries ---
    System.out.println();

	int i;

    try {
      // Create a Statement object to execute the queries on,
      Statement st = connection.createStatement();

	  for(i=0;i<100;i++)
	  {
	  	ResultSet rs=st.executeQuery("select xxxData.rowid as rowid,geo_descr,produc_descr,period_descr,measure1,measure2 " +
                                   "from xxxGeo,xxxProduc,xxxPeriod,xxxData " +
                                   "where xxxData.rowid >= " + 1000 + " " +
								   "and xxxData.rowid <= " + 1100 + " " + 
                                   "and xxxGeo.geo_rowid=xxxData.geo_rowid " +
                                   "and xxxProduc.produc_rowid=xxxData.product_rowid " +
                                   "and xxxPeriod.period_rowid=xxxData.period_rowid order by rowid");
       	while(rs.next())
		{
//			System.out.println(rs.getInt(1) + "," + rs.getString(2) + "," + rs.getString(3) + "," + rs.getString(4) + "," + rs.getDouble(5) + "," + rs.getDouble(6));
		}
	}

      System.out.println();

      st.close();
      connection.close();

    }
    catch (SQLException e) {
      System.out.println(
	"An error occured\n" +
	"The SQLException message is: " + e.getMessage());
      return;
    }

  }

}
