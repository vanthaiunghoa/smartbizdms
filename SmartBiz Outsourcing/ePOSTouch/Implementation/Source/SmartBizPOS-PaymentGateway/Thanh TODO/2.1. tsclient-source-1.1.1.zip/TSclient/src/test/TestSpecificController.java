/*
 * Created on Nov 16, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import java.util.HashMap;
import java.util.Map;

import nz.co.transparent.client.controller.SpecificController;
import nz.co.transparent.client.db.*;
import nz.co.transparent.client.gui.*;

/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class TestSpecificController {
	
	private void go() {

		SpecificController controller = SpecificController.getInstance();
		GenericTableModel clientTableModel = null;
		
		try {
			//ClientTableModel clientTableModel = nz.co.transparent.client.controller.getClients("", "", "", 30);
			//ClientTableModel clientTableModel = nz.co.transparent.client.controller.getClients("Smith", "", "", 30);
			//ClientTableModel clientTableModel = nz.co.transparent.client.controller.getClients("", "Jane", "", 30);
			//ClientTableModel clientTableModel = nz.co.transparent.client.controller.getClients("", "", "0001", 30);
			StringBuffer maxPassed = new StringBuffer();
			Map searchMap = new HashMap(3);
			searchMap.put("last_name", "Smith");
			searchMap.put("first_name", "J");
			searchMap.put("contact_detail", "");
			clientTableModel.setMapList(controller.findClients(searchMap, 30, maxPassed));
			
			for (int i=0; i<clientTableModel.getRowCount(); i++) {
				System.out.println("client_id: " + clientTableModel.getValueAt(i, 0));
				System.out.println("   last_name: " + clientTableModel.getValueAt(i, 1));
				System.out.println("   first_name: " + clientTableModel.getValueAt(i, 2));
				System.out.println("   contact-type: " + clientTableModel.getValueAt(i, 7));
				System.out.println("   contact_detail: " + clientTableModel.getValueAt(i, 8));
			}
			
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage() );
		}
	}
	
	public static void main (String [] args) {
		PoolingDriverHandler dbcPool  =  new PoolingDriverHandler("client");
		new TestSpecificController().go();
		dbcPool.closeConnectionPool();
		System.out.println("Done");
	}
}
