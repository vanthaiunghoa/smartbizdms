/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 *
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

 /*
  * Created on Dec 1, 2003
  *
  * To change the template for this generated file go to
  * Window - Preferences - Java - Code Generation - Code and Comments
  */
package nz.co.transparent.client.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.apache.commons.dbutils.DbUtils;

/**
 * @author johnz
 *
 */
public class SQL {
    
    /**
     *
     */
    private SQL() {
        super();
    }
    
    /**
     * Get unique key for tableName with primaryKeyName
     * This method assumes that previous key of all tables has been reset with resetUniqueKey during database setup
     *
     * @param tableName Name of table
     * @param primaryKeyName Column name of primary key
     * @return primary key
     * @throws SQLException
     */
    public static int getUniqueKey(String tableName, String primaryKeyName)
    throws SQLException {
        
        DataSource dataSource = DataSourceHandler.getDataSource();
        Connection conn = null;
        Statement stmt = null;
        
        try {
            String sql = "select UNIQUEKEY('" + tableName + "') as KeyID";
            conn = dataSource.getConnection();
            stmt = conn.createStatement();
            ResultSet rset;
            rset = stmt.executeQuery(sql);
            rset.next();
            int key = rset.getInt("KeyID");
            return key;
        } catch (SQLException se) {
            throw new SQLException(se.getMessage());
        } finally {
            try {
                DbUtils.close(stmt);
                DbUtils.close(conn);
            } catch (SQLException se) {
                throw new SQLException(se.getMessage());
            }
        }
    }
    
    public static void resetUniqueKey(String tableName, String primaryKeyName)
    throws SQLException {
        
        DataSource dataSource = DataSourceHandler.getDataSource();
        Connection conn = null;
        PreparedStatement pstmt = null;
        Statement stmt = null;
        
        try {
            String sql1 = "select UNIQUEKEY('" + tableName + "') as KeyID";
            String sql2 = "select max(" + primaryKeyName + ") as MaxKey from " + tableName;
            conn = dataSource.getConnection();
            pstmt = conn.prepareStatement(sql1);
            ResultSet rset;
            rset = pstmt.executeQuery();
            rset.next();
            int key = rset.getInt("KeyID");
            
            stmt = conn.createStatement();
            rset = stmt.executeQuery(sql2);
            rset.next();
            int maxKey = rset.getInt("MaxKey");
            if (key >= maxKey) {
                return;
            }
            
            // We have to set the sequence right
            for (int i=key + 1; i <= maxKey; i++) {
                rset = pstmt.executeQuery();
            }

            return;
        } catch (SQLException se) {
            throw new SQLException(se.getMessage());
        } finally {
            try {
                DbUtils.close(stmt);
                DbUtils.close(pstmt);
                DbUtils.close(conn);
            } catch (SQLException se) {
                throw new SQLException(se.getMessage());
            }
        }
    }
}