/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * ClientSearch.java
 * 
 * Created on November 10, 2003, 12:21 PM
 */

package nz.co.transparent.client.gui;

import nz.co.transparent.client.gui.util.DialogLayout;
import nz.co.transparent.client.gui.util.InternalFrameOpenedAdapter;

import java.awt.Dimension;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;

/**
 * @author John Zoetebier
 *  
 */
public class ClientSearchForm extends javax.swing.JInternalFrame {

	private static final int FIELD_LENGTH = 20;

	private JLabel lastNameLabel = new JLabel("Last name:");
	private JLabel firstNameLabel = new JLabel("First name:");
	private JLabel contactDetailLabel = new JLabel("Contact detail:");
	private JPanel contentPane = new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();
	private JTextField lastNameField = new JTextField();
	private JTextField firstNameField = new JTextField();
	private JTextField contactDetailField = new JTextField();
	private JButton clientSearchButton = new JButton();
	private JButton clientNewSearchButton = new JButton();
	private JToolBar mainToolBar = new JToolBar();
	private ClientTableForm clientTableForm;
	private Map searchMap;
	private boolean firstInternalframeActivated = false;
	// End of variables declaration

	/** Creates new form ClientSearch */
	public ClientSearchForm() {
		initComponents();
	}

	/**
	 * This method is called from within the constructor to initialize the
	 * form.
	 */
	private void initComponents() {

		setName("Client search");
		setTitle("Client search");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		setContentPane(contentPane);
		try {
			setSelected(true);
		} catch (java.beans.PropertyVetoException e1) {
			e1.printStackTrace();
		}

		addInternalFrameListener(
			new InternalFrameOpenedAdapter(
				this,
				lastNameField));
		addInternalFrameListener(new InternalFrameAdapter() {
			public void internalFrameActivated(InternalFrameEvent e) {
                            formInternalFrameActivated();
			}

                        public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                            try {
                                evt.getInternalFrame().setMaximum(true);
                            } catch (java.beans.PropertyVetoException pve) {
                                System.out.println(pve.getMessage());
                            }
                        }
		});

		clientSearchButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Find24.gif")));
		clientSearchButton.setMnemonic(KeyEvent.VK_E);
		clientSearchButton.setToolTipText(
			"Enter one or more of the search fields. Then click me.");
		clientSearchButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				clientSearchButton_actionPerformed();
			}
		});

		clientNewSearchButton.setIcon(
				new javax.swing.ImageIcon(
					getClass().getResource(
						"/toolbarButtonGraphics/general/New24.gif")));
			clientNewSearchButton.setMnemonic(KeyEvent.VK_N);
			clientNewSearchButton.setToolTipText(
				"New search: clean search fields");
			clientNewSearchButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					clientNewSearchButton_actionPerformed();
				}
			});

		mainToolBar.setBorder(BorderFactory.createEtchedBorder());
		mainToolBar.setFloatable(false);
		mainToolBar.add(Box.createRigidArea(new Dimension(5, 0)));
		mainToolBar.add(clientSearchButton);
		mainToolBar.add(clientNewSearchButton);

		mainToolBar.add(Box.createHorizontalGlue());
		// make buttons left aligned
		contentPane.add(mainToolBar);

		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));

		dialogPanel.add(lastNameLabel);
		lastNameField.setColumns(FIELD_LENGTH);
		lastNameField.setText("");
		lastNameField.setToolTipText("Last name or part of it.");
		lastNameField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					clientSearchButton.doClick();
				}
			}
		});
		dialogPanel.add(lastNameField);

		dialogPanel.add(firstNameLabel);
		firstNameField.setText("");
		firstNameField.setColumns(FIELD_LENGTH);
		firstNameField.setToolTipText("First name or part of it.");
		firstNameField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					clientSearchButton.doClick();
				}
			}
		});
		dialogPanel.add(firstNameField);

		dialogPanel.add(contactDetailLabel);
		contactDetailField.setText("");
		contactDetailField.setColumns(FIELD_LENGTH);
		contactDetailField.setToolTipText(
			"Phone number, fax, email address etc.");
		contactDetailField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					clientSearchButton.doClick();
				}
			}
		});
		dialogPanel.add(contactDetailField);

		middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.X_AXIS));
		middlePanel.setBorder(
			BorderFactory.createCompoundBorder(
				BorderFactory.createEtchedBorder(),
				BorderFactory.createEmptyBorder(20, 5, 20, 5)));
		middlePanel.add(dialogPanel);
		middlePanel.add(Box.createHorizontalStrut(700));

		contentPane.add(middlePanel);

		//===========================================
		// Create client table form
		//===========================================
		clientTableForm = new ClientTableForm();
		contentPane.add(clientTableForm);

		//===========================================
		// Pack
		//===========================================
		pack();
	}

	private void clientSearchButton_actionPerformed() {
		searchMap = new HashMap();
		searchMap.put("last_name", lastNameField.getText());
		searchMap.put("first_name", firstNameField.getText());
		searchMap.put("contact_detail", contactDetailField.getText());
		clientTableForm.updateTable(searchMap);
	}

	private void clientNewSearchButton_actionPerformed() {
		lastNameField.setText("");
		firstNameField.setText("");
		contactDetailField.setText("");
	}

	private void formInternalFrameActivated() {
		if (!firstInternalframeActivated) {
			firstInternalframeActivated = true;
			requestFocusFor(lastNameField);
		}
	}

	private void requestFocusFor(final JComponent comp) {

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				comp.setRequestFocusEnabled(true);
				comp.requestFocus();
			}
		});
	}
}