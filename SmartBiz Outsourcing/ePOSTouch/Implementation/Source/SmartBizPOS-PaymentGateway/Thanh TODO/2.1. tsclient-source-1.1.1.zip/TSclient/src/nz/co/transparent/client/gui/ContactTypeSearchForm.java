/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 *
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

 /*
  * ContactTypeSearch.java
  *
  * Created on Januari 2, 2004
  */

package nz.co.transparent.client.gui;

import nz.co.transparent.client.gui.util.DialogLayout;
import nz.co.transparent.client.gui.util.InternalFrameOpenedAdapter;

import java.awt.Dimension;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import javax.swing.*;

/**
 *
 * @author John Zoetebier
 *
 */
public class ContactTypeSearchForm extends javax.swing.JInternalFrame {
    
    private static final int FIELD_LENGTH =20;
    
    private Logger log = Logger.getLogger("nz.co.transparent.client.gui");
    private JLabel contactTypeLabel = new JLabel("Contact type:");
    private JTextField contactTypeField = new JTextField();
    private JPanel contentPane = new JPanel();
    private JPanel middlePanel = new JPanel();
    private JPanel dialogPanel = new JPanel();
    private JButton searchButton = new JButton();
    private JToolBar mainToolBar = new JToolBar();
    private ContactTypeTableForm contactTypeTableForm;
    private Map searchMap;
    // End of variables declaration
    
    /** Creates new form ContactTypeSearch */
    public ContactTypeSearchForm() {
        setName("Contact type search");
        setTitle("Contact type search");
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        setPreferredSize(new java.awt.Dimension(600, 500));
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
        setContentPane(contentPane);
        try {
            setSelected(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        //setVisible(true);
        addInternalFrameListener(
                new InternalFrameOpenedAdapter(this, contactTypeField));
        
        searchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Find24.gif")));
        searchButton.setMnemonic(KeyEvent.VK_E);
        searchButton.setToolTipText("Enter one or more of the search fields. Then click me.");
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                searchButton_actionPerformed();
            }
        });
        
        mainToolBar.setBorder(BorderFactory.createEtchedBorder());
        mainToolBar.setFloatable(false);
        mainToolBar.add(Box.createRigidArea(new Dimension(5,0)));
        mainToolBar.add(searchButton);
        
        mainToolBar.add(Box.createHorizontalGlue());	// make buttons left aligned
        contentPane.add(mainToolBar);
        
        dialogPanel.setLayout(new DialogLayout());
        dialogPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        
        dialogPanel.add(contactTypeLabel);
        contactTypeField.setText("");
        contactTypeField.setColumns(FIELD_LENGTH);
        contactTypeField.setToolTipText("Contact type or part of it.");
        contactTypeField.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    searchButton.doClick();
                }
            }
        });
        dialogPanel.add(contactTypeField);
        
        middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.X_AXIS));
        middlePanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(20, 5, 20, 5)));
        middlePanel.add(dialogPanel);
        middlePanel.add(Box.createHorizontalStrut(700));
        
        contentPane.add(middlePanel);
        
        //===========================================
        // Create contactType table form
        //===========================================
        contactTypeTableForm = new ContactTypeTableForm();
        contentPane.add(contactTypeTableForm);
        
        //===========================================
        // Pack
        //===========================================
        pack();
    }
    
    private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
        
        try {
            this.setMaximum(true);
        } catch (java.beans.PropertyVetoException pve) {
            log.warning(pve.getMessage());
        }
    }
    
    private void searchButton_actionPerformed() {
        searchMap = new HashMap();
        searchMap.put("contact_type", contactTypeField.getText());
        contactTypeTableForm.updateTable(searchMap);
    }
}