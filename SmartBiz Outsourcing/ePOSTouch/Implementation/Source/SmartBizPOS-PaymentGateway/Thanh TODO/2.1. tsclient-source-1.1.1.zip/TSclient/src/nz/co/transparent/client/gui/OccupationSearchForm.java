/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 *
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

 /*
  * OccupationSearch.java
  *
  * Created on Januari 3, 2004
  */

package nz.co.transparent.client.gui;

import nz.co.transparent.client.gui.util.DialogLayout;
import nz.co.transparent.client.gui.util.InternalFrameOpenedAdapter;

import java.awt.Dimension;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;

/**
 *
 * @author John Zoetebier
 *
 */
public class OccupationSearchForm extends javax.swing.JInternalFrame {
    
    private static final int FIELD_LENGTH =20;
    
    private JLabel occupationLabel = new JLabel("Occupation:");
    private JTextField occupationField = new JTextField();
    private JPanel contentPane = new JPanel();
    private JPanel middlePanel = new JPanel();
    private JPanel dialogPanel = new JPanel();
    private JButton occupationSearchButton = new JButton();
    private JToolBar mainToolBar = new JToolBar();
    private OccupationTableForm occupationTableForm;
    private Map searchMap;
    // End of variables declaration
    
    /** Creates new form OccupationSearch */
    public OccupationSearchForm() {
        setName("Occupation search");
        setTitle("Occupation search");
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        setPreferredSize(new java.awt.Dimension(600, 500));
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
        setContentPane(contentPane);
        addInternalFrameListener(new InternalFrameOpenedAdapter(this, occupationField));
        
        occupationSearchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Find24.gif")));
        occupationSearchButton.setMnemonic(KeyEvent.VK_E);
        occupationSearchButton.setToolTipText("Enter one or more of the search fields. Then click me.");
        occupationSearchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                occupationSearchButton_actionPerformed();
            }
        });
        
        mainToolBar.setBorder(BorderFactory.createEtchedBorder());
        mainToolBar.setFloatable(false);
        mainToolBar.add(Box.createRigidArea(new Dimension(5,0)));
        mainToolBar.add(occupationSearchButton);
        
        mainToolBar.add(Box.createHorizontalGlue());	// make buttons left aligned
        contentPane.add(mainToolBar);
        
        dialogPanel.setLayout(new DialogLayout());
        dialogPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        
        dialogPanel.add(occupationLabel);
        occupationField.setText("");
        occupationField.setColumns(FIELD_LENGTH);
        occupationField.setToolTipText("Occupation or part of it.");
        occupationField.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    occupationSearchButton.doClick();
                }
            }
        });
        dialogPanel.add(occupationField);
        
        middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.X_AXIS));
        middlePanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(20, 5, 20, 5)));
        middlePanel.add(dialogPanel);
        middlePanel.add(Box.createHorizontalStrut(700));
        
        contentPane.add(middlePanel);
        
        //===========================================
        // Create occupation table form
        //===========================================
        occupationTableForm = new OccupationTableForm();
        contentPane.add(occupationTableForm);
        
        //===========================================
        // Pack
        //===========================================
        pack();
    }
    
    private void occupationSearchButton_actionPerformed() {
        searchMap = new HashMap();
        searchMap.put("occupation", occupationField.getText());
        occupationTableForm.updateTable(searchMap);
    }
}