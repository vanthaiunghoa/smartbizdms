/*
 * Created on Nov 18, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class TestComboBox extends JFrame {
	
	private JComboBox comboBox = new JComboBox();

	public TestComboBox() {
		initComponents();
	}
	
	private void initComponents() {
		
		comboBox.setEditable(true);
		comboBox.addItem("Item 1");
		comboBox.addItem("Item 2");
		comboBox.addItem("Item 3");
		comboBox.addItem("Item 4");
		comboBox.addItem("Item 5");
		comboBox.setSelectedIndex(2);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//util.Message.information(null, "This is actionListener");
				String message;
				message = "Selected index = " + comboBox.getSelectedIndex() +
					"\nSelected value = " + comboBox.getSelectedItem();
				nz.co.transparent.client.util.Messager.information(null, message);
			}
		});
		
		getContentPane().add(comboBox);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500, 400);
		pack();
		show();
	}
	
	

	public static void main(String [] args) {
		
		new TestComboBox();
		
	}
	
}
