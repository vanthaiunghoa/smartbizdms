/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Nov 12, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package nz.co.transparent.client.util;

import java.awt.Component;

import javax.swing.JOptionPane;

/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public final class Messager {
	
	/**
	 * private constructor to prevent creating an instance from this class 
	 */
	private Messager() {
		
	}
	
	/**
	  * Prompts the user with an error message in an alert window.
	  *
	  * @param component Parent component. If no component present, then pass null.
	  * @param msg The message displayed in the error window.
	  */
	public static void exception (Component component, String msg){
		JOptionPane.showConfirmDialog(component, wrapMessage(msg), "Error"
		, JOptionPane.DEFAULT_OPTION
				, JOptionPane.ERROR_MESSAGE);
	}
	
	public static String wrapMessage(String message){

		final int LINE_LENGTH = 100; 
		final int MAX_LINES = 15;
		int lineCount = 0;
		StringBuffer tempBuffer = new StringBuffer();
		int beginIndex = 0;
		int endIndex = 0;
		boolean messageTruncated = false;
		
		if (message == null) {
			return "<null>";
		}
		
		String[] lines = message.split("\n");
		
		for (int i=0; i<lines.length; i++) {
			if (lineCount++ > MAX_LINES) {
				messageTruncated = true;
				break;
			}

			if (lines[i].length() > LINE_LENGTH) {
				// Split line in shorter parts
				beginIndex = 0;

				while (true) {
					if (lineCount++ > MAX_LINES) {
						messageTruncated = true;
						break;
					}

					endIndex = beginIndex + LINE_LENGTH;

					if (endIndex > lines[i].length()) {
						tempBuffer.append(lines[i].substring(beginIndex, lines[i].length()));
						tempBuffer.append("\n");
						break;
					}

					// Get last  blank
					char[] chars = lines[i].substring(beginIndex, endIndex).toCharArray();
					
					for (int k=(chars.length -1); k>=0; k--) {
						if (chars[k] == ' ') {
							endIndex = k;
							break;
						}
					}

					tempBuffer.append(lines[i].substring(beginIndex, endIndex) + "\n");
					beginIndex = endIndex +1;
				}
			} else {
				tempBuffer.append(lines[i] + "\n");
			}
		}

		if (messageTruncated) {
			tempBuffer.append("\n");
			tempBuffer.append("\n=== Message truncated ===");
			tempBuffer.append("\nCheck application log for full message.");
		}
		
		return tempBuffer.toString();
	}
		
	public static void information (Component component, String msg){

		JOptionPane.showConfirmDialog(component, wrapMessage(msg), "Information"
				, JOptionPane.DEFAULT_OPTION
				, JOptionPane.INFORMATION_MESSAGE);
	}

	public static void warning (Component component, String msg){

		JOptionPane.showConfirmDialog(component, wrapMessage(msg), "Warning"
				, JOptionPane.DEFAULT_OPTION
				, JOptionPane.WARNING_MESSAGE);

	}
	
	public static int question (Component component, String msg){

		return JOptionPane.showConfirmDialog(component, wrapMessage(msg), "Question"
				, JOptionPane.YES_NO_OPTION
				, JOptionPane.QUESTION_MESSAGE);
	}
}