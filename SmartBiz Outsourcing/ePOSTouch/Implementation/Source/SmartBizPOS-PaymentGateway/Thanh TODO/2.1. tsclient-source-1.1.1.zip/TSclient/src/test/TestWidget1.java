package test;


/**
 * @author johnz
 */
import java.awt.*;
import javax.swing.*;

public class TestWidget1 extends JFrame {

  public TestWidget1() {

	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	Container content = getContentPane();
	content.setLayout(new GridLayout(1,0));

	String text = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed"+

		   " do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut "+

		   "enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi"+

		   " ut aliquip ex ea commodo consequat. Duis aute irure dolor in "+

		   "reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla"+

		   " pariatur. Excepteur sint occaecat cupidatat non proident, sunt in "+

		   "culpa qui officia deserunt mollit anim id est laborum.";

	JButton jb = new JButton("HI");

	for (int i=0; i<2; i++) {

	  JTextArea jta = new JTextArea(text);

	  jta.setFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,null);
	  jta.setFocusTraversalKeys(KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,null);
	  //jta.setNextFocusableComponent(jb);
	  jta.setLineWrap(true);
	  jta.setWrapStyleWord(true);
	  content.add(new JScrollPane(jta));
	}

	content.add(jb);

	setSize(300,300);

	show();

  }

  public static void main(String args[]) { new TestWidget1(); }

}



  