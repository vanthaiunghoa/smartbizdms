/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * TenderSearch.java
 *
 * Created on Januari 6, 2004
 */

package nz.co.transparent.client.gui;

import nz.co.transparent.client.gui.util.DialogLayout;
import nz.co.transparent.client.gui.util.InternalFrameOpenedAdapter;

import java.awt.Dimension;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;

/**
 * 
 * @author John Zoetebier
 *
 */
public class TenderSearchForm extends javax.swing.JInternalFrame {
    
	private static final int FIELD_LENGTH =20; 
	
	private JLabel tenderLabel = new JLabel("Tender:");
	private JTextField tenderField = new JTextField();
	private JPanel contentPane = new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();
	private JButton tenderSearchButton = new JButton();
	private JToolBar mainToolBar = new JToolBar();
	private TenderTableForm TenderTableForm;
	private Map searchMap;
	// End of variables declaration
    
	/** Creates new form TenderSearch */
	public TenderSearchForm() {
		setName("Tender search");
		setTitle("Tender search");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		setContentPane(contentPane);
		addInternalFrameListener(new InternalFrameOpenedAdapter(this, tenderField));

		tenderSearchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Find24.gif")));
		tenderSearchButton.setMnemonic(KeyEvent.VK_E);
		tenderSearchButton.setToolTipText("Enter one or more of the search fields. Then click me.");
		tenderSearchButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				tenderSearchButton_actionPerformed();
			 }
		});
		
		mainToolBar.setBorder(BorderFactory.createEtchedBorder());
		mainToolBar.setFloatable(false);
		mainToolBar.add(Box.createRigidArea(new Dimension(5,0)));
		mainToolBar.add(tenderSearchButton);

		mainToolBar.add(Box.createHorizontalGlue());	// make buttons left aligned
		contentPane.add(mainToolBar);

		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));

		dialogPanel.add(tenderLabel);
		tenderField.setText("");
		tenderField.setColumns(FIELD_LENGTH);
		tenderField.setToolTipText("Tender or part of it.");
		tenderField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					tenderSearchButton.doClick();
				}
			}
		});
		dialogPanel.add(tenderField);

		middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.X_AXIS));
		middlePanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(20, 5, 20, 5)));
		middlePanel.add(dialogPanel);
		middlePanel.add(Box.createHorizontalStrut(700));

		contentPane.add(middlePanel);

		//===========================================
		// Create Tender table form
		//===========================================
		TenderTableForm = new TenderTableForm();
		contentPane.add(TenderTableForm);
		
		//===========================================
		// Pack
		//===========================================
		pack();
	}

	private void tenderSearchButton_actionPerformed() {
		searchMap = new HashMap();
		searchMap.put("Tender", tenderField.getText());
		TenderTableForm.updateTable(searchMap);
	}
}