/*
 * Created on Jan 28, 2004
 *
 */
package test;

import javax.print.PrintService;
import javax.print.PrintServiceLookup;

/**
 * @author John Zoetebier
 * 
 */
public class TestPrinters {

	/**
	 * 
	 */
	public TestPrinters() {
		super();
	}

	public static void main(String[] args) {


		PrintService[] printServices = PrintServiceLookup.lookupPrintServices(null, null); 
		
		System.out.println("Default print service: " + PrintServiceLookup.lookupDefaultPrintService());
		
		for (int i = 0; i < printServices.length; i++) {
			System.out.println(printServices[i].getName());
		}
		
		
		
	}
}
