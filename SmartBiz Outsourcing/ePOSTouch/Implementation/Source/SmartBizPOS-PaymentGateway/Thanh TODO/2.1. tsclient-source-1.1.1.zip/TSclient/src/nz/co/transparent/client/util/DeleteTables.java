/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Dec 17, 2003
 *  
 */
package nz.co.transparent.client.util;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.apache.commons.dbutils.DbUtils;


import nz.co.transparent.client.db.*;


/**
 * @author johnz
 *  
 */
public class DeleteTables {

	/**
	 *  
	 */
	public DeleteTables() {
		super();
	}

	public static void main(String[] args) {

		Logger log = Logger.getLogger("nz.co.transparent.client.db");
		
		String userName = "";
		String password = "";

		if (args.length == 2) {
			userName = args[0];
			password = args[1];
		} else {
			userName = Configuration.getProperty("login.username","");
			password = Configuration.getProperty("login.password","");
		}

		if (userName.equals("")) {
			throw new RuntimeException("userName must not be empty");
		}
		
		if (password.equals("")) {
			throw new RuntimeException("password must not be empty");
		}

		DataSourceHandler.setPassword(password);
		DataSourceHandler.setUserName(userName);
		DataSource dataSource = DataSourceHandler.getDataSource();
		Connection conn = null;
		ResultSet rsetTables = null;
		ResultSet rsetImportedKeys = null;
		Statement stmt = null;
		DatabaseMetaData metaData = null;
		String msg = null;
		String sql = null;

		try {
			conn = dataSource.getConnection();
			stmt = conn.createStatement();
			metaData = conn.getMetaData();
			String[] tableTypes = {"TABLE"};
			rsetTables = metaData.getTables("", "APP", "%", tableTypes);
			String tableName = null;
			while (rsetTables.next()) {
				tableName = rsetTables.getString("TABLE_NAME");
				System.out.println("TABLE_NAME=" + tableName);
				rsetImportedKeys = metaData.getImportedKeys("","APP", tableName);
						
				while (rsetImportedKeys.next()) {
					System.out.println("   FKTABLE_NAME=" + rsetImportedKeys.getString("FKTABLE_NAME"));
					System.out.println("   FKCOLUMN_NAME=" + rsetImportedKeys.getString("FKCOLUMN_NAME"));
					System.out.println("   FK_NAME=" + rsetImportedKeys.getString("FK_NAME"));
					sql = "ALTER TABLE " + tableName + " DROP CONSTRAINT " + rsetImportedKeys.getString("FK_NAME");
					stmt.execute(sql);
				}
			}
			
			// Now we can delete tables
			rsetTables = metaData.getTables("", "APP", "%", tableTypes);
			while (rsetTables.next()) {
				tableName = rsetTables.getString("TABLE_NAME");
				System.out.println("DROP TABLE = " + tableName);
				sql = "DROP TABLE " + tableName;
				stmt.execute(sql);
			}
		} catch (SQLException se) {
			msg = "SQL error: " + se.getMessage();
			log.warning(msg);
		} finally {
			try {
				DbUtils.close(rsetTables);
				DbUtils.close(rsetImportedKeys);
				DbUtils.close(conn);
			} catch (SQLException se) {
				msg = "SQL error: " + se.getMessage();
				log.warning(msg);
			}
		}
	}
}