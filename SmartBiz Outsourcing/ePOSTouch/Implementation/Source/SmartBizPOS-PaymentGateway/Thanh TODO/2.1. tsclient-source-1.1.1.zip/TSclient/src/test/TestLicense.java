/*
 * Created on Jan 20, 2004
 *
 */
package test;

/**
 * @author John Zoetebier
 * 
 */
public class TestLicense {

	/**
	 * 
	 */
	public TestLicense() {
		super();
	}

	public static void main(String[] args) {
	}
}
