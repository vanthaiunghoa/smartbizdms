/*
 * Created on Dec 15, 2003
 *
 */
package test;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author johnz
 * 
 */
public class TestDateCompare {

	/**
	 * 
	 */
	public TestDateCompare() {
		super();
	}

	public static void main(String[] args) {
		
		Map testMap = new HashMap();
		Date date1 = new Date();
		Date date2 = new Date();
		date2.setTime(date2.getTime() + 10);
		
		testMap.put("date1", date1);
		testMap.put("date2", date2);
		
		if (testMap.get("date1").equals(testMap.get(date2))) {
			System.out.println("Object compare: dates are equal");
		} else {
			System.out.println("Object compare: dates are NOT equal");
		}

		if (date1.equals(date2)) {
			System.out.println("Date compare: dates are equal");
		} else {
			System.out.println("Date compare: dates are NOT equal");
		}
	}
}
