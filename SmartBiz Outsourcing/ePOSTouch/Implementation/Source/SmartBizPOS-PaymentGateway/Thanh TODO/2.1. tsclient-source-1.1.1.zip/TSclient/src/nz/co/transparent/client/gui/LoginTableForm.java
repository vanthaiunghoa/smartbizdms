/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Jan 1, 2004
 *
 */
package nz.co.transparent.client.gui;

/**
 * @author John Zoetebier
 * 
 */
import nz.co.transparent.client.gui.util.GenericUtils;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.*;

import nz.co.transparent.client.util.Messager;

import nz.co.transparent.client.controller.GenericController;
import nz.co.transparent.client.db.ControllerException;

//import nz.co.transparent.client.db.ControllerException;
//
//import util.Configuration;
//import util.Messager;


/**
 * Show table
 * Extends JTable
 * Gets data from search map with {FieldName => FieldValue} pairs
 * 
 * @author John Zoetebier
 *
 */
public class LoginTableForm extends JPanel  {
    
	private static List columnPropertyMapList = new ArrayList();
	private static Map columnPropertyMap;

	static {
		columnPropertyMap = new HashMap(2);
		columnPropertyMap.put("columnName", "user_name");
		columnPropertyMap.put("columnHeader", "User name");
		columnPropertyMapList.add(columnPropertyMap);
		
		columnPropertyMap = new HashMap(2);
		columnPropertyMap.put("columnName", "login_date");
		columnPropertyMap.put("columnHeader", "Login date");
		columnPropertyMapList.add(columnPropertyMap);
		
		columnPropertyMap = new HashMap(2);
		columnPropertyMap.put("columnName", "logoff_date");
		columnPropertyMap.put("columnHeader", "Logoff date");
		columnPropertyMapList.add(columnPropertyMap);
	}		
	

	private JTable table = new JTable ();
	private JPanel panel;
	private JToolBar toolbar = new JToolBar();
	private JButton newButton = new JButton();
	private JButton updateButton = new JButton();
	private JButton deleteButton = new JButton();
	private JScrollPane scrollPane = new JScrollPane();
	private GenericTableModel tableModel = new GenericTableModel(columnPropertyMapList);
	private GenericController genericController = GenericController.getInstance();

	public LoginTableForm() {

		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		toolbar.setBorder(BorderFactory.createEtchedBorder());
		toolbar.setFloatable(false);

		newButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif")));
		newButton.setToolTipText("New login");
		newButton.setMnemonic(KeyEvent.VK_C);
		newButton.setEnabled(false);
		newButton.addActionListener(new NewButtonActionListener());
		
		updateButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Edit24.gif")));
		updateButton.setToolTipText("Update login");
		updateButton.setMnemonic(KeyEvent.VK_U);
		updateButton.setEnabled(false);
		updateButton.addActionListener(new UpdateButtonActionListener());
		
		deleteButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setToolTipText("Delete login");
		deleteButton.setMnemonic(KeyEvent.VK_L);
		deleteButton.setEnabled(false);
		deleteButton.addActionListener(new DeleteButtonActionListener());

		toolbar.add(newButton);
		toolbar.add(Box.createRigidArea(new Dimension(5,0)));
		toolbar.add(updateButton);
		toolbar.add(Box.createRigidArea(new Dimension(5,0)));
		toolbar.add(deleteButton);
		toolbar.add(Box.createGlue());

		panel = new JPanel(new BorderLayout());
		panel.setBorder(BorderFactory.createCompoundBorder(
						BorderFactory.createEtchedBorder(), 
						BorderFactory.createEmptyBorder(5, 5, 5, 5)
						));
		panel.add(toolbar, BorderLayout.NORTH);
		
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.setToolTipText("Select a row, then click on button in toolbar");
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() >= 2) {
					updateButton.doClick();
				}
			}
		});
		
		scrollPane = new JScrollPane(table);
		scrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

		panel.add(scrollPane, BorderLayout.CENTER);
		tableModel = new GenericTableModel(columnPropertyMapList);
		GenericUtils.updateTable(table, tableModel);
		add(panel);
	}
	
	public void updateTable(Map personMap) {
		
		try {
			if (personMap.get("person_id") == null) {
				tableModel = new GenericTableModel(columnPropertyMapList);
			} else {
				List list = genericController.findAllWhere("login", "login_date DESC", "person_id=" + personMap.get("person_id"));
				tableModel.setMapList(list);
			}
			
			GenericUtils.updateTable(table, tableModel);
		} catch (ControllerException ce) {
			Messager.exception(this, "LoginTableForm: Error getting table data\n" + ce.getMessage());
			return;
		}
	}
	
	/**
	 * Action listener for new button
	 * 
	 * @author John Zoetebier
	 *
	 */
	private class NewButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {

//			if (personMap.get("person_id") == null) {
//				Messager.information(getParent(), "Please enter details main form first");
//				return;
//			}
//			
//			form = new LoginForm();
//			form.populateNewForm(personMap);
//			MainFrame.openFrame(form);
		}
	}

	/**
	 * Action listener for update button
	 * 
	 * @author John Zoetebier
	 *
	 */
	private class UpdateButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			
//			// Get loginRoleID from table
//			int index = table.getSelectedRow();
//			if (index < 0) {
//				Messager.information((JFrame) MainFrame.getInstance(), "Please select a row in table");
//				return;
//			}
//
//			Integer loginRoleID = (Integer) table.getValueAt(index, 0);
//			form = new LoginForm();
//			form.populateForm(loginRoleID.intValue());
//			MainFrame.openFrame(form);
		}
	}

	/**
	 * Action listener for delete button
	 * 
	 * @author John Zoetebier
	 *
	 */
	private class DeleteButtonActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
//			// Get loginRoleID from table
//			int index = table.getSelectedRow();
//			if (index < 0) {
//				Messager.information((JFrame) MainFrame.getInstance(), "Please select a row in table");
//				return;
//			}
//
//			if (Messager.question((JFrame) MainFrame.getInstance(), "This will delete this record and all dependent records.\nDo you want to continue ?") != JOptionPane.YES_OPTION) {
//				return;
//			}
//
//			Integer loginRoleID = (Integer) table.getValueAt(index, 0);
//			int maxRecords = Integer.parseInt(Parameter.getParameter("max.records.search", Constants.MAX_RECORDS_SEARCH));
//			StringBuffer maxPassed = new StringBuffer();
//			try {
//				genericController.deleteRecord("login_role", "login_role_id=" + loginRoleID);
//				updateTable(personMap);
//			} catch (ControllerException ce) {
//				String msg = "Temp: error deleting record. " + ce.getMessage();
//				log.warning(msg);
//				Messager.exception(null, msg);
//				return;
//			}
		}
	}
}