/*
 * Created on Jan 26, 2004
 *  
 */
package test;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

/**
 * @author John Zoetebier
 *  
 */
public class TestJOptionPane {

	/**
	 *  
	 */
	public TestJOptionPane() {
		super();
	}

	private static String askPassword() {
		JPasswordField pf = new JPasswordField();
		Object[] message = new Object[] { "Enter password:", pf };
		Object[] options = new String[] { "Ok", "Cancel" };

		return JOptionPane.showInputDialog(null,message);
	}

	private static String askPassword2() {
		JPasswordField pf = new JPasswordField();
		Object[] message = new Object[] { "Enter password:", pf };
		Object[] options = new String[] { "Ok", "Cancel" };

		if (JOptionPane
			.showOptionDialog(
				null,
				message,
				"Password",
				JOptionPane.OK_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE,
				null,
				null,
				null)
			== 0) { // OK
			return String.valueOf(pf.getPassword());
		} else {
			return null; // Cancel
		}
	}

	public static void main(String[] args) {

		System.out.println("Password=" + askPassword());
		System.exit(0);

	}
}
