/*
 * Created on Jan 8, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import java.util.Properties;

/**
 * @author John Zoetebier
 *
 */
public class TestProperties {
	
	public static void main(String[] args) {
		Properties sp = System.getProperties();
		Properties myTable = new Properties(sp);
		myTable.list(System.out);
		
	}
}
