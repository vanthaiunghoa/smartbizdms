/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
package nz.co.transparent.client.report;
import dori.jasper.engine.*;
import dori.jasper.engine.export.*;
import dori.jasper.engine.util.*;
import java.io.*;

import nz.co.transparent.client.util.Configuration;

/**
 *
 */

public class TestReport {

	/**
	 *
	 */
	private static final String TASK_COMPILE = "compile";
	private static final String TASK_FILL = "fill";
	private static final String TASK_PRINT = "print";
	private static final String TASK_PDF = "pdf";
	private static final String TASK_XML = "xml";
	private static final String TASK_XML_EMBED = "xmlEmbed";
	private static final String TASK_HTML = "html";
	private static final String TASK_XLS = "xls";
	private static final String TASK_CSV = "csv";
	private static final String TASK_RUN = "run";

	/**
	 *
	 */
	public static void main(String[] args) {
		String fileName = null;
		String taskName = null;

		if (args.length == 0) {
			usage();
			return;
		}

		int k = 0;
		while (args.length > k) {
			if (args[k].startsWith("-T"))
				taskName = args[k].substring(2);
			if (args[k].startsWith("-F"))
				fileName = args[k].substring(2);

			k++;
		}

		try {
			long start = System.currentTimeMillis();
			if (TASK_COMPILE.equals(taskName)) {
				// Set path for temporary compilation files. This ensures no java file is overriden on folder containing report.xml
				System.setProperty("jasper.reports.compile.temp", Configuration.getProperty("client.dir", "") + "/temp");
				System.setProperty("jasper.reports.compile.keep.java.file", "true");
				JasperCompileManager.compileReportToFile(fileName);
				System.err.println(
					"Compile time : " + (System.currentTimeMillis() - start));
				System.exit(0);
			} else if (TASK_FILL.equals(taskName)) {
				JasperFillManager.fillReportToFile(
					fileName,
					null,
					new JREmptyDataSource());
				System.err.println(
					"Filling time : " + (System.currentTimeMillis() - start));
				System.exit(0);
			} else if (TASK_PRINT.equals(taskName)) {
				JasperPrintManager.printReport(fileName, true);
				System.err.println(
					"Printing time : " + (System.currentTimeMillis() - start));
				System.exit(0);
			} else if (TASK_PDF.equals(taskName)) {
				JasperExportManager.exportReportToPdfFile(fileName);
				System.err.println(
					"PDF creation time : "
						+ (System.currentTimeMillis() - start));
				System.exit(0);
			} else if (TASK_XML.equals(taskName)) {
				JasperExportManager.exportReportToXmlFile(fileName, false);
				System.err.println(
					"XML creation time : "
						+ (System.currentTimeMillis() - start));
				System.exit(0);
			} else if (TASK_XML_EMBED.equals(taskName)) {
				JasperExportManager.exportReportToXmlFile(fileName, true);
				System.err.println(
					"XML creation time : "
						+ (System.currentTimeMillis() - start));
				System.exit(0);
			} else if (TASK_HTML.equals(taskName)) {
				JasperExportManager.exportReportToHtmlFile(fileName);
				System.err.println(
					"HTML creation time : "
						+ (System.currentTimeMillis() - start));
				System.exit(0);
			} else if (TASK_XLS.equals(taskName)) {
				File sourceFile = new File(fileName);

				JasperPrint jasperPrint =
					(JasperPrint) JRLoader.loadObject(sourceFile);

				File destFile =
					new File(
						sourceFile.getParent(),
						jasperPrint.getName() + ".xls");

				JRXlsExporter exporter = new JRXlsExporter();

				exporter.setParameter(
					JRExporterParameter.JASPER_PRINT,
					jasperPrint);
				exporter.setParameter(
					JRExporterParameter.OUTPUT_FILE_NAME,
					destFile.toString());
				exporter.setParameter(
					JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET,
					Boolean.FALSE);

				exporter.exportReport();

				System.err.println(
					"XLS creation time : "
						+ (System.currentTimeMillis() - start));
				System.exit(0);
			} else if (TASK_CSV.equals(taskName)) {
				File sourceFile = new File(fileName);

				JasperPrint jasperPrint =
					(JasperPrint) JRLoader.loadObject(sourceFile);

				File destFile =
					new File(
						sourceFile.getParent(),
						jasperPrint.getName() + ".csv");

				JRCsvExporter exporter = new JRCsvExporter();

				exporter.setParameter(
					JRExporterParameter.JASPER_PRINT,
					jasperPrint);
				exporter.setParameter(
					JRExporterParameter.OUTPUT_FILE_NAME,
					destFile.toString());

				exporter.exportReport();

				System.err.println(
					"CSV creation time : "
						+ (System.currentTimeMillis() - start));
				System.exit(0);
			} else if (TASK_RUN.equals(taskName)) {
				JasperRunManager.runReportToPdfFile(
					fileName,
					null,
					new JREmptyDataSource());
				System.err.println(
					"PDF running time : "
						+ (System.currentTimeMillis() - start));
				System.exit(0);
			} else {
				usage();
				System.exit(0);
			}
		} catch (JRException e) {
			e.printStackTrace();
			System.exit(1);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	/**
	 * 
	 */
	private static void usage() {
		System.out.println("Usage:");
		System.out.println("\tjava <program_name> -T<task_name> -F<file_name>");
		System.out.println(
			"\t<task_name> : compile | fill | print | pdf | xml | xmlEmbed | html | xls | csv | run");
		System.out.println(
			"\t<file_name> : name of input file for task, for example Report.xml");
	}

}