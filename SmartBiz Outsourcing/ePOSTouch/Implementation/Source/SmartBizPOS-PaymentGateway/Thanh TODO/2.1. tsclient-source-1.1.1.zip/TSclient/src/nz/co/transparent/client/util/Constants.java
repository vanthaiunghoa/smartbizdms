/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Nov 15, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package nz.co.transparent.client.util;

/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public interface Constants {
	
	final static String TS_CLIENT_VERSION = "1.1.1";
	final static String DATABASE_CONNECTION_POOL_NAME = "client";	// Connection pool "client"
	final static String DBCP_MAX_ACTIVE="100";
	final static String DBCP_MAX_IDLE="50";
	final static String DBCP_MAX_WAIT="30000";
	final static String DBCP_MIN_IDLE="4";
	final static String FORMAT_SHORT_DATE = "dd/MM/yyyy";
	final static String FORMAT_TIMESTAMP = "yyyy-MM-dd HH:mm:ss.S z";
	final static String JDBC_URL = "jdbc:apache:commons:dbcp:" + DATABASE_CONNECTION_POOL_NAME;	// Connection pool "client"
	final static String JDBC_PORT="9157";
	final static String JDBC_SERVER="localhost";
	final static String MAX_RECORDS_SEARCH = "30";
	final static String REPORT_CARDREPORT_PRINTER= "";
	final static String REPORT_ENVELOPREPORT_PRINTER= "";
	final static String REPORT_ENVELOPREPORT_SENDER_ADDRESS= "";
	final static String SERVER_MODE="embedded";
	final static String SYSTEMDB_ADMIN_GROUP="secure access";
}