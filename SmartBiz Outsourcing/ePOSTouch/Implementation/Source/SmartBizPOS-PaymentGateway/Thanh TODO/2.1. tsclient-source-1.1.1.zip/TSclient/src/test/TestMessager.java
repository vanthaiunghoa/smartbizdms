/*
 * Created on Nov 27, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;


import nz.co.transparent.client.util.Messager;

/**
 * @author johnz
 *
 */
public class TestMessager {

	/**
	 * 
	 */
	public TestMessager() {
	}

	public static void main(String[] args) {

		String message = "Update warning !\n";
		message += "This is a message that exceeds more than 1 line.     Lets see where the line break occurs. It should not split up in the middle of a word.";
		message += "\nThis is next part of the message. Does it go to next line ?";
		System.out.println(Messager.wrapMessage(message));
	}
}
