/*
 * Created on Nov 22, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
import javax.swing.*;
import java.awt.*;

public class TestTabbedPane extends JFrame
{
JTabbedPane tabbedPane;

public TestTabbedPane()
{
tabbedPane = new JTabbedPane();
tabbedPane.setPreferredSize( new Dimension(300, 200) );
getContentPane().add(tabbedPane);

// newTab( "one" );
// newTab( "two" );
// newTab( "three" );
}

private void newTab(String text)
{
JTextArea textArea = new JTextArea( text );
JScrollPane scrollPane = new JScrollPane( textArea );
tabbedPane.addTab( text, scrollPane );
tabbedPane.setSelectedIndex( tabbedPane.getTabCount() - 1 );
textArea.requestFocus();
}

public static void main(String args[])
{
TestTabbedPane frame = new TestTabbedPane();
frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
frame.pack();
frame.setVisible(true);
frame.newTab( "one" );
frame.newTab( "two" );
frame.newTab( "three" );
}
}