/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Nov 14, 2003
 * 
 * To change the template for this generated file go to Window - Preferences -
 * Java - Code Generation - Code and Comments
 */
package nz.co.transparent.client.controller;

import java.sql.*;
import java.util.*;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.DataSourceHandler;
import nz.co.transparent.client.db.FinderException;
import nz.co.transparent.client.db.SQL;

/**
 * @author johnz
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class LoginController {

	// Static variables
	private static Map personMap = new HashMap();
	private static Logger log = Logger.getLogger("nz.co.transparent.client.db");

	static {
		// For testing purposes we set some fields in personMap
		// During testing we bypass the login form,
		// but forms nevertheless use data of the person logged in
		personMap.put("person_id", new Integer(1));
		personMap.put("user_name", "_TEST_");
		personMap.put("first_name", "TEST");
		personMap.put("last_name", "TEST");
	}

	private LoginController() {
	}

	/**
	 * @param userName
	 *                login ID of person
	 * @throws FinderException
	 * @throws ControllerException
	 */
	public static void loginPerson(String userName, String passWordInPlainText)
		throws FinderException, ControllerException {

		// Set username and password once before getting DataSource
		DataSourceHandler.setUserName(userName);
		DataSourceHandler.setPassword(passWordInPlainText);
		DataSource dataSource = DataSourceHandler.getDataSource();
		
		QueryRunner queryRunner = new QueryRunner(dataSource);
		ResultSetHandler rshMap = new MapHandler();
		ResultSetHandler rshList = new MapListHandler();

		try {
			String sql =
				"select * from person" + " where (" + " (user_name=?)" + " )";
			personMap = (Map) queryRunner.query(sql, userName, rshMap);

			if (personMap == null) {
				// Check if this is the first user: admin
				sql = "select * from person";
				//params[1] = PasswordService.encrypt(passWordInPlainText);
				personMap = (Map) queryRunner.query(sql, rshMap);
				
				// Person could not be found, but there are already persons present
				if (personMap != null) {
					throw new FinderException();
				}
				
				// Add admin user
				personMap = new HashMap();
				int uniqueKey = nz.co.transparent.client.db.SQL.getUniqueKey("person", "person_id");
				personMap.put("person_id", new Integer(uniqueKey));
				personMap.put("user_name" , userName);
				personMap.put("comment" , "Added by system on " + new java.util.Date());
				personMap.put("updater_person_id" , new Integer(uniqueKey));
				GenericController genericController = GenericController.getInstance();
				genericController.insertRecord("person", "person_id", personMap);
				
				Map personRoleMap = new HashMap();
				// Add admin
				personRoleMap.put("person_role_id", null);
				personRoleMap.put("person_id", personMap.get("person_id"));
				personRoleMap.put("role_id",new Integer(1));
				personRoleMap.put("updater_person_id",new Integer(0));
				genericController.insertRecord("person_role", "person_role_id", personRoleMap);

				// Add operator
				personRoleMap.put("person_role_id", null);
				personRoleMap.put("role_id",new Integer(2));
				genericController.insertRecord("person_role", "person_role_id", personRoleMap);
				
				// Grant all premission to person table
				sql = "grant ALL on APP.person to " + userName + " with grant option";
				int result = queryRunner.update(sql);
			}

			sql =
				"select role_id from person_role where person_id = "
					+ personMap.get("person_id");
			List personRoleList =
				(List) queryRunner.query(sql, rshList);
			Iterator iterator = personRoleList.iterator();
			Map personRoleMap = null;
			Map roleMap = null;
			Integer roleID = null;
			ArrayList roleList = new ArrayList(personRoleList.size());
			while (iterator.hasNext()) {
				personRoleMap = (Map) iterator.next();
				roleID = (Integer) personRoleMap.get("role_id");
				sql =
					"select role_code from role where role_id = "
						+ roleID.intValue();
				roleMap = (Map) queryRunner.query(sql, rshMap);
				roleList.add(roleMap.get("role_code"));
			}

			personMap.put("role_list", roleList);

			// Update login
			sql =
				"update login"
					+ " set login_date=CURRENT_TIMESTAMP"
					+ " where ("
					+ " (person_id=?)"
					+ " )";

			Integer personID = (Integer) personMap.get("person_id");
			int result = queryRunner.update(sql, personID);

			if (result == 0) {
				sql =
					"insert into login"
						+ " set user_name="
						+ SQL.getUniqueKey("login", "user_name")
						+ " ,person_id=?";
				result = queryRunner.update(sql, personID);
			}

			return;
		} catch (SQLException se) {
			String message =
				"LoginController: SQL Exception: " + se.getMessage();
			log.warning(message);

			if (message.indexOf("Cannot create PoolableConnectionFactory") > -1) {
				throw new FinderException(se);
			} else {
				throw new ControllerException(message);
			}
		}
	}

	/**
	 * Logoff Person
	 */
	public static void logoffPerson() {

		DataSource dataSource = DataSourceHandler.getDataSource();
		QueryRunner queryRunner = new QueryRunner(dataSource);
		ResultSetHandler rshMap = new MapHandler();

		try {
			String sql =
				"update login"
					+ " set logoff_date=CURRENT_TIMESTAMP"
					+ " where ("
					+ " (person_id=?)"
					+ " )";

			Integer personID = (Integer) personMap.get("person_id");
			Object[] params = { personID };
			int result = queryRunner.update(sql, params);
		} catch (SQLException se) {
			String message =
				"LoginController: SQL Exception: " + se.getMessage();
			log.warning(message);
		}
	}

	/**
	 * Return map of person
	 * 
	 * @return Object with field value
	 */
	public static Map getPerson() {
		return personMap;
	}

	/**
	 * Convenience method to get list with role_codes of person logged in
	 * 
	 * @return <code>List</code> with roles
	 */
	public static List getRoleList() {
		return (List) personMap.get("role_list");
	}

	/**
	 * Check if this person has role in role array
	 * 
	 * @param roles
	 * @return <code>boolean</code> : true if person logged in has role
	 */
	public static boolean hasRole(String[] roles) {
		if (roles == null) {
			return false;
		}

		List list = (List) personMap.get("role_list");

		if (list == null) {
			return false;
		}

		for (int i = 0; i < roles.length; i++) {
			if (list.contains(roles[i])) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if this person has role in role array
	 * 
	 * @return boolean
	 */
	public static boolean hasRole(String role) {

		if (role == null) {
			return false;
		}

		String[] roles = { role };
		return hasRole(roles);
	}
}