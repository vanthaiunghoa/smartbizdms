/*
 * Created on Jan 22, 2004
 *
 */
package test;

import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

/**
 * @author John Zoetebier
 * 
 */
public class TestPreferences {

	/**
	 * 
	 */
	public TestPreferences() {
		super();
	}

	public static void main(String[] args) {
		
		byte[] defSender = {' '};
		byte[] senders = Preferences.userRoot().getByteArray("report.envelopreport.send", defSender);

		System.out.println("sender=");
		System.out.println(senders.toString());
		String test = new String(senders);
		System.out.println(test);		
		
		String sender = "Sender name\nSenderAddress";
		senders = new byte[sender.length()];
		
		for (int i=0; i<sender.length(); i++) {
			senders[i] = (byte) sender.charAt(i);
		}
		
		//senders = sender.t
		Preferences.userRoot().putByteArray("report.envelopreport.send", senders);
		
		try {
			Preferences.userRoot().flush();
		} catch (BackingStoreException bse) {
			System.out.println("BackingStoreException: " + bse.getMessage());
		}
		
//		Preferences userPrefs = Preferences.userRoot();
//		System.out.println(userPrefs.get("UserPref1", "UserPref1: stored ??"));
//		userPrefs.put("UserPref1", "This is a test pref for user");
		
		System.out.println("Ready");
	}
}
