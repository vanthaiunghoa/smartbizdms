/*
 * Created on Dec 1, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import nz.co.transparent.client.util.PasswordService;
import nz.co.transparent.client.db.ControllerException;

/**
 * @author johnz
 *
 */
public class TestPasswordService {

	/**
	 * 
	 */
	public TestPasswordService() {
		super();
	}

	public static void main (String [] args) {
		
		String password = new String("person3");
		
		try {
			String passwordEncrypted = PasswordService.encrypt(password);
			System.out.println(passwordEncrypted);
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
		}
	}
	
	
}
