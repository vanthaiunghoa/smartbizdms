/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 *
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

 /*
  * OccupationSearch.java
  *
  * Created on March 17, 2004
  */

package nz.co.transparent.client.gui;

import nz.co.transparent.client.gui.util.DialogLayout;
import nz.co.transparent.client.gui.util.InternalFrameOpenedAdapter;

import java.awt.Dimension;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;

/**
 *
 * @author John Zoetebier
 *
 */
public class InsuranceCompanySearchForm extends javax.swing.JInternalFrame {
    
    private static final int FIELD_LENGTH =20;
    
    private JLabel insuranceCompanyLabel = new JLabel("Insurance Company:");
    private JTextField insuranceCompanyField = new JTextField();
    private JPanel contentPane = new JPanel();
    private JPanel middlePanel = new JPanel();
    private JPanel dialogPanel = new JPanel();
    private JButton insuranceCompanySearchButton = new JButton();
    private JToolBar mainToolBar = new JToolBar();
    private InsuranceCompanyTableForm insuranceCompanyTableForm;
    private Map searchMap;
    // End of variables declaration
    
    /** Creates new form InsuranceCompanySearch */
    public InsuranceCompanySearchForm() {
        setName("Insurance Company search");
        setTitle("Insurance Company search");
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        setPreferredSize(new java.awt.Dimension(600, 500));
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
        setContentPane(contentPane);
        addInternalFrameListener(new InternalFrameOpenedAdapter(this, insuranceCompanyField));
        
        insuranceCompanySearchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Find24.gif")));
        insuranceCompanySearchButton.setMnemonic(KeyEvent.VK_E);
        insuranceCompanySearchButton.setToolTipText("Enter one or more of the search fields. Then click me.");
        insuranceCompanySearchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                insuranceCompanySearchButton_actionPerformed();
            }
        });
        
        mainToolBar.setBorder(BorderFactory.createEtchedBorder());
        mainToolBar.setFloatable(false);
        mainToolBar.add(Box.createRigidArea(new Dimension(5,0)));
        mainToolBar.add(insuranceCompanySearchButton);
        
        mainToolBar.add(Box.createHorizontalGlue());	// make buttons left aligned
        contentPane.add(mainToolBar);
        
        dialogPanel.setLayout(new DialogLayout());
        dialogPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        
        dialogPanel.add(insuranceCompanyLabel);
        insuranceCompanyField.setText("");
        insuranceCompanyField.setColumns(FIELD_LENGTH);
        insuranceCompanyField.setToolTipText("Insurance Company or part of it.");
        insuranceCompanyField.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    insuranceCompanySearchButton.doClick();
                }
            }
        });
        dialogPanel.add(insuranceCompanyField);
        
        middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.X_AXIS));
        middlePanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(20, 5, 20, 5)));
        middlePanel.add(dialogPanel);
        middlePanel.add(Box.createHorizontalStrut(700));
        
        contentPane.add(middlePanel);
        
        //===========================================
        // Create insuranceCompany table form
        //===========================================
        insuranceCompanyTableForm = new InsuranceCompanyTableForm();
        contentPane.add(insuranceCompanyTableForm);
        
        //===========================================
        // Pack
        //===========================================
        pack();
    }
    
    private void insuranceCompanySearchButton_actionPerformed() {
        searchMap = new HashMap();
        searchMap.put("insurance_company", insuranceCompanyField.getText());
        insuranceCompanyTableForm.updateTable(searchMap);
    }
}