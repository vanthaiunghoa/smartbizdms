/*
 * Created on Dec 3, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import nz.co.transparent.client.util.Messager;

import nz.co.transparent.client.db.PoolingDriverHandler;
import nz.co.transparent.client.db.ColumnMetaData;

/**
 * @author johnz
 *
 */
public class TestTableMetaData {

	private static final String[] columnPropertyNames = { 
		"TABLE_CAT", 			// String => table catalog (may be null) 
		"TABLE_SCHEM", 			// String => table schema (may be null) 
		"TABLE_NAME",			// String => table name 
		"COLUMN_NAME", 		// String => column name 
		"DATA_TYPE",				// int => SQL type from java.sql.Types 
		"TYPE_NAME",				// String => Data source dependent type name, for a UDT the type name is fully qualified 
		"COLUMN_SIZE",			//	int => column size. For char or date types this is the maximum number of characters, for numeric or decimal types this is precision. 
		"BUFFER_LENGTH",		// is not used. 
		"DECIMAL_DIGITS",		// int => the number of fractional digits 
		"NUM_PREC_RADIX",	// int => Radix (typically either 10 or 2) 
		"NULLABLE",				// int => is NULL allowed. 
		//		"columnNoNulls",	- might not allow NULL values 
		//		"columnNullable",	- definitely allows NULL values 
		//		"columnNullableUnknown",	- nullability unknown 
		"REMARKS",				// String => comment describing column (may be null) 
		"COLUMN_DEF",			// String => default value (may be null) 
		"SQL_DATA_TYPE",		// int => unused 
		"SQL_DATETIME_SUB",	// int => unused 
		"CHAR_OCTET_LENGTH",	// int => for char types the maximum number of bytes in the column 
		"ORDINAL_POSITION",	// int => index of column in table (starting at 1) 
		"IS_NULLABLE",			// String => "NO" means column definitely does not allow NULL values; "YES" means the column might allow NULL values. An empty string means nobody knows. 
//		"SCOPE_CATLOG",		// String => catalog of table that is the scope of a reference attribute (null if DATA_TYPE isn't REF) 
//		"SCOPE_SCHEMA",		// String => schema of table that is the scope of a reference attribute (null if the DATA_TYPE isn't REF) 
//		"SCOPE_TABLE",			// String => table name that this the scope of a reference attribure (null if the DATA_TYPE isn't REF) 
//		"SOURCE_DATA_TYPE"	// short => source type of a distinct type or user-generated Ref type, SQL type from java.sql.Types (null if DATA_TYPE isn't DISTINCT or user-generated REF)
	};
		
	/**
	 * 
	 */
	public TestTableMetaData() {
		super();
	}

	
	public static void main (String[] args) {

		PoolingDriverHandler databaseConnectionPool = new PoolingDriverHandler();
		java.util.List list = null;

//		try {
//			List columnPropertyList = TableMetaData.getTableColumnProperties("client", "COLUMN_NAME");
//			Iterator iterator = columnPropertyList.iterator();
//			
//			while (iterator.hasNext()) {
//				System.out.println("ColumnName=" + (String) iterator.next());
//			}
//		} catch (SQLException se) {
//			System.out.println("TestTableMetaData ready");
//			return;
//		}
//
//		if (true) {
//			System.out.println("TestTableMetaData ready");
//			return;
//		}
		
		try {
			Date dateStart = new Date();
			Date dateEnd = new Date();
			int max = 1;
			for (int i=0; i<max; i++) {
				dateStart = new Date();
				list = ColumnMetaData.getColumns("client");
				dateEnd = new Date();
				System.out.println("i = " + i);
				System.out.println("   Time passed = " + (dateEnd.getTime() - dateStart.getTime()));

				Iterator iterator = list.iterator();
			
				while (iterator.hasNext()) {
					Map columnPropertyMap = (Map) iterator.next();
					
					System.out.println("Column : " + columnPropertyMap.get("COLUMN_NAME")); 
					for (int j=0; j<columnPropertyNames.length; j++) {
						System.out.println("  " + columnPropertyNames[j] + " = " + columnPropertyMap.get(columnPropertyNames[j])); 
					}
				}
			}
		} catch (SQLException se) {
			Messager.exception(null, se.getMessage());
			return;
		}
		
		System.out.println("TestTableMetaData ready");
	}
	
}
