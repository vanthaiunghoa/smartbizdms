/*
 * Created on Nov 27, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import nz.co.transparent.client.gui.MainFrame;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

import nz.co.transparent.client.util.Messager;

/**
 * @author johnz
 *
 */
public class TestMessager2 extends JFrame {

	/**
	 * 
	 */
	public TestMessager2() {
		super();
		
		JButton button = new JButton("Show message");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String message = "Update warning !\n";
				message += "Changes have been made by an other person or process.\n";
				message += "To override changes, click Yes button.\n";
				message += "To see changes, click No button.";
				int result = Messager.question(null, message);
				Messager.information((JFrame) MainFrame.getInstance(), "Result=" + result);
			}
		});

		Container content = getContentPane();
		content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
		getContentPane().add(button);
		setSize(600,500);
		pack();
		show();
	}

	public static void main(String[] args) {
		new TestMessager2();
	}
}
