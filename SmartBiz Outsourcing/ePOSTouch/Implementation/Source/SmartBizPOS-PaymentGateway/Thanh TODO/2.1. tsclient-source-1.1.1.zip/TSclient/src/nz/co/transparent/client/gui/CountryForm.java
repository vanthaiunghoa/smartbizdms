/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Country.java
 * 
 * Created on Januari 19, 2004
 */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.*;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;

/**
 * @author John Zoetebier
 */
public class CountryForm extends javax.swing.JInternalFrame {

	// Constants
	private static final int FIELD_LENGTH = 14;

	// Private variables
	private Map countryMap = new HashMap();
	private Map personMap = new HashMap();
	private GenericController genericController =
		GenericController.getInstance();

	private JLabel countryIDLabel = new JLabel("Country ID");
	private JLabel countryLabel = new JLabel("Country");
	private JLabel isDefaultLabel = new JLabel("Is default");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	private JLabel dateCreatedLabel = new JLabel("Date created");
	private JLabel dateUpdatedLabel = new JLabel("Date updated");

	private DateFormat timeStampFormat =
		new SimpleDateFormat(Parameter.getParameter("format.timestamp", Constants.FORMAT_TIMESTAMP));

	private JTextField countryIDField = new JTextField();
	private JTextField countryField = new JTextField();
	private JCheckBox isDefaultField = new JCheckBox();
	private JTextField updaterPersonIDField = new JTextField();
	private JFormattedTextField dateCreatedField =
		new JFormattedTextField(timeStampFormat);
	private JFormattedTextField dateUpdatedField =
		new JFormattedTextField(timeStampFormat);

	private JPanel contentPanel = new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();

	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public CountryForm() {

		setName("Country form");
		setTitle("Country form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));

		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);
		addInternalFrameListener(
			new InternalFrameOpenedAdapter(
				this,
				countryField));

		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New country.");
		newButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				newButton_actionPerformed();
			}
		});

		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		saveButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save country.");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(saveButton);

		reloadButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh country.");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		deleteButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete country.");
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				deleteButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setFocusTraversalPolicy(
			new InputOrderFocusTrafersalPolicy());
		dialogPanel.setFocusCycleRoot(true);

		// Dialog fields
		dialogPanel.add(countryIDLabel);
		Dimension fieldDimension =
			new Dimension(200, countryIDLabel.getPreferredSize().height);
		countryIDField.setToolTipText("Generated by system.");
		countryIDField.setEditable(false);
		countryIDField.setColumns(FIELD_LENGTH);
		dialogPanel.add(countryIDField);

		dialogPanel.add(countryLabel);
		dialogPanel.add(countryField);

		dialogPanel.add(isDefaultLabel);
		dialogPanel.add(isDefaultField);

		dialogPanel.add(updaterPersonIDLabel);
		updaterPersonIDField.setEditable(false);
		dialogPanel.add(updaterPersonIDField);

		dialogPanel.add(dateCreatedLabel);
		dateCreatedField.setEditable(false);
		dialogPanel.add(dateCreatedField);

		dialogPanel.add(dateUpdatedLabel);
		dateUpdatedField.setEditable(false);
		dialogPanel.add(dateUpdatedField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));

		// Add dialogPanel to content panel
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);
		pack();
	}

	/**
	 * Populate form using PK countryID
	 * 
	 * @param countryID
	 *                Primary key
	 */
	public void populateForm(int countryID) {

		String msg = null;
		try {
			msg = "CountryForm: Cannot find country: " + countryID;
			countryMap =
				genericController.findWhere(
					"country",
					"country_id=" + countryID);
			Integer personID = (Integer) countryMap.get("updater_person_id");
			personMap = Updater.getUpdater(personID.intValue());
		} catch (ControllerException ce) {
			Messager.exception(this, msg + "\n" + ce.getMessage());
			return;
		} catch (FinderException fe) {
			Messager.exception(this, msg + "\n" + fe.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		countryIDField.setText(
			String.valueOf(countryMap.get("country_id").toString()));
		countryField.setText(countryMap.get("country").toString());
		isDefaultField.setSelected(
			((Boolean) (countryMap.get("is_default"))).booleanValue());
		updaterPersonIDField.setText(personMap.get("user_name").toString());
		dateCreatedField.setValue(countryMap.get("date_created"));
		dateUpdatedField.setValue(countryMap.get("date_updated"));
	}

	/**
	 * Populate new form
	 *  
	 */
	public void populateNewForm() {

		newButton_actionPerformed();
	}

	private void deleteButton_actionPerformed(ActionEvent evt) {
		String msg = null;

		if (countryMap.get("country_id") == null) {
			msg = "New country cannot be deleted";
			Messager.information(this, msg);
			return;
		}

		msg = "Continue to delete country ?";
		if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
			return;
		}

		try {
			Integer countryID = (Integer) countryMap.get("country_id");
			genericController.deleteRecord(
				"country",
				"country_id=" + countryID.intValue());
			newButton_actionPerformed();
		} catch (ControllerException ce) {
			Messager.exception(
				this,
				"CountryForm: Error deleting country.\n" + ce.getMessage());
			return;
		}
	}

	private void newButton_actionPerformed() {

		countryMap.put("country_id", null);
		personMap = LoginController.getPerson();

		GenericUtils.resetInputFields(dialogPanel);
		Map countryMap = null;

		countryIDField.setText(null);
		countryField.setText(null);
		isDefaultField.setSelected(false);
		updaterPersonIDField.setText(
			(String) LoginController.getPerson().get("user_name"));
		dateCreatedField.setValue(new Date());
		dateUpdatedField.setValue(new Date());
	}

	private void saveButton_actionPerformed(ActionEvent evt) {

		if (!validateForm()) {
			return;
		}

		// Store fields in countryMap
		countryMap.put("country_id", countryMap.get("country_id"));
		countryMap.put("country", countryField.getText());
		countryMap.put(
			"is_default",
			Boolean.valueOf(isDefaultField.isSelected()));
		countryMap.put(
			"updater_person_id",
			LoginController.getPerson().get("person_id"));
		countryMap.put("date_created", dateCreatedField.getValue());
		countryMap.put("date_updated", dateUpdatedField.getValue());

		try {
			if (countryIDField.getText().equals("")) {
				countryMap.put("country_id", null); // Generate
				// key
				genericController.insertRecord(
					"country",
					"country_id",
					countryMap);
			} else {
				// Cast to Integer, otherwise record lookup and update will
				// fail
				countryMap.put(
					"country_id",
					Integer.valueOf(countryIDField.getText()));
				genericController.updateRecord(
					"country",
					"country_id",
					countryMap);
			}

			Integer countryID = (Integer) countryMap.get("country_id");
			// If is_default has been set, switch off any other default
			genericController.switchOffOtherDefault(
				"country",
				"country_id",
				countryID,
				isDefaultField.isSelected());
			populateForm(countryID.intValue());
		} catch (UpdaterException ue) {
			String message = "Update warning !\n";
			message
				+= "Changes have been made by an other person or process.\n";
			message += "Form will be refreshed with latest values";
			Messager.warning(this, message);
			this.populateForm(
				Integer.parseInt(countryMap.get("country_id").toString()));
		} catch (ControllerException ce) {
			Messager.exception(this, "Error: " + ce.getMessage());
		}
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogPanel);

		if (countryField.getText().equals("")) {
			countryField.setBackground(Color.YELLOW);
			countryField.setToolTipText("Please enter country");
			countryField.requestFocus();
			validationOk = false;
		}

		return validationOk;
	}

	private void reloadButton_actionPerformed(ActionEvent evt) {
		Integer countryID = (Integer) countryMap.get("country_id");

		if (countryID == null) {
			this.newButton_actionPerformed();
		} else {
			this.populateForm(countryID.intValue());
		}
	}
}