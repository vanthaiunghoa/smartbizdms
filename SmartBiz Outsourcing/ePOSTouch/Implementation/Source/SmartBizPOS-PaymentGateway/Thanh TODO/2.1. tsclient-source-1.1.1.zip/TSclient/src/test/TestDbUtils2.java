/*
 * Created on Dec 13, 2003
 *
 */
package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Map;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.MapHandler;

import nz.co.transparent.client.util.Constants;

/**
 * @author johnz
 * 
 */
public class TestDbUtils2 {

	public TestDbUtils2() {
		super();
	}
	
	public void go() {
		
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(Constants.JDBC_URL);
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}
		
		QueryRunner runner = new QueryRunner();
		ResultSetHandler rsh = new MapHandler();
		String sql = null;
		Map clientMap = null;
		Object obj = null;
		
		try {
			sql = "delete from Client where (ClientID=40)";
			obj = runner.query(conn, sql, null, rsh);
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}
		
		try {
			sql = "select * from Client where (ClientID=40)";
			clientMap = (Map) runner.query(conn, sql, null, rsh);
			DbUtils.close(conn);
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}

		System.out.println("LastName = " + clientMap.get("lastname"));
	}

	public static void main(String[] args) {
		new TestDbUtils2().go();
	}
}
