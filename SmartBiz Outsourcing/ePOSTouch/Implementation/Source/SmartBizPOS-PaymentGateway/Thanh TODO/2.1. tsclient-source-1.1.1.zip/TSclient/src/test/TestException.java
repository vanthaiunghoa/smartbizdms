/*
 * Created on Nov 30, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.MapHandler;

import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.DataSourceHandler;

/**
 * @author johnz
 *
 */
public class TestException {

	private Logger log = Logger.getLogger("nz.co.transparent.client.db");
	private DataSource dataSource = DataSourceHandler.getDataSource();

	/**
	 * 
	 */
	public TestException() {
		super();
	}
	
	public void updateRecord(String tableName, String primaryKeyName, Map columnMap)  
	throws ControllerException  {
		
		Connection conn = null;
		QueryRunner queryRunner = new QueryRunner(dataSource);
		ResultSetHandler rsh = new MapHandler();
		String sql = null;

		try {
			conn = dataSource.getConnection();
			conn.setAutoCommit(false);	// Start transaction
		} catch (SQLException se) {
			log.warning("SQL Exception: " + se.getMessage());
			try {
				conn.rollback();
			} catch (SQLException se2) {
				log.warning("SQL Exception: " + se2.getMessage());
				throw new ControllerException(se2);
			}
		} finally {
			try {
				DbUtils.close(conn);
			} catch (SQLException se3) {
				log.warning("SQL Exception: " + se3.getMessage());
				throw new ControllerException(se3);
			}
		}
	}

	public static void main(String [] args) 
		throws Exception {
		
		System.out.println("Start");
		if (true) {
			throw new Exception("This is a test");
		}
		
		System.out.println("End");
	}
}
