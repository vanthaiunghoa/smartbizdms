/*
 * Created on Dec 13, 2003
 *
 */
package test;

import nz.co.transparent.client.util.Configuration;

/**
 * @author johnz
 * 
 */
public class TestConfiguration {

	/**
	 * 
	 */
	public TestConfiguration() {
		super();
	}

	public static void main(String[] args) {
		
		System.out.println("server.mode=" + Configuration.getProperty("server.mode", "unknown"));
		System.out.println("client.dir=" + Configuration.getProperty("client.dir", "unknown"));
		Configuration.storeConfiguration();
		System.out.println("Ready");
	}
}
