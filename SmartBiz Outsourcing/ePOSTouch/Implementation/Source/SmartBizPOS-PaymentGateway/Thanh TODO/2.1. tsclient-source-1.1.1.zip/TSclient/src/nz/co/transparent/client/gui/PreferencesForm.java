/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
* Preferences.java
* 
* Created on January 28, 2004
*/

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.logging.Logger;

import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.swing.*;

import nz.co.transparent.client.util.Configuration;
import nz.co.transparent.client.util.Messager;

import nz.co.transparent.client.controller.GenericController;

/**
 * @author John Zoetebier
 */
public class PreferencesForm extends JInternalFrame {

	// Constants
	private static final int FIELD_LENGTH = 14;

	// Private variables
	private Logger log = Logger.getLogger("nz.co.transparent.client.gui");
	private GenericController genericController =
		GenericController.getInstance();

	private List printerList;
	private JLabel cardReportPrinterLabel = new JLabel("Card report printer");
	private JLabel envelopReportPrinterLabel =
		new JLabel("Envelop report printer");
	private JLabel envelopReportSenderLabel =
		new JLabel("Envelop report sender");
	private JLabel serverModeLabel = new JLabel("Server mode");
	private JLabel serverNameLabel = new JLabel("Server name");
	private JLabel serverPortLabel = new JLabel("Server port");

	private JComboBox cardReportPrinterField = new JComboBox();
	private JComboBox envelopReportPrinterField = new JComboBox();
	private JTextArea envelopReportSenderField = new JTextArea(4, FIELD_LENGTH);
	private JRadioButton serverModeField = new JRadioButton("Server");
	private JRadioButton embeddedModeField = new JRadioButton("Embedded");
	private JTextField serverNameField = new JTextField();
	private JTextField serverPortField = new JTextField();

	private JPanel contentPanel = new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();

	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();

	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public PreferencesForm() {
		initComponents();
	}

	/**
	 * This method is called from within the constructor to initialize the
	 * form.
	 */
	private void initComponents() {

		setName("Preferences form");
		setTitle("Preferences form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);
		addInternalFrameListener(
			new InternalFrameOpenedAdapter(this, cardReportPrinterField));

		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		saveButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save preferences.");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(saveButton);

		reloadButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh preferences.");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setFocusTraversalPolicy(
			new InputOrderFocusTrafersalPolicy());
		dialogPanel.setFocusCycleRoot(true);
		// This will force focus go down the colum

		// Dialog fields
		String tooltip =
			"Selected printer will become default printer for card report";
		dialogPanel.add(cardReportPrinterLabel);
		cardReportPrinterLabel.setToolTipText(tooltip);
		cardReportPrinterField.setEditable(false);
		dialogPanel.add(cardReportPrinterField);

		dialogPanel.add(envelopReportPrinterLabel);
		tooltip = "Selected printer will become default printer for envelop";
		envelopReportPrinterLabel.setToolTipText(tooltip);
		envelopReportPrinterField.setEditable(false);
		dialogPanel.add(envelopReportPrinterField);

		dialogPanel.add(envelopReportSenderLabel);
		tooltip =
			"Hit enter key to go to next line. Use tab key to go to next field.";
		envelopReportSenderLabel.setToolTipText(tooltip);
		envelopReportSenderField.setLineWrap(true);
		envelopReportSenderField.setWrapStyleWord(true); // wrap
		// only
		// on
		// word boundary
		// Ensure tabs are handled by focus manager
		envelopReportSenderField.setFocusTraversalKeys(
			KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,
			null);
		envelopReportSenderField.setFocusTraversalKeys(
			KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,
			null);

		JScrollPane envelopReportsenderScrollPane =
			new JScrollPane(envelopReportSenderField);
		dialogPanel.add(envelopReportsenderScrollPane);

		serverModeField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				serverNameField.setEnabled(true);
				serverPortField.setEnabled(true);
			}
		});

		embeddedModeField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				serverNameField.setEnabled(false);
				serverPortField.setEnabled(false);
			}
		});

		dialogPanel.add(serverModeLabel);
		tooltip =
			"Consult your administrator. Select server of database server runs in server mode. Otherwise select embeeeded mode";
		serverModeLabel.setToolTipText(tooltip);
		// Put server mode buttons in buttn group
		ButtonGroup serverModebuttonGroup = new ButtonGroup();
		serverModebuttonGroup.add(serverModeField);
		serverModebuttonGroup.add(embeddedModeField);
		JPanel radioPanel = new JPanel(new GridLayout(0, 1));
		radioPanel.add(serverModeField);
		radioPanel.add(embeddedModeField);
		dialogPanel.add(radioPanel);

		tooltip = "Name or IP address of server";
		serverNameLabel.setToolTipText(tooltip);
		dialogPanel.add(serverNameLabel);
		dialogPanel.add(serverNameField);

		tooltip = "Port number of server";
		serverPortLabel.setToolTipText(tooltip);
		dialogPanel.add(serverPortLabel);
		dialogPanel.add(serverPortField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));

		// Add dialogPanel to content panel
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);

		pack();
	}

	/**
	 * Populate form using configuration settings
	 *  
	 */
	public void populateForm() {

		GenericUtils.resetInputFields(dialogPanel);

		// Get list of printer
		PrintService[] printServices =
			PrintServiceLookup.lookupPrintServices(null, null);
		String cardReportPrinter =
			Configuration.getDecodedProperty("report.cardreport.printer", "");
			
		for (int i = 0; i < printServices.length; i++) {
			cardReportPrinterField.addItem(printServices[i].getName());

			if (cardReportPrinter.equals(printServices[i].getName())) {
				cardReportPrinterField.setSelectedIndex(i);
			}
		}

		String envelopReportPrinter =
			Configuration.getDecodedProperty("report.envelopreport.printer", "");
		for (int i = 0; i < printServices.length; i++) {
			envelopReportPrinterField.addItem(printServices[i].getName());

			if (envelopReportPrinter.equals(printServices[i].getName())) {
				envelopReportPrinterField.setSelectedIndex(i);
			}
		}

		envelopReportSenderField.setText(
			Configuration.getDecodedProperty(
				"report.envelopreport.sender.address",
				""));
		serverNameField.setText(
			Configuration.getProperty("server.name", "localhost"));
		serverPortField.setText(
			Configuration.getProperty("server.port", "9157"));

		// Set server mode

		if (Configuration
			.getProperty("server.mode", "embedded")
			.equals("embedded")) {
			embeddedModeField.setSelected(true);
			serverModeField.setSelected(false);
			serverNameField.setEnabled(false);
			serverPortField.setEnabled(false);
		} else {
			embeddedModeField.setSelected(false);
			serverModeField.setSelected(true);
			serverNameField.setEnabled(true);
			serverPortField.setEnabled(true);
		}
	}

	private void saveButton_actionPerformed(ActionEvent evt) {

		if (!validateForm()) {
			return;
		}

		if (serverModeField.isSelected()) {
			if (Configuration
				.getProperty("server.mode", "")
				.toString()
				.equals("embedded")) {
				Messager.information(
					this,
					"Please exit application and login again");
			}
		} else {
			if (Configuration
				.getProperty("server.mode", "")
				.toString()
				.equals("server")) {
				Messager.information(
					this,
					"Please exit application and login again");
			}
		}

		// Printer must be encode as name can have special characters like "\"
		Configuration.setEncodedProperty(
			"report.cardreport.printer",
			cardReportPrinterField.getSelectedItem().toString());
		Configuration.setEncodedProperty(
			"report.envelopreport.printer",
			envelopReportPrinterField.getSelectedItem().toString());
		Configuration.setEncodedProperty(
			"report.envelopreport.sender.address",
			envelopReportSenderField.getText());
		Configuration.setProperty(
			"server.mode",
			(serverModeField.isSelected()) ? "server" : "embedded");
		Configuration.setProperty("server.name", serverNameField.getText());
		Configuration.setProperty("server.port", serverPortField.getText());
		Configuration.storeConfiguration();
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogPanel);

		try {
			Integer serverPort = Integer.valueOf(serverPortField.getText());
		} catch (NumberFormatException e) {
			serverPortField.setBackground(Color.YELLOW);
			serverPortField.setToolTipText(
				"Please enter numeric value for server port");
			serverPortField.requestFocus();
			validationOk = false;
		}

		return validationOk;
	}

	private void reloadButton_actionPerformed(ActionEvent evt) {
		populateForm();
	}
}