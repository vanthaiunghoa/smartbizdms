/*
 * Created on Dec 6, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;


import javax.swing.*;
import java.awt.*;

public class LongMenu extends JFrame
{
    public LongMenu()
    {
        super("Displaying Long Menus");
        JMenuBar menuBar = new JMenuBar();
        this.setJMenuBar(menuBar);
        JMenu bigMenu = new JMenu("bigMenu");
        menuBar.add(bigMenu);

        // specify a layout manager for the menu
        // Uncomment the next two lines to use the layout manager
        GridLayout menuGrid = new GridLayout(25,4);   
        bigMenu.getPopupMenu().setLayout(menuGrid); 
        // add 100 menu items to both menus
        for (int i = 1; i < 101; i++)
        {
            JMenuItem bigMenuItem = new JMenuItem("bigMenuItem " + i);
            bigMenu.add(bigMenuItem);
        }
    }
    public static void main(String[] args)
    {
        LongMenu frame = new LongMenu();
        frame.setSize(250, 200);
        frame.setLocation(200, 300);
        frame.setVisible(true);
    }
}