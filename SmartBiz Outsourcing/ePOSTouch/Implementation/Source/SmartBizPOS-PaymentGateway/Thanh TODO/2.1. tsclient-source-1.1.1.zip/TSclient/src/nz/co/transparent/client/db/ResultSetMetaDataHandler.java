/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Dec 14, 2003
 *
 */
package nz.co.transparent.client.db;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.ResultSetHandler;

/**
 * @author John Zoetebier
 * 
 */
public class ResultSetMetaDataHandler implements ResultSetHandler {

	/**
	 * 
	 */
	public ResultSetMetaDataHandler() {
		super();
	}

	/* (non-Javadoc)
	 * @see org.apache.commons.dbutils.ResultSetHandler#handle(java.sql.ResultSet)
	 */
	public Object handle(ResultSet rs) throws SQLException {
		
		try {
			List columnList = new ArrayList();
			Map columnPropertyMap = null;
			String columnPropterty = null;
			ResultSetMetaData metaData = rs.getMetaData();
			for (int i = 1; i <= metaData.getColumnCount(); i++) {
				columnPropertyMap = new HashMap(2);
				columnPropertyMap.put("catalog_name", metaData.getCatalogName(i));
				columnPropertyMap.put("column_class_name", metaData.getColumnClassName(i));
				columnPropertyMap.put("column_label", metaData.getColumnLabel(i));
				columnPropertyMap.put("column_name", metaData.getColumnName(i));
				columnPropertyMap.put("column_type_name", metaData.getColumnTypeName(i));
				columnPropertyMap.put("schema_name", metaData.getSchemaName(i));
				columnPropertyMap.put("table_name", metaData.getTableName(i));
				columnPropertyMap.put("column_display_size", new Integer(metaData.getColumnDisplaySize(i)));
				columnPropertyMap.put("column_type", new Integer(metaData.getColumnType(i)));
				columnPropertyMap.put("precision", new Integer(metaData.getPrecision(i)));
				columnPropertyMap.put("scale", new Integer(metaData.getScale(i)));
				columnList.add(columnPropertyMap);
			}
			
			return columnList;
		} catch (SQLException se) {
			String msg = "SQL error: " + se.getMessage();
			throw new SQLException(msg);
		}
	}
}