/*
 * Created on Nov 25, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;


import java.sql.*;

import nz.co.transparent.client.db.PoolingDriverHandler;
import nz.co.transparent.client.util.Constants;

/**
 * @author johnz
 *
 */
public class TestSQL {

	/**
	 * 
	 */
	public TestSQL() {
		super();
	}

	private void go() {
		
		PoolingDriverHandler databaseConnectionPool = new PoolingDriverHandler("client");
		Connection conn;
		
		try {
			conn = DriverManager.getConnection(Constants.JDBC_URL);
			conn.setAutoCommit(false);
		} catch (SQLException se) {
			System.out.println("Cannot get SQL connection");
			return;
		}
		
		int countRows = 0 ;
		Statement stmt = null;
		String sql;
		sql = "update Client" +
				" set DateUpdated = CURRENT_TIMESTAMP " +
				" where(ClientID=1)";		
		try {
			stmt = conn.createStatement();
			countRows = stmt.executeUpdate(sql);
			conn.commit();
		} catch (SQLException se) {
			System.out.println("Update failed: " + se.getMessage());
			try {
				conn.rollback();
			} catch (SQLException se2) {
				System.out.println("Rollback failed: " + se2.getMessage());
			}
		}
		
		try {
			stmt.close();
			conn.close();
		} catch (SQLException se) {
			System.out.println("Close failed: " + se.getMessage());
		}
		
		System.out.println("Rows affected: " + countRows);
		System.out.println("TestSQL: ready");

	}
	
	public static void main(String[] args) {
		new TestSQL().go();
	}
}
