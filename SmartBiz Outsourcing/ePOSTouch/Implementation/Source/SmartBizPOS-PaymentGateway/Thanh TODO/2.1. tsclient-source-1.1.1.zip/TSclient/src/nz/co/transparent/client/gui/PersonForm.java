/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Person.java
 *
 * Created on November 29, 2003, 14:08 PM
 */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.KeyboardFocusManager;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

import javax.swing.*;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;


/**
 *
 * @author  John Zoetebier
 */
public class PersonForm extends javax.swing.JInternalFrame {

	// Constants
	private static final int FIELD_LENGTH = 14;
	private static final int FIELD_LENGTH_SHORT = 13;

	// Private variables
	private Map personMap = new HashMap();
	private Map updaterMap = new HashMap();
	private Logger log = Logger.getLogger("nz.co.transparent.client.gui");
	private GenericController genericController = GenericController.getInstance();
	private SystemDBController systemController = SystemDBController.getInstance();
	
	private JLabel personIDLabel = new JLabel("Person ID");
	private JLabel userNameLabel = new JLabel("User name");
	private JLabel password1Label = new JLabel("Password");
	private JLabel password2Label = new JLabel("Password again");
	private JLabel firstNameLabel = new JLabel("First name");
	private JLabel lastNameLabel = new JLabel("Last name");
	private JLabel address1Label = new JLabel("Address 1");
	private JLabel address2Label = new JLabel("Address 2");
	private JLabel suburbLabel = new JLabel("Suburb");
	private JLabel cityLabel = new JLabel("City");
	private JLabel dateOfBirthLabel = new JLabel("Date of birth");
	private JLabel commentLabel = new JLabel("Comment");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	private JLabel dateCreatedLabel = new JLabel("Date created");
	private JLabel dateUpdatedLabel = new JLabel("Date updated");
	
	private DateFormat shortDateFormat = new SimpleDateFormat(Parameter.getParameter("format.shortdate", Constants.FORMAT_SHORT_DATE));
	private DateFormat timeStampFormat = new SimpleDateFormat(Parameter.getParameter("format.timestamp", Constants.FORMAT_TIMESTAMP));

	private JTextField personIDField = new JTextField();
	private JTextField userNameField = new JTextField();
	private JPasswordField password1Field = new JPasswordField();
	private JPasswordField password2Field = new JPasswordField();
	private JTextField firstNameField = new JTextField();
	private JTextField lastNameField = new JTextField();
	private JTextField address1Field = new JTextField();
	private JTextField address2Field = new JTextField();
	private JTextField suburbField = new JTextField();
	private JTextField cityField = new JTextField();
	private JFormattedTextField dateOfBirthField = new JFormattedTextField(shortDateFormat);
	private JTextArea commentField = new JTextArea(4, FIELD_LENGTH);
	private JTextField updaterPersonIDField = new JTextField();
	private JFormattedTextField dateCreatedField = new JFormattedTextField(timeStampFormat);
	private JFormattedTextField dateUpdatedField = new JFormattedTextField(timeStampFormat);
	
	private JPanel contentPane = new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dialogForm1 = new JPanel();
	private JPanel dialogForm2 = new JPanel();

	private JToolBar toolbarMain = new JToolBar();
	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();

	private JTabbedPane tabbedPane = new JTabbedPane(SwingConstants.TOP, JTabbedPane.WRAP_TAB_LAYOUT);
	private PersonRoleTableForm personRoleTableForm;
	private LoginTableForm loginTableForm;

	/** Creates new PersonForm */
	public PersonForm() {
		initComponents();
	}
    
	/** This method is called from within the constructor to
	 * initialize the form.
	 */
	private void initComponents() {
		
		setName("Person form");
		setTitle("Person form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		setContentPane(contentPane);
		try {
			setSelected(true);
		} catch (java.beans.PropertyVetoException e1) {
			e1.printStackTrace();
		}

		addInternalFrameListener(new InternalFrameOpenedAdapter(this, userNameField));
						
		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New person.");
		newButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				newButton_actionPerformed();
			 }
		});
		
		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		saveButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save person.");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(saveButton);

		reloadButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh person.");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		deleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete person.");
		deleteButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				deleteButton_actionPerformed(evt);
			 }
		});
		
		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));
		
		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPane.add(toolbarMain);

		dialogForm1.setLayout(new DialogLayout());
		dialogForm2.setLayout(new DialogLayout());

		// Setup dialog form
		dialogForm1.add(personIDLabel);
		personIDField.setColumns(FIELD_LENGTH);
		personIDField.setToolTipText("Generated by system.");
		personIDField.setEditable(false);
		dialogForm1.add(personIDField);

		dialogForm1.add(userNameLabel);
		userNameField.setColumns(FIELD_LENGTH);
		dialogForm1.add(userNameField);

		dialogForm1.add(password1Label);
		password1Field.setColumns(FIELD_LENGTH);
		dialogForm1.add(password1Field);

		dialogForm1.add(password2Label);
		password2Field.setColumns(FIELD_LENGTH);
		dialogForm1.add(password2Field);

		dialogForm1.add(firstNameLabel);
		firstNameField.setColumns(FIELD_LENGTH);
		dialogForm1.add(firstNameField);

		dialogForm1.add(lastNameLabel);
		lastNameField.setColumns(FIELD_LENGTH);
		Dimension fieldDimension = lastNameField.getPreferredSize();
		dialogForm1.add(lastNameField);

		dialogForm1.add(address1Label);
		address1Field.setColumns(FIELD_LENGTH);
		dialogForm1.add(address1Field);

		dialogForm1.add(address2Label);
		address2Field.setColumns(FIELD_LENGTH);
		dialogForm1.add(address2Field );
		
		dialogForm1.add(suburbLabel);
		suburbField.setColumns(FIELD_LENGTH);
		//suburbField.setNextFocusableComponent(cityField);
		dialogForm1.add(suburbField);
		
		dialogForm2.add(cityLabel);
		cityField.setColumns(FIELD_LENGTH);
		dialogForm2.add(cityField);

		dialogForm2.add(dateOfBirthLabel);
		dateOfBirthField.setColumns(FIELD_LENGTH);
		dialogForm2.add(dateOfBirthField);

		dialogForm2.add(commentLabel);
		commentField.setLineWrap(true);
		commentField.setWrapStyleWord(true);	// wrap only on word boundary
		// Ensure tabs are handled by focus manager
		commentField.setFocusTraversalKeys(
				KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,null);
		commentField.setFocusTraversalKeys(
			KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,null);
		 
		JScrollPane commentScrollPane = new JScrollPane(commentField);
		dialogForm2.add(commentScrollPane);

		dialogForm2.add(updaterPersonIDLabel);
		updaterPersonIDField.setColumns(FIELD_LENGTH_SHORT);
		updaterPersonIDField.setEditable(false);
		dialogForm2.add(updaterPersonIDField);

		dialogForm2.add(dateCreatedLabel);
		dateCreatedField.setColumns(FIELD_LENGTH_SHORT);
		dateCreatedField.setEditable(false);
		dialogForm2.add(dateCreatedField);

		dialogForm2.add(dateUpdatedLabel);
		dateUpdatedField.setColumns(FIELD_LENGTH_SHORT);
		dateUpdatedField.setEditable(false);
		dialogForm2.add(dateUpdatedField);

		// Add dialogForm to content panel 
		middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.X_AXIS));
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
		middlePanel.setFocusCycleRoot(true);
		middlePanel.setFocusTraversalPolicy(new InputOrderFocusTrafersalPolicy());
		middlePanel.add(dialogForm1);
		middlePanel.add(Box.createHorizontalStrut(10));
		middlePanel.add(dialogForm2);
		middlePanel.add(Box.createHorizontalStrut(500));
		
		contentPane.add(middlePanel);

		//===========================================
		// Create person role panel
		//===========================================
		personRoleTableForm = new PersonRoleTableForm();
		tabbedPane.addTab("Role", personRoleTableForm);

		//===========================================
		// Create login panel
		//===========================================
		loginTableForm = new LoginTableForm();
		tabbedPane.addTab("Login", loginTableForm);
		
		//===========================================
		// Add tabbed pane to content pane
		//===========================================
		contentPane.add(tabbedPane);
		pack();
	}

	/**
	 * Populate form using PK person_id
	 * @param personID PK person_id
	 */
	public void populateForm(int personID) {

		String msg = null;
		try {
			msg = "PersonForm: Cannot find person: " + personID;
			personMap = genericController.findWhere("person", "person_id=" + personID);
			Integer updaterID = (Integer) personMap.get("updater_person_id");
			updaterMap = Updater.getUpdater(updaterID.intValue());
		} catch (ControllerException ce) {
			Messager.exception(this, msg + "\n" + ce.getMessage());
			return;
		} catch (FinderException fe) {
			Messager.exception(this, msg  + "\n" + fe.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogForm1);
		personIDField.setText(GenericUtils.setText(personMap.get("person_id")));
		userNameField.setText(GenericUtils.setText(personMap.get("user_name")));
		password1Field.setText("");
		password2Field.setText("");
		firstNameField.setText(GenericUtils.setText(personMap.get("first_name")));
		lastNameField.setText(GenericUtils.setText(personMap.get("last_name")));
		address1Field.setText(GenericUtils.setText(personMap.get("address1")));
		address2Field.setText(GenericUtils.setText(personMap.get("address2")));
		suburbField.setText(GenericUtils.setText(personMap.get("suburb")));
		cityField.setText(GenericUtils.setText(personMap.get("city")));
		dateOfBirthField.setValue(personMap.get("date_of_birth"));
		commentField.setText(GenericUtils.setText(personMap.get("comment")));
		updaterPersonIDField.setText(GenericUtils.setText(updaterMap.get("user_name")));
		dateCreatedField.setValue(personMap.get("date_created"));
		dateUpdatedField.setValue(personMap.get("date_updated"));
		
		// Set table models
		personRoleTableForm.updateTable(personMap);
		loginTableForm.updateTable(personMap);
	}
	
	/**
	 * Populate new form
	 * 
	 */
	public void populateNewForm() {

		newButton_actionPerformed();
	}
	
	private void deleteButton_actionPerformed(ActionEvent evt) {
		String msg = null;

		if (personMap.get("person_id") == null) {
			msg = "New person cannot be deleted";
			Messager.information(this, msg);
			return;
		}

		msg = "Continue to delete person and person roles ?";
		if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
			return;
		}
			
		Integer personID = null;
		try {
			personID = (Integer) personMap.get("person_id");
			genericController.deleteRecord("person", "person_id=" + personID.intValue());
			genericController.revokeAllPermissions(personMap.get("user_name").toString());
			systemController.dropUser(personMap.get("user_name").toString());
			newButton_actionPerformed();
		} catch (ControllerException ce) {
			Messager.exception(this, "PersonForm: Error getting person data" + ce.getMessage());
			return;
		}
	}

	private void newButton_actionPerformed() {

		personMap.put("person_id", null);
		updaterMap = LoginController.getPerson();
		GenericUtils.resetInputFields(dialogForm1);
		personIDField.setText(null);
		userNameField.setText(null);
		password1Field.setText(null);
		password2Field.setText(null);
		firstNameField.setText(null);
		lastNameField.setText(null);
		address1Field.setText(null);
		address2Field.setText(null);
		suburbField.setText(null);
		cityField.setText(null);
		dateOfBirthField.setValue(null);
		String dateFormat = Parameter.getParameter("format.shortdate", Constants.FORMAT_SHORT_DATE);
		dateFormat = dateFormat.toLowerCase();
		dateOfBirthField.setToolTipText("Date format: " + dateFormat);
		dateOfBirthField.setText(null);
		commentField.setText(null);
		updaterPersonIDField.setText((String) LoginController.getPerson().get("user_name"));
		dateCreatedField.setValue(new Date());
		dateUpdatedField.setValue(new Date());
		
		// Set table models
		personRoleTableForm.updateTable(personMap);
		loginTableForm.updateTable(personMap);
	}

	private void saveButton_actionPerformed(ActionEvent evt) {
		
		if (!validateForm()) {
			return;
		}
		
		// Store fields in personMap 
		// Convert display values to foreign keys before passing personMap to nz.co.transparent.client.controller
		personMap.put("user_name", userNameField.getText());
		personMap.put("first_name", firstNameField.getText());
		personMap.put("last_name", lastNameField.getText());
		personMap.put("address1", address1Field.getText());
		personMap.put("address2", address2Field.getText());
		personMap.put("suburb", suburbField.getText());
		personMap.put("city", cityField.getText());
		personMap.put("date_of_birth", dateOfBirthField.getValue());
		personMap.put("comment", commentField.getText());
		personMap.put("updater_person_id", LoginController.getPerson().get("person_id"));
		personMap.put("date_created", dateCreatedField.getValue());
		personMap.put("date_updated", dateUpdatedField.getValue());

		try {
			if (personIDField.getText().equals("")) {
				personMap.put("person_id", null); 	// Generate key
				genericController.insertRecord("person", "person_id", personMap);
				// Create user in system database
				systemController.createUser(userNameField.getText(), new String(password1Field.getPassword()));
			} else {
				personMap.put("person_id", Integer.valueOf(personIDField.getText()));	// Cast to Integer, otherwise record lookup and update will fail
				genericController.updateRecord("person", "person_id", personMap);

				// If passord is chaged update system DB
				char[] password = password1Field.getPassword();
				if (password.length > 0) {
					systemController.alterUser(personMap.get("user_name").toString(), String.valueOf(password), null);  
				}
			}
			
			Integer personID = (Integer) personMap.get("person_id");
			populateForm(personID.intValue());
		} catch (UpdaterException ue) {
			String message = "Update warning !\n";
			message += "Changes have been made by an other person or process.\n";
			message += "Form will be refreshed with latest values";
			Messager.warning(this, message);
			populateForm(Integer.parseInt(personMap.get("person_id").toString()));
		} catch (ControllerException ce) {
			Messager.exception(this, "Error: " + ce.getMessage());
		}
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogForm1);

		// If this is a new person, then password must be entered
		// Else password can be empty
		if (personIDField.getText().equals("")) {
			if (password1Field.getPassword().length == 0) {
				password1Field.setBackground(Color.YELLOW);
				password1Field.setToolTipText("Please enter Password");
				password1Field.requestFocus();
				validationOk = false;
			} else {
				if (!getPasswordText(password1Field).equals(getPasswordText(password2Field))) {
					password1Field.setBackground(Color.YELLOW);
					password1Field.setToolTipText("Passwords different. Please enter both password fields again");
					password2Field.setBackground(Color.YELLOW);
					password2Field.setToolTipText("Enter password again.");
					password1Field.requestFocus();
					validationOk = false;
				}
			}
		} else {
			if (!getPasswordText(password1Field).equals(getPasswordText(password2Field))) {
				password1Field.setBackground(Color.YELLOW);
				password1Field.setToolTipText("Passwords different. Please enter both password fields again");
				password2Field.setBackground(Color.YELLOW);
				password2Field.setToolTipText("Enter password again.");
				password1Field.requestFocus();
				validationOk = false;
			}
		}

		if (userNameField.getText().equals("")) {
			userNameField.setBackground(Color.YELLOW);
			userNameField.setToolTipText("Please enter login ID");
			userNameField.requestFocus();
			validationOk = false;
		}
		
		Map loginMap = LoginController.getPerson();
		
		if (userNameField.getText().equalsIgnoreCase(loginMap.get("user_name").toString())) {
			userNameField.setBackground(Color.YELLOW);
			userNameField.setToolTipText("You cannot remove yourself");
			userNameField.requestFocus();
			validationOk = false;
		}

		return validationOk;
	}
	
	private void reloadButton_actionPerformed(ActionEvent evt) {
		Integer personID = (Integer) personMap.get("person_id");
		
		if (personID == null) {
			newButton_actionPerformed();
		} else {
			populateForm(personID.intValue());
		}
	}
	
	private String getPasswordText(JPasswordField passwordField) {
		
		char[] password = passwordField.getPassword();
		StringBuffer buffer = new StringBuffer(password.length);
		
		for (int i=0; i<password.length; i++) {
			buffer.append(password[i]);
		}
		
		return buffer.toString();
	}
}