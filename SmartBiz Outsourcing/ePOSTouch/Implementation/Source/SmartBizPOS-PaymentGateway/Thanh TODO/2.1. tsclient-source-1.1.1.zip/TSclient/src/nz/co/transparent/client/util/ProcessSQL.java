/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 package nz.co.transparent.client.util;

import java.sql.*;
import java.io.*;

import javax.sql.DataSource;

import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.DataSourceHandler;


public class ProcessSQL {

	static String eol = "\0";
	static StringBuffer statementBuffer;
	static int statementCount = 0;
	
	public static void main(String[] args) {
		
		if (args.length == 0) {
			System.out.println("ProcessSQL:: syntax = nz.co.transparent.client.util.ProcessSQL <file name> <database_userName> <database_password>");
			return;
		}

		// File with SQL statements
		File file = new File(args[0]);
		if (!file.exists()) {
			System.out.println("ProcessSQL:: File does not exist: " + args[0]);
			System.exit(0);
		}

		// Get username and password from command args, if possible
		String userName = "";
		String password = "";

		if (args.length > 1) {
			userName = args[1];
			password = args[2];
		} else {
			userName = Configuration.getProperty("login.username", "");
			password = Configuration.getProperty("login.password", "");
		}

		if (userName.equals("")) {
			throw new RuntimeException("userName must not be empty");
		}
		
		if (password.equals("")) {
			throw new RuntimeException("password must not be empty");
		}
		
		// Setup datasource 
		DataSourceHandler.setPassword(password);
		DataSourceHandler.setUserName(userName);
		DataSource dataSource = DataSourceHandler.getDataSource();
		Connection connection = null;

		try {
			connection = dataSource.getConnection();
			connection.setAutoCommit(false);
		} catch (SQLException e) {
			System.out.println(
				"ProcessSQL:: Unable to get database connection.\n"
					+ e.getMessage());
			System.exit(0);
		}

		// --- Set up the database ---
		// Reading a line works different on Windows and Linux as the end-of-line character is different
		// That's why we cannot use LineRead, but must read a character at a time
		// When processing statement we check for comment lines
		try {
			Statement statement = connection.createStatement(); 
			BufferedReader bufReader = new BufferedReader(new FileReader(file));
			StringBuffer buffer;
			int character = 0;
			StringBuffer sqlBuffer = new StringBuffer();

			while (true) {
				if ((character = bufReader.read()) == -1) {
					processStatement(statement, sqlBuffer);
					break;
				}
				
				// Cast int to char. This works when using byte characters in SQL file 
				sqlBuffer.append((char) character);

				if (character == ';') {
					processStatement(statement, sqlBuffer);
					sqlBuffer = new StringBuffer();
				}
			}
				
			System.out.println("Number of statements processed: " + statementCount);
		} catch (Exception e) {
			System.out.println("An error occured: " + e.getMessage());
			try {
				connection.rollback();
				connection.close();
				return;
			} catch (Exception e2) {
				return;
			}
		}

		// Close the the connection.
		try {
			connection.commit();
			connection.close();
			DataSourceHandler.closeDataSource();
		} catch (SQLException e2) {
			e2.printStackTrace(System.err);
		} catch (ControllerException ce) {
			System.out.println("ProcessSQL nz.co.transparent.client.controller exception::\n" + ce.getMessage());
		}
		
		System.out.println("ProcessSQL ready");
	}
	
	private static void processStatement(Statement statement, StringBuffer sqlBuffer) {

		if (sqlBuffer.indexOf(";") == -1) {
			return;
		}
		
		if (eol.equals("\0")) {
			if (sqlBuffer.indexOf("\r\n") > -1) {
				eol = "\r\n";
			} else if (sqlBuffer.indexOf("\n") > -1) {
				eol = "\n";
			} else if (sqlBuffer.indexOf("\r") > -1) {
				eol = "\r";
			}
		}
		
		statementCount++;
		// Split into lines
		String[] lines = sqlBuffer.toString().split(eol);
		statementBuffer = new StringBuffer();
		
		for (int i=0; i<lines.length; i++) {
			if (lines[i].length() == 0) {
			} else if (lines[i].trim().substring(0,1).equals("#")) {
			} else {
				statementBuffer.append(lines[i]);
				statementBuffer.append(" ");
			}
		}
		
		try {
			statement.execute(statementBuffer.toString());
		} catch (SQLException se) {
			System.out.println("==>");
			System.out.println("Query failed:");
			System.out.println(statementBuffer.toString());
			System.out.println("The SQLException message is: ");
			System.out.println(se.getMessage());
			System.out.println("==>");
		}
	}
}