/*
 * DeleteTablesTest.java
 * JUnit based test
 *
 * Created on November 8, 2004, 3:55 PM
 */

package nz.co.transparent.client.util;

import junit.framework.*;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.apache.commons.dbutils.DbUtils;
import nz.co.transparent.client.db.*;

/**
 *
 * @author johnz
 */
public class DeleteTablesTest extends TestCase {
    
    public DeleteTablesTest(String testName) {
        super(testName);
    }

    protected void setUp() throws java.lang.Exception {
    }

    protected void tearDown() throws java.lang.Exception {
    }

    public static junit.framework.Test suite() {
        junit.framework.TestSuite suite = new junit.framework.TestSuite(DeleteTablesTest.class);
        
        return suite;
    }

    /**
     * Test of main method, of class nz.co.transparent.client.util.DeleteTables.
     */
    public void testMain() {
        System.out.println("testMain");
        
        // TODO add your test code below by replacing the default call to fail.
        //fail("The test case is empty.");
                String[] args = {};
        DeleteTables.main(args);
    }
    
    // TODO add test methods here. The name must begin with 'test'. For example:
    // public void testHello() {}
    
}
