/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Jan 14, 2004
 *  
 */
package nz.co.transparent.client.report;

import java.io.File;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;

import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.HashPrintServiceAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.PrintServiceAttributeSet;
import javax.print.attribute.standard.MediaSizeName;
import javax.print.attribute.standard.OrientationRequested;
import javax.print.attribute.standard.PrinterName;

import nz.co.transparent.client.controller.GenericController;
import nz.co.transparent.client.controller.SpecificController;

import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.FinderException;
import dori.jasper.engine.JREmptyDataSource;
import dori.jasper.engine.JRException;
import dori.jasper.engine.JRExporterParameter;
import dori.jasper.engine.JasperFillManager;
import dori.jasper.engine.JasperPrint;
import dori.jasper.engine.export.JRPrintServiceExporter;
import dori.jasper.engine.export.JRPrintServiceExporterParameter;
import dori.jasper.view.JasperViewer;
import nz.co.transparent.client.util.Configuration;
import nz.co.transparent.client.util.Constants;

/**
 * @author John Zoetebier
 *  
 */
public class EnvelopReporter {

	static Logger log = Logger.getLogger("report");

	/**
	 * Print DL envelop in landscape Envelop is fed short side first at left
	 * side of printer from printer view.
	 */
	public EnvelopReporter() {
		super();
	}

	public static void print(int clientID, boolean printPreview)
		throws ControllerException {

		// Check if jasper report is present
		String fileSeparator = System.getProperty("file.separator");
		String jasperFileName =
			Configuration.getProperty("client.dir", "")
				+ fileSeparator
				+ "resource"
				+ fileSeparator
				+ "EnvelopReport.jasper";
		File jasperFile = new File(jasperFileName);
		String msg = null;

		if (!jasperFile.exists()) {
			msg = "Cannot find jasper file: " + jasperFileName;
			log.warning(msg);
			throw new ControllerException(msg);
		}

		Map clientMap = null;
		Map titleMap = null;
		GenericController genericController = GenericController.getInstance();
		SpecificController specificController =
			SpecificController.getInstance();

		try {
			clientMap =
				genericController.findWhere("client", "client_id=" + clientID);
		} catch (FinderException fe) {
			throw new ControllerException("No client record found");
		}

		try {
			titleMap =
				genericController.findWhere("title", "title_id=" + clientMap.get("title_id"));
		} catch (FinderException fe) {
			throw new ControllerException("No title record found for title_id =" + clientMap.get("title_id"));
		}

		Map reportMap = new HashMap();
		// Get sender address
		Map parameterMap = null;

		// Sender address must be decoded from Base64
		reportMap.put(
			"SenderAddress",
			Configuration.getDecodedProperty(
				"report.envelopreport.sender.address",
				""));
		StringBuffer receiverAddress = new StringBuffer();
		if (titleMap != null && titleMap.get("title_code") != null) {
			receiverAddress.append(titleMap.get("title_code"));
		}

		if (clientMap.get("first_name") != null) {
			receiverAddress.append(" " + clientMap.get("first_name"));
		}

		//		if (clientMap.get("middle_name") != null) {
		//			if (receiverAddress.length() > 0) {
		//				receiverAddress.append(",");
		//			}
		//				
		//			receiverAddress.append(" " + clientMap.get("middle_name"));
		//		}

		if (clientMap.get("last_name") != null) {
			receiverAddress.append(" ");
			receiverAddress.append(clientMap.get("last_name"));
			receiverAddress.append("\n");
		}

		if (clientMap.get("address1") != null) {
			receiverAddress.append(clientMap.get("address1"));
			receiverAddress.append("\n");
		}

		if (clientMap.get("address2") != null) {
			receiverAddress.append(clientMap.get("address2"));
			receiverAddress.append("\n");
		}

		if (clientMap.get("suburb") != null) {
			receiverAddress.append(clientMap.get("suburb"));
			receiverAddress.append("\n");
		}

		if (clientMap.get("city") != null) {
			receiverAddress.append(clientMap.get("city"));
			receiverAddress.append("\n");
		}

		reportMap.put("ReceiverAddress", receiverAddress.toString().trim());

		try {
			JasperPrint jasperPrint =
				JasperFillManager.fillReport(
					jasperFileName,
					reportMap,
					new JREmptyDataSource());

			// For print attributes see API docs:
			// j2sdk-1_4_2/docs/api/index.html
			PrintRequestAttributeSet printRequestAttributeSet =
				new HashPrintRequestAttributeSet();
			printRequestAttributeSet.add(OrientationRequested.LANDSCAPE);
			printRequestAttributeSet.add(MediaSizeName.ISO_A4);

			PrintServiceAttributeSet printServiceAttributeSet =
				new HashPrintServiceAttributeSet();
			// Linux: print queues like "draft", "normal", "photo", etc
			// Windows: use physical printername like "Epson Stylus COLOR 680"
			// or "HP LaserJet 5000 Series PCL"

			String printerNameTemp =
				Configuration.getDecodedProperty(
					"report.envelopreport.printer",
					Constants.REPORT_ENVELOPREPORT_PRINTER);

			if (printerNameTemp.equals("")) {
			} else {
				PrinterName printerName =
					new PrinterName(printerNameTemp, Locale.getDefault());
				printServiceAttributeSet.add(printerName);
			}

			JRPrintServiceExporter exporter = new JRPrintServiceExporter();
			exporter.setParameter(
				JRExporterParameter.JASPER_PRINT,
				jasperPrint);
			exporter.setParameter(
				JRPrintServiceExporterParameter.PRINT_REQUEST_ATTRIBUTE_SET,
				printRequestAttributeSet);
			exporter.setParameter(
				JRPrintServiceExporterParameter.PRINT_SERVICE_ATTRIBUTE_SET,
				printServiceAttributeSet);
			exporter.setParameter(
				JRPrintServiceExporterParameter.DISPLAY_PAGE_DIALOG,
				Boolean.FALSE);
			exporter.setParameter(
				JRPrintServiceExporterParameter.DISPLAY_PRINT_DIALOG,
				Boolean.TRUE);

			if (printPreview) {
				// preview is started in non_modal
				JasperViewer.viewReport(jasperPrint, false);
			} else {
				exporter.exportReport();
			}
		} catch (JRException je) {
			msg =
				"\nError printing envelop:\nPlease check printer parameter.\n"
					+ je.getMessage();
			log.warning(msg);
			throw new ControllerException(msg);
		}
	}
}