/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Prescription.java
 *
 * Created on November 22, 2003, 14:08 PM
 */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.KeyboardFocusManager;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.*;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;


/**
 *
 * @author  John Zoetebier
 */
public class PrescriptionForm extends javax.swing.JInternalFrame {

	// Constants
	private static final int FIELD_LENGTH = 14;

	// Private variables
	private Map prescriptionMap = new HashMap();
	private Map clientMap = new HashMap();
	private Map personMap = new HashMap();
	private GenericController genericController = GenericController.getInstance();
	
	private JLabel prescriptionIDLabel = new JLabel("Prescription ID");
	private JLabel clientIDLabel = new JLabel("Client");
	private JLabel prescriptionLabel = new JLabel("Prescription");
	private JLabel commentLabel = new JLabel("Comment");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	private JLabel dateCreatedLabel = new JLabel("Date created");
	private JLabel dateUpdatedLabel = new JLabel("Date updated");
	
	private DateFormat timeStampFormat = new SimpleDateFormat(Parameter.getParameter("format.timestamp", Constants.FORMAT_TIMESTAMP));

	private JTextField prescriptionIDField = new JTextField();
	private JTextField clientIDField = new JTextField();
	private JTextField prescriptionField = new JTextField();
	private JTextArea commentField = new JTextArea(4, FIELD_LENGTH);
	private JTextField updaterPersonIDField = new JTextField();
	private JFormattedTextField dateCreatedField = new JFormattedTextField(timeStampFormat);
	private JFormattedTextField dateUpdatedField = new JFormattedTextField(timeStampFormat);
	
	private JPanel contentPanel = new JPanel();
	private JPanel middlePanel = new JPanel();	// To get dialogPanel left alligned
	private JPanel dialogPanel = new JPanel();

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();
	
	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public PrescriptionForm() {
		initComponents();
	}
    
	/** This method is called from within the constructor to
	 * initialize the form.
	 */
	private void initComponents() {
		
		setName("Prescription form");
		setTitle("Prescription form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);
		addInternalFrameListener(new InternalFrameOpenedAdapter(this, prescriptionField));

		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New prescription.");
		newButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				newButton_actionPerformed();
			 }
		});
		
		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		saveButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save prescription.");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(saveButton);

		reloadButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh prescription.");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		deleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete prescription.");
		deleteButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				deleteButton_actionPerformed(evt);
			 }
		});
		
		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));
		
		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setFocusTraversalPolicy(new InputOrderFocusTrafersalPolicy());
		dialogPanel.setFocusCycleRoot(true);	// This will force focus go down the colum

		// Dialog fields
		dialogPanel.add(prescriptionIDLabel);
		Dimension fieldDimension = new Dimension(200, prescriptionIDLabel.getPreferredSize().height);
//		prescriptionIDField.setColumns(FIELD_LENGTH);
		prescriptionIDField.setToolTipText("Generated by system.");
		prescriptionIDField.setEditable(false);
		dialogPanel.add(prescriptionIDField);

		dialogPanel.add(clientIDLabel);
		clientIDField.setEditable(false);
		dialogPanel.add(clientIDField);

		dialogPanel.add(prescriptionLabel);
		dialogPanel.add(prescriptionField);

		dialogPanel.add(commentLabel);
		commentField.setLineWrap(true);
		commentField.setWrapStyleWord(true);	// wrap only on word boundary
		// Ensure tabs are handled by focus manager
		commentField.setFocusTraversalKeys(
				KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,null);
		commentField.setFocusTraversalKeys(
			KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,null);
		 
		JScrollPane commentScrollPane = new JScrollPane(commentField);
		dialogPanel.add(commentScrollPane);

		dialogPanel.add(updaterPersonIDLabel);
		updaterPersonIDField.setEditable(false);
		dialogPanel.add(updaterPersonIDField);

		dialogPanel.add(dateCreatedLabel);
		dateCreatedField.setEditable(false);
		dialogPanel.add(dateCreatedField);

		dialogPanel.add(dateUpdatedLabel);
		dateUpdatedField.setEditable(false);
		dialogPanel.add(dateUpdatedField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
		
		// Add dialogPanel to content panel 
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);

		pack();
	}

	/**
	 * Populate form using PK prescription_id
	 * @param prescriptionID PK prescription_id
	 */
	public void populateForm(int prescriptionID) {

		String msg = null;
		try {
			msg = "PrescriptionForm: Cannot find prescription: " + prescriptionID;
			prescriptionMap = genericController.findWhere("prescription", "prescription_id=" + prescriptionID);
			Integer clientID = (Integer) prescriptionMap.get("client_id");

			msg = "PrescriptionForm: Cannot find client: " + clientID;
			clientMap = genericController.findWhere("client", "client_id=" + clientID);

			Integer personID = (Integer) prescriptionMap.get("updater_person_id");
			personMap = Updater.getUpdater(personID.intValue());
		} catch (ControllerException ce) {
			Messager.exception(this, msg + "\n" + ce.getMessage());
			return;
		} catch (FinderException fe) {
			Messager.exception(this, msg  + "\n" + fe.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		prescriptionIDField.setText(String.valueOf(prescriptionMap.get("prescription_id").toString()));
		clientIDField.setText((String) clientMap.get("last_name"));
		prescriptionField.setText((String) prescriptionMap.get("prescription"));
		commentField.setText((String) prescriptionMap.get("comment"));
		updaterPersonIDField.setText((String) personMap.get("user_name"));
		dateCreatedField.setValue(prescriptionMap.get("date_created"));
		dateUpdatedField.setValue(prescriptionMap.get("date_updated"));
	}
	
	/**
	 * Populate new form
	 * 
	 * @param parentMap Map of parent
	 */
	public void populateNewForm(Map parentMap) {

		this.clientMap = parentMap;
		newButton_actionPerformed();
	}

	private void deleteButton_actionPerformed(ActionEvent evt) {
		String msg = null;

		if (prescriptionMap.get("prescription_id") == null) {
			msg = "New prescription cannot be deleted";
			Messager.information(this, msg);
			return;
		}

		msg = "Continue to delete prescription ?";
		if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
			return;
		}
			
		try {
			Integer prescriptionID = (Integer) prescriptionMap.get("prescription_id");
			genericController.deleteRecord("prescription", "prescription_id=" + prescriptionID.intValue());
			newButton_actionPerformed();
		} catch (ControllerException ce) {
			Messager.exception(this, "PrescriptionForm: Error deleting prescription.\n" + ce.getMessage());
			return;
		}
	}

	private void newButton_actionPerformed() {

		prescriptionMap.put("prescription_id", null);
		personMap = LoginController.getPerson();

		GenericUtils.resetInputFields(dialogPanel);
		Map contactTypeMap = null;
		
		prescriptionIDField.setText(null);
		clientIDField.setText((String) clientMap.get("last_name"));
		prescriptionField.setText(null);
		commentField.setText(null);
		updaterPersonIDField.setText((String) LoginController.getPerson().get("user_name"));
		dateCreatedField.setValue(new Date());
		dateUpdatedField.setValue(new Date());
	}

	private void saveButton_actionPerformed(ActionEvent evt) {
		
		if (!validateForm()) {
			return;
		}
		
		// Store fields in prescriptionMap 
		// Convert display values to foreign keys before passing prescriptionMap to nz.co.transparent.client.controller
		prescriptionMap.put("client_id", clientMap.get("client_id"));
		prescriptionMap.put("prescription", prescriptionField.getText());
		prescriptionMap.put("comment", commentField.getText());
		prescriptionMap.put("updater_person_id", LoginController.getPerson().get("person_id"));
		prescriptionMap.put("date_created", dateCreatedField.getValue());
		prescriptionMap.put("date_updated", dateUpdatedField.getValue());

		try {
			if (prescriptionIDField.getText().equals("")) {
				prescriptionMap.put("prescription_id", null); 	// Generate key
				genericController.insertRecord("prescription", "prescription_id", prescriptionMap);
			} else {
				// Cast to Integer, otherwise record lookup and update will fail
				prescriptionMap.put("prescription_id", Integer.valueOf(prescriptionIDField.getText()));
				genericController.updateRecord("prescription", "prescription_id", prescriptionMap);
			}
			
			Integer prescriptionID = (Integer) prescriptionMap.get("prescription_id");
			populateForm(prescriptionID.intValue());
		} catch (UpdaterException ue) {
			String message = "Update warning !\n";
			message += "Changes have been made by an other person or process.\n";
			message += "Form will be refreshed with latest values";
			Messager.warning(this, message);
			populateForm(Integer.parseInt(prescriptionMap.get("prescription_id").toString()));
		} catch (ControllerException ce) {
			Messager.exception(this, "Error: " + ce.getMessage());
		}
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogPanel);

		if (prescriptionField.getText().equals("")) {
			prescriptionField.setBackground(Color.YELLOW);
			prescriptionField.setToolTipText("Please enter prescription");
			prescriptionField.requestFocus();
			validationOk = false;
		}

		return validationOk;
	}
	
	private void reloadButton_actionPerformed(ActionEvent evt) {
		Integer prescriptionID = (Integer) prescriptionMap.get("prescription_id");
		
		if (prescriptionID == null) {
			this.newButton_actionPerformed();
		} else {
			this.populateForm(prescriptionID.intValue());
		}
	}
}