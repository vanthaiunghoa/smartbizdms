/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Dec 13, 2003
 *
 */
package nz.co.transparent.client.db;

/**
 * @author johnz
 * 
 */
import java.sql.SQLException;
import java.util.logging.Logger;
import org.apache.commons.dbcp.BasicDataSource;
import nz.co.transparent.client.util.Configuration;
import nz.co.transparent.client.util.Constants;

/**
 * Wrapper class for DBCP BasicDataSource
 * DataSource works better with Jakarate DbUtils
 * DbUtils will automatically open and close connections behind the screens
 * @author johnz
 *
 */
public class DataSourceHandler {

	private static Logger log = Logger.getLogger("nz.co.transparent.client.db");
	private static BasicDataSource dataSource;
	private static String userName;
	private static String password;
	
	// Do not allow to instantiate the class
	private DataSourceHandler() {
	}
	
	public static javax.sql.DataSource getDataSource() {
		
		if (dataSource != null) {
			return dataSource;
		}
		
		// Check if credentials have been set
		if (userName == null) {
			throw new RuntimeException("userName is null. Must be set before getting datasoure");
		}
		
		if (password == null) {
			throw new RuntimeException("userName is null. Must be set before getting datasoure");
		}
		
		// Initialize connection URL and database credentials from configuration file
		String connectURI;
 
		if (Configuration.getProperty("server.mode", Constants.SERVER_MODE).equalsIgnoreCase("server")) {
			connectURI =
				"jdbc:mckoi://"
				+ Configuration.getProperty("server.name", "localhost")
				+ ":"
				+ Configuration.getProperty("server.port", "9157");
				
//			if (!Configuration.getProperty("jdbc.schema").equals("")) {
//				connectURI += "/"
//				+ Configuration.getProperty("jdbc.schema")
//				+ "/";
//			}
		} else {
			String fileSeparator = System.getProperty("file.separator");
			String clientDir = Configuration.getProperty("client.dir", ".");
			String dbConfig = clientDir + fileSeparator + "resource" +  fileSeparator + "db.conf";  
			connectURI = "jdbc:mckoi:local://" + dbConfig;
		}
		
		log.info("connectURI=" + connectURI);
		// First we set up the BasicDataSource.
		dataSource = new BasicDataSource();
		dataSource.setDriverClassName("com.mckoi.JDBCDriver");
		dataSource.setUsername(userName);
		dataSource.setPassword(password);
		dataSource.setUrl(connectURI);

		dataSource.setMaxActive(Integer.parseInt(Configuration.getProperty("dbcp.maxactive", "100")));
		dataSource.setMaxWait(Integer.parseInt(Configuration.getProperty("dbcp.maxwait", "30000")));

		if (Configuration.getProperty("dbcp.maxidle", "").equals("")) {
			int maxIdle = Integer.parseInt(Configuration.getProperty("dbcp.maxactive", "100"));
			maxIdle = maxIdle / 5;
			Configuration.setProperty("dbcp.maxidle", new Integer(maxIdle).toString());
			Configuration.storeConfiguration();
		}
		
		dataSource.setMaxIdle(Integer.parseInt(Configuration.getProperty("dbcp.maxidle", "50")));
		dataSource.setMinIdle(Integer.parseInt(Configuration.getProperty("dbcp.minidle", "1")));
		log.info("Setting up data source: done.");
		return dataSource;
	}

	/**
	 * Closes all connections in DataSource
	 * @throws ControllerException
	 */
	public static void closeDataSource() throws ControllerException {
		try {
			dataSource.close();
		} catch (SQLException se) {
			log.warning(se.getMessage());
			throw new ControllerException(se.getMessage());
		}
	}

	public static void setUserName(String userName) {

		dataSource = null;
		DataSourceHandler.userName = userName;
	}

	public static String getUserName() {
		return userName;
	}

	public static void setPassword(String password) {
		
		dataSource = null;
		DataSourceHandler.password = password;
	}

	public static String getPassword() {
		return password;
	}

	/** 
	 * Load credentials from configuration file
	 * For TESTING purposes ONLY
	 * Production environment: setUserName() and serPassword() 
	 * 
	 *
	 */
	public static void loadCredentialsFromConfig() {

		// Load DataSourceHandler credentials from configuration file
		DataSourceHandler.setUserName(Configuration.getProperty("login.username", ""));
		DataSourceHandler.setPassword(Configuration.getProperty("login.password", ""));
		return;
	}
}