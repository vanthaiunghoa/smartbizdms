/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * PersonSearch.java
 *
 * Created on November 31, 2003, 12:21 PM
 */

package nz.co.transparent.client.gui;

import nz.co.transparent.client.gui.util.DialogLayout;
import nz.co.transparent.client.gui.util.InternalFrameOpenedAdapter;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;

/**
 * 
 * @author John Zoetebier
 *
 */
public class PersonSearchForm extends javax.swing.JInternalFrame {
    
	// Contants
	private static final int FIELD_LENGTH =20; 
	
	// Variables declaration
	private JLabel lastNameLabel = new JLabel("Last name:");
	private JLabel firstNameLabel = new JLabel("First name:");
	private JLabel userNameLabel = new JLabel("User name:");
	private JPanel contentPane = new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();
	private JTextField lastNameField = new JTextField();
	private JTextField firstNameField = new JTextField();
	private JTextField userNameField = new JTextField();
	private JButton personSearchButton = new JButton();
	private JToolBar toolbar = new JToolBar();
	private PersonTableForm personTableForm;
	private Map searchMap;
	private Container parentContainer = null;
	// End of variables declaration
    
	/** Creates new form PersonSearch */
	public PersonSearchForm() {
		initComponents();
		parentContainer = getParent();
	}
    
	/** This method is called from within the constructor to
	 * initialize the form.
	 */
	private void initComponents() {
		
		setName("Person search");
		setTitle("Person search");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		setContentPane(contentPane);
		try {
			setSelected(true);
		} catch (java.beans.PropertyVetoException e1) {
			e1.printStackTrace();
		}

		addInternalFrameListener(new InternalFrameOpenedAdapter(this, lastNameField));

		personSearchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Find24.gif")));
		personSearchButton.setMnemonic(KeyEvent.VK_E);
		personSearchButton.setToolTipText("Enter one or more of the search fields. Then click me.");
		personSearchButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				personSearchButton_actionPerformed(evt);
			 }
		});
		
		toolbar.setBorder(BorderFactory.createEtchedBorder());
		toolbar.setFloatable(false);
		toolbar.add(Box.createRigidArea(new Dimension(5,0)));
		toolbar.add(personSearchButton);

		toolbar.add(Box.createHorizontalGlue());	// make buttons left aligned
		contentPane.add(toolbar);

		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));

		dialogPanel.add(lastNameLabel);
		lastNameField.setColumns(FIELD_LENGTH);
		lastNameField.setText("");
		lastNameField.setToolTipText("Last name or part of it.");
		lastNameField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					personSearchButton.doClick();
				}
			}
		});
		dialogPanel.add(lastNameField);

		dialogPanel.add(firstNameLabel);
		firstNameField.setText("");
		firstNameField.setColumns(FIELD_LENGTH);
		firstNameField.setToolTipText("First name or part of it.");
		firstNameField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					personSearchButton.doClick();
				}
			}
		});
		dialogPanel.add(firstNameField);

		dialogPanel.add(userNameLabel);
		userNameField.setText("");
		userNameField.setColumns(FIELD_LENGTH);
		userNameField.setToolTipText("User name or part of it");
		userNameField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					personSearchButton.doClick();
				}
			}
		});
		dialogPanel.add(userNameField);

		middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.X_AXIS));
		middlePanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(20, 5, 20, 5)));
		middlePanel.add(dialogPanel);
		middlePanel.add(Box.createHorizontalStrut(700));

		contentPane.add(middlePanel);

		//===========================================
		// Create person table form
		//===========================================
		personTableForm = new PersonTableForm();
		contentPane.add(personTableForm);
		
		//===========================================
		// Pack
		//===========================================
		pack();
	}

	private void personSearchButton_actionPerformed(ActionEvent evt) {
		searchMap = new HashMap();
		searchMap.put("last_name", lastNameField.getText());
		searchMap.put("first_name", firstNameField.getText());
		searchMap.put("user_name", userNameField.getText());
		personTableForm.updateTable(searchMap);
	}
	
//	private void processPassword() {
//		
//		String password = null;
//		Map personMap = null;
//		SystemDBController systemController = SystemDBController.getInstance();
//		PasswordOnlyDialog dialog = new PasswordOnlyDialog(null, "Password"); 
//		int i =0;
//		
//		while (true) {
//			password = dialog.showDialog();
//			
//			if (password == null) {
//				this.dispose();
//				return;
//			}
//			
//			// Check only 3 times
//			try {
//				if (i++ < 2) {
//					personMap = systemController.getUser(LoginController.getPerson().get("user_name").toString());
//					
//					if (personMap != null) {
//						if (password.equals(personMap.get("Password"))) {
//							try {
//								this.setMaximum(true);
//							} catch (PropertyVetoException pve) {
//								// Ignore
//							}
//							
//							return;
//						}
//					}
//				}
//			} catch (ControllerException ce) {
//				String msg = "PersonSearch: error getting password.\n" + ce.getMessage();
//				Messager.exception(this, msg);
//				this.dispose();
//				return;
//			}
//		}
//	}
}