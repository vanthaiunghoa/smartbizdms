/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Nov 14, 2003
 *
 */
package nz.co.transparent.client.controller;

import java.sql.SQLException;
import java.util.Map;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.MapHandler;

import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.DataSourceHandler;

/**
 * Handles fundtions for system database
 * 
 * @author John Zoetebier
 *
 */
public class SystemDBController {

	private static SystemDBController _instance;
	private Logger log = Logger.getLogger("nz.co.transparent.client.db");
	private DataSource dataSource = DataSourceHandler.getDataSource();

	/**
	 * Private constructor
	 *
	 */
	private SystemDBController() {
	}
	
	public static SystemDBController getInstance() {
		
		if (_instance != null) {
			return _instance;
		}
		
		_instance = new SystemDBController();
		return _instance;
	}
	
	/**
	 * Create a new user
	 * @param userName
	 * @param password
	 * @throws ControllerException
	 */
	public void createUser(String userName, String password) 
		throws ControllerException {
		
		String sql = "create user " + userName + " set password '" + password + "'";
		QueryRunner queryRunner = new QueryRunner(DataSourceHandler.getDataSource());
		
		try {
			
			queryRunner.update(sql);
		} catch (SQLException se) {
			log.warning("SystemDBController: " + se.getMessage());
			throw new ControllerException(se);
		}
	}			

	/**
	 * Lock account
	 * @param userName
	 * @param lockAccount
	 * @throws ControllerException
	 */
	public void lockAccount(String userName, boolean lockAccount) 
		throws ControllerException {
		
		String sql = "alter user " + userName;
	
		if (lockAccount) {
			sql += " set acount lock";
		} else {
			sql += " set acount unlock";
		}
			
		QueryRunner queryRunner = new QueryRunner(DataSourceHandler.getDataSource());
		ResultSetHandler rsh = new MapHandler();
		try {
			queryRunner.update(sql);
		} catch (SQLException se) {
			log.warning("SystemDBController: " + se.getMessage());
			throw new ControllerException(se);
		}
	}			

	/**
	 * Alter user
	 * 
	 * @param userName userName and password are required
	 * @param password
	 * @throws ControllerException
	 */
	public void alterUser(String userName, String password) 
		throws ControllerException {
	
		alterUser(userName, password, null);
		return;
	}			

	/**
	 * Alter user
	 * 
	 * @param userName userName and password are required
	 * @param password
	 * @param groupList
	 * @throws ControllerException
	 */
	public void alterUser(String userName, String password, String groupList) 
		throws ControllerException {
		
		String sql = "alter user " + userName;
		sql += " set password '" + password +"'";
		
		if (groupList != null) {
			sql += " set groups '" + groupList +"'";
		}
		
		QueryRunner queryRunner = new QueryRunner(DataSourceHandler.getDataSource());
		ResultSetHandler rsh = new MapHandler();
		try {
			queryRunner.update(sql);
		} catch (SQLException se) {
			log.warning("SystemDBController: " + se.getMessage());
			throw new ControllerException(se);
		}
	}			

	/**
	 * Drop a user from System DB
	 * @param userName
	 * @throws ControllerException
	 */
	public void dropUser(String userName) 
		throws ControllerException {
		
		String sql = "drop user " + userName;
		QueryRunner queryRunner = new QueryRunner(DataSourceHandler.getDataSource());
		try {
			queryRunner.update(sql);
		} catch (SQLException se) {
			log.warning("SystemDBController: " + se.getMessage());
			throw new ControllerException(se);
		}
	}

	/**
	 * Get user from System DB
	 * @param userName
	 * @return <code>Map</code> with user details 
	 * @throws ControllerException
	 */
	public Map getUser(String userName) 
		throws ControllerException {
		
		// Create user in system database as well.
		String sql = "select * from SYS_INFO.sUSRPassword";
		sql += " where (UserName='" + userName + "')";
		QueryRunner queryRunner = new QueryRunner(DataSourceHandler.getDataSource());
		ResultSetHandler rsh = new MapHandler();

		try {
			return (Map) queryRunner.query(sql, rsh);
		} catch (SQLException se) {
			log.warning("SystemDBController: " + se.getMessage());
			throw new ControllerException(se);
		}
	}			
}