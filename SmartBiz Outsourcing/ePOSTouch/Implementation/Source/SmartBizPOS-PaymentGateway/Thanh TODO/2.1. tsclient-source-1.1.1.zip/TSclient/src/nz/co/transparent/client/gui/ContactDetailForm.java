/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * ContactDetail.java
 * 
 * Created on November 19, 2003, 14:08 PM
 */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.KeyboardFocusManager;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

import javax.swing.*;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;

/**
 * @author John Zoetebier
 */
public class ContactDetailForm extends javax.swing.JInternalFrame {

	// Constants
	private static final int FIELD_LENGTH = 14;

	// Private variables
	private Map contactDetailMap = new HashMap();
	private Map clientMap = new HashMap();
	private Map personMap = new HashMap();
	private List contactTypeList;
	private Logger log = Logger.getLogger("nz.co.transparent.client.gui");
	private GenericController genericController =
		GenericController.getInstance();

	private JLabel contactDetailIDLabel = new JLabel("Contact detail ID");
	private JLabel clientIDLabel = new JLabel("Client");
	private JLabel contactTypeIDLabel = new JLabel("Contact type");
	private JLabel contactDetailLabel = new JLabel("Contact detail");
	private JLabel commentLabel = new JLabel("Comment");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	private JLabel dateCreatedLabel = new JLabel("Date created");
	private JLabel dateUpdatedLabel = new JLabel("Date updated");

	private DateFormat timeStampFormat =
		new SimpleDateFormat(Parameter.getParameter("format.timestamp", Constants.FORMAT_TIMESTAMP));

	private JTextField contactDetailIDField = new JTextField();
	private JTextField clientIDField = new JTextField();
	private JComboBox contactTypeIDField = new JComboBox();
	private JTextField contactDetailField = new JTextField();
	private JTextArea commentField = new JTextArea(4, FIELD_LENGTH);
	private JTextField updaterPersonIDField = new JTextField();
	private JFormattedTextField dateCreatedField =
		new JFormattedTextField(timeStampFormat);
	private JFormattedTextField dateUpdatedField =
		new JFormattedTextField(timeStampFormat);

	private JPanel contentPanel = new JPanel();
	private JPanel middlePanel = new JPanel();
	// To get dialogPanel left alligned
	private JPanel dialogPanel = new JPanel();

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();

	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public ContactDetailForm() {
		initComponents();
	}

	/**
	 * This method is called from within the constructor to initialize the
	 * form.
	 */
	private void initComponents() {

		setName("Contact detail form");
		setTitle("Contact detail form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);
		addInternalFrameListener(
			new InternalFrameOpenedAdapter(
				this,
				contactTypeIDField));

		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New contact detail.");
		newButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				newButton_actionPerformed();
			}
		});

		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		saveButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save contact detail.");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(saveButton);

		reloadButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh contact detail.");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		deleteButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete contact detail.");
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				deleteButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setFocusTraversalPolicy(
			new InputOrderFocusTrafersalPolicy());
		dialogPanel.setFocusCycleRoot(true);
		// This will force focus go down the colum

		// Dialog fields
		dialogPanel.add(contactDetailIDLabel);
		Dimension fieldDimension =
			new Dimension(200, contactDetailIDLabel.getPreferredSize().height);
		//		contactDetailIDField.setColumns(FIELD_LENGTH);
		contactDetailIDField.setToolTipText("Generated by system.");
		contactDetailIDField.setEditable(false);
		dialogPanel.add(contactDetailIDField);

		dialogPanel.add(clientIDLabel);
		clientIDField.setEditable(false);
		dialogPanel.add(clientIDField);

		dialogPanel.add(contactTypeIDLabel);
		contactTypeIDField.setEditable(true);
		dialogPanel.add(contactTypeIDField);

		dialogPanel.add(contactDetailLabel);
		contactDetailField.setEditable(true);
		dialogPanel.add(contactDetailField);

		dialogPanel.add(commentLabel);
		commentField.setLineWrap(true);
		commentField.setWrapStyleWord(true); // wrap only on
															// word boundary
		// Ensure tabs are handled by focus manager
		commentField.setFocusTraversalKeys(
			KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,
			null);
		commentField.setFocusTraversalKeys(
			KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,
			null);

		JScrollPane commentScrollPane = new JScrollPane(commentField);
		dialogPanel.add(commentScrollPane);

		dialogPanel.add(updaterPersonIDLabel);
		updaterPersonIDField.setEditable(false);
		dialogPanel.add(updaterPersonIDField);

		dialogPanel.add(dateCreatedLabel);
		dateCreatedField.setEditable(false);
		dialogPanel.add(dateCreatedField);

		dialogPanel.add(dateUpdatedLabel);
		dateUpdatedField.setEditable(false);
		dialogPanel.add(dateUpdatedField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));

		// Add dialogPanel to content panel
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);

		pack();
	}

	/**
	 * Populate form using PK contact_detail_id
	 * 
	 * @param contactDetailID
	 *                PK contact_detail_id
	 */
	public void populateForm(int contactDetailID) {

		String msg = null;
		try {
			msg =
				"ContactDetailForm: Cannot find contact detail: "
					+ contactDetailID;
			contactDetailMap =
				genericController.findWhere(
					"contact_detail",
					"contact_detail_id=" + contactDetailID);
			Integer clientID = (Integer) contactDetailMap.get("client_id");
			msg = "ContactDetailForm: Cannot find client: " + clientID;
			clientMap =
				genericController.findWhere("client", "client_id=" + clientID);
			Integer personID =
				(Integer) contactDetailMap.get("updater_person_id");
			personMap = Updater.getUpdater(personID.intValue());
			msg = "ContactDetailForm: Cannot find contactTypes";
			contactTypeList =
				genericController.findAll("contact_type", "contact_type");
		} catch (ControllerException ce) {
			Messager.exception(this, msg + "\n" + ce.getMessage());
			return;
		} catch (FinderException fe) {
			Messager.exception(this, msg + "\n" + fe.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		// Fill combobox
		GenericUtils.updateJComboBox(
			contactTypeIDField,
			contactTypeList,
			"contact_type",
			"contact_type_id",
			(Integer) contactDetailMap.get("contact_type_id"));

		contactDetailIDField.setText(
			String.valueOf(
				contactDetailMap.get("contact_detail_id").toString()));
		clientIDField.setText((String) clientMap.get("last_name"));
		contactDetailField.setText(
			(String) contactDetailMap.get("contact_detail"));
		commentField.setText((String) contactDetailMap.get("comment"));
		updaterPersonIDField.setText((String) personMap.get("user_name"));
		dateCreatedField.setValue(contactDetailMap.get("date_created"));
		dateUpdatedField.setValue(contactDetailMap.get("date_updated"));
	}

	/**
	 * Populate new form
	 * 
	 * @param clientMap
	 *                Map of parent
	 */
	public void populateNewForm(Map clientMap) {

		this.clientMap = clientMap;
		newButton_actionPerformed();
	}

	private void deleteButton_actionPerformed(ActionEvent evt) {
		String msg = null;

		if (contactDetailMap.get("contact_detail_id") == null) {
			msg = "New contact detail cannot be deleted";
			Messager.information(this, msg);
			return;
		}

		msg = "Continue to delete contact detail ?";
		if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
			return;
		}

		try {
			Integer contactDetailID =
				(Integer) contactDetailMap.get("contact_detail_id");
			genericController.deleteRecord(
				"contact_detail",
				"contact_detail_id=" + contactDetailID.intValue());
			newButton_actionPerformed();
		} catch (ControllerException ce) {
			Messager.exception(
				this,
				"ContactDetailForm: Error deleting contact detail.\n"
					+ ce.getMessage());
			return;
		}
	}

	private void newButton_actionPerformed() {

		try {
			contactDetailMap.put("contact_detail_id", null);
			personMap = LoginController.getPerson();
			contactTypeList =
				genericController.findAll("contact_type", "contact_type");
		} catch (ControllerException ce) {
			Messager.exception(
				this,
				"ContactDetailForm: Error getting contact detail data"
					+ ce.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		Map contactTypeMap = null;

		// Fill combobox
		GenericUtils.updateJComboBox(
			contactTypeIDField,
			contactTypeList,
			"contact_type");

		contactDetailIDField.setText(null);
		clientIDField.setText((String) clientMap.get("last_name"));
		contactDetailField.setText(null);
		commentField.setText(null);
		updaterPersonIDField.setText(
			(String) LoginController.getPerson().get("user_name"));
		dateCreatedField.setValue(new Date());
		dateUpdatedField.setValue(new Date());
	}

	private void saveButton_actionPerformed(ActionEvent evt) {

		if (!validateForm()) {
			return;
		}

		// Store fields in contactDetailMap
		// Convert display values to foreign keys before passing
		// contactDetailMap to nz.co.transparent.client.controller
		contactDetailMap.put("client_id", clientMap.get("client_id"));
		contactDetailMap.put(
			"contact_type_id",
			GenericUtils.getKey(
				contactTypeList,
				"contact_type_id",
				"contact_type",
				(String) contactTypeIDField.getSelectedItem()));
		contactDetailMap.put("contact_detail", contactDetailField.getText());
		contactDetailMap.put("comment", commentField.getText());
		contactDetailMap.put(
			"updater_person_id",
			LoginController.getPerson().get("person_id"));
		contactDetailMap.put("date_created", dateCreatedField.getValue());
		contactDetailMap.put("date_updated", dateUpdatedField.getValue());

		try {
			if (contactDetailIDField.getText().equals("")) {
				contactDetailMap.put("contact_detail_id", null);
				// Generate key
				genericController.insertRecord(
					"contact_detail",
					"contact_detail_id",
					contactDetailMap);
			} else {
				contactDetailMap.put(
					"contact_detail_id",
					Integer.valueOf(contactDetailIDField.getText()));
				// Cast to Integer, otherwise record lookup and update will
				// fail
				genericController.updateRecord(
					"contact_detail",
					"contact_detail_id",
					contactDetailMap);
			}

			Integer contactDetailID =
				(Integer) contactDetailMap.get("contact_detail_id");
			populateForm(contactDetailID.intValue());
		} catch (UpdaterException ue) {
			String message = "Update warning !\n";
			message
				+= "Changes have been made by an other person or process.\n";
			message += "Form will be refreshed with latest values";
			Messager.warning(this, message);
			populateForm(
				Integer.parseInt(
					contactDetailMap.get("contact_detail_id").toString()));
		} catch (ControllerException ce) {
			Messager.exception(this, "Error: " + ce.getMessage());
		}
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogPanel);

		if (contactDetailField.getText().equals("")) {
			contactDetailField.setBackground(Color.YELLOW);
			contactDetailField.setToolTipText("Please enter contact detail");
			contactDetailField.requestFocus();
			validationOk = false;
		}

		if (contactTypeIDField.getSelectedItem().equals("")) {
			contactTypeIDField.getEditor().getEditorComponent().setBackground(
				Color.YELLOW);
			contactTypeIDField.setToolTipText("Please enter contact type");
			contactTypeIDField.requestFocus();
			validationOk = false;
		}

		// Check if new item entered in combobox
		String msg = null;
		try {
			if (contactTypeIDField.getSelectedIndex() == -1) {
				// Add new contactType silently
				Integer contactTypeID =
					genericController.getForeignKey(
						"contact_type",
						(String) contactTypeIDField.getSelectedItem(),
						"contact_type",
						"contact_type_id",
						contactTypeList);
				contactDetailMap.put("contact_type_id", contactTypeID);
				GenericUtils.updateJComboBox(
					contactTypeIDField,
					contactTypeList,
					"contact_type",
					"contact_type_id",
					(Integer) contactDetailMap.get("contact_type_id"));

			}

			return validationOk;
		} catch (ControllerException ce) {
			msg = "Controller error: " + ce.getMessage();
			log.warning(msg);
			Messager.exception(this, msg);
			return false;
		}
	}

	private void reloadButton_actionPerformed(ActionEvent evt) {
		Integer contactDetailID =
			(Integer) contactDetailMap.get("contact_detail_id");

		if (contactDetailID == null) {
			this.newButton_actionPerformed();
		} else {
			this.populateForm(contactDetailID.intValue());
		}
	}
}