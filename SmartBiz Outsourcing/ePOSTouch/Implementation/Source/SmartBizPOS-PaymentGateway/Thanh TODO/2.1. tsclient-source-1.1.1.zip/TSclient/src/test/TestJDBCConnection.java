/*
 * Created on Nov 26, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

/**
 * @author johnz
 *
 */
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;


//
// Here's a simple example of how to use the PoolingDriver.
// In this example, we'll construct the PoolingDriver manually,
// just to show how the pieces fit together, but you could also
// configure it using an external conifguration file in
// JOCL format (and eventually Digester).
//

//
// To compile this example, you'll want:
//	* commons-pool.jar
//	* commons-dbcp.jar
// in your classpath.
//
// To run this example, you'll want:
//	* commons-collections.jar
//	* commons-pool.jar
//	* commons-dbcp.jar
//	* the classes for your (underlying) JDBC driver
// in your classpath.
//
// Invoke the class using two arguments:
//	* the connect string for your underlying JDBC driver
//	* the query you'd like to execute
// You'll also want to ensure your underlying JDBC driver
// is registered.  You can use the "jdbc.drivers"
// property to do this.
//
// For example:
//	java -Djdbc.drivers=oracle.jdbc.driver.OracleDriver \
//		 -classpath commons-collections.jar:commons-pool.jar:commons-dbcp.jar:oracle-jdbc.jar:. \
//		 ManualPoolingDriverExample
//		 "jdbc:oracle:thin:scott/tiger@myhost:1521:mysid"
//		 "SELECT * FROM DUAL"
//

// ===
// In this case we use McKoi database server:
// Embedded server:
// "jdbc:mckoi:local://resource/nz.co.transparent.client.db.conf" "select * from Client"
// Multi-user server:
// "jdbc:mckoi://localhost" "select * from Client"
// ===

public class TestJDBCConnection {

	// This test uses ConnectionPool.close() to check database corruption
	public static void main(String[] args) { 
		//
		// First we load the underlying JDBC driver.
		// You need this if you don't use the jdbc.drivers
		// system property.
		//
		System.out.println("Loading underlying JDBC driver.");
		// Register the Mckoi JDBC Driver
		try {
			Class.forName("com.mckoi.JDBCDriver").newInstance();
		} catch (Exception e) {
			System.out.println(
					"Unable to register the JDBC Driver.\n"
						+ "Make sure the JDBC driver is in the\n"
						+ "classpath.\n");
			return;
		}
		System.out.println("JDBC driver instantiated.");

		//
		// Now, we can use JDBC as we normally would.
		// Using the connect string
		//  jdbc:apache:commons:dbcp:example
		// The general form being:
		//  jdbc:apache:commons:dbcp:<name-of-pool>
		//

		Connection conn = null;
		PreparedStatement pstmt = null;
		Statement stmt = null;
		ResultSet rset = null;
		// Set url and sql
		String url = "jdbc:mckoi:local://resource/nz.co.transparent.client.db.conf";
		//String url = "jdbc:mckoi://localhost";
		String sql;
		boolean serverMode = true;
		int loopCount = 30;
				
		long startTime;
		long currentTime;
		System.out.println("Creating connection.");

		System.out.println("==> START");
		for (int i=1; i<=loopCount; i++) {
			System.out.println("==> i = " + i);
			startTime = new Date().getTime();
			try {
				if (serverMode) {
					conn = DriverManager.getConnection("jdbc:mckoi://localhost", "admin_user", "client00");
				} else {
					// Embedded mode
					conn = DriverManager.getConnection("jdbc:mckoi:local://resource/nz.co.transparent.client.db.conf", "admin_user", "client00");
				}
				
				conn.setAutoCommit(true);
				System.out.println("Connection time=" + (new Date().getTime() - startTime));
	
				System.out.println("Executing statement.");
				sql = "select * from Client where (ClientID=1)";
				stmt = conn.createStatement();
				rset = stmt.executeQuery(sql);
				rset.next();
				System.out.println("LastName=" + rset.getString("LastName"));
			} catch(SQLException e) {
				e.printStackTrace();
				try { pstmt.close(); } catch(Exception e1) { }
				try { conn.close(); } catch(Exception e2) { }
			}
		}
		
		try { stmt.close(); } catch(Exception e2) { }
		try { pstmt.close(); } catch(Exception e2) { }
		try { conn.close(); } catch(Exception e2) { }
		System.out.println("DBCP example: ready !");
	}
}
