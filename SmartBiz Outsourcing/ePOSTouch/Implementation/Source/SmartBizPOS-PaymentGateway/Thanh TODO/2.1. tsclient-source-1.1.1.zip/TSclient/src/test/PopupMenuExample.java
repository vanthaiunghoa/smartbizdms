/*
 * Created on Dec 5, 2003
 */
package test;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class PopupMenuExample
	extends JPanel
	implements ActionListener, PopupMenuListener, MouseListener {
	public JPopupMenu popup;

	public PopupMenuExample() {

		popup = new JPopupMenu();

		JMenuItem item;
		popup.add(item = new JMenuItem("Left"));
		item.setHorizontalTextPosition(SwingConstants.LEFT);
		item.addActionListener(this);

		popup.add(item = new JMenuItem("Center"));
		item.setHorizontalTextPosition(SwingConstants.CENTER);
		item.addActionListener(this);

		popup.add(item = new JMenuItem("Right"));
		item.setHorizontalTextPosition(SwingConstants.RIGHT);
		item.addActionListener(this);

		popup.addPopupMenuListener(this);

		addMouseListener(this);

	}

	public void mousePressed(MouseEvent event) {
		checkPopup(event);
	}

	public void mouseClicked(MouseEvent event) {
		checkPopup(event);
	}

	public void mouseEntered(MouseEvent event) {
	}

	public void mouseExited(MouseEvent event) {
	}

	public void mouseReleased(MouseEvent event) {
		checkPopup(event);
	}

	private void checkPopup(MouseEvent event) {
		if (event.isPopupTrigger()) {
			popup.show(this, event.getX(), event.getY());
		}
	}

	public void popupMenuWillBecomeVisible(PopupMenuEvent event) {
		System.out.println("popup menu will be visible!");
	}

	public void popupMenuWillBecomeInvisible(PopupMenuEvent event) {
		System.out.println("popup menu will be invisible!");
	}

	public void popupMenuCanceled(PopupMenuEvent event) {
		System.out.println("popup menu is hidden!");
	}

	public void actionPerformed(ActionEvent event) {
		System.out.println(
			"Popup menu item[" + event.getActionCommand() + "]was pressed.!");
	}

	public static void main(String s[]) {
		JFrame frame = new JFrame("popup menu example");
		frame.setContentPane(new PopupMenuExample());
		frame.setSize(300, 300);
		frame.setVisible(true);
	}
}