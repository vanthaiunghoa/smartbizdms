/*
 * Created on Oct 31, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import java.io.File;

import javax.swing.*;

/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class TestIcon extends JFrame {

	public static void main(String[] args) {
		new TestIcon().go();
	}
	
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected static ImageIcon createImageIconFromFile(String path,
											   String description) {
//		java.net.URL imgURL = TestIcon.class.getResource(path);
//		if (imgURL == null) {
//			System.err.println("Couldn't find file: " + path);
//			return null;
//		}
//		return new ImageIcon(imgURL, description);

		File file = new File(path);
		if (!file.exists()) {
			System.err.println("Couldn't find file: " + path);
			return null;
		}

		return new ImageIcon(path, description);
	}
	
	protected static ImageIcon createImageIconFromURL(String path,
											   String description) {
		java.net.URL imgURL = TestIcon.class.getResource(path);
		if (imgURL == null) {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
		return new ImageIcon(imgURL, description);
	}
	
	public void go() {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel topPanel = new JPanel();
		String userDir = System.getProperty("user.dir");
		ImageIcon icon1 = createImageIconFromFile(userDir + "/icons/org/javalobby/icons/20x20png/Battery.png",
									 "Image of a battery");
		ImageIcon icon2 = createImageIconFromFile(userDir + "/icons/org/javalobby/icons/32x32/Calculator.gif", 
										"Image of a calculator");
		ImageIcon icon3 = createImageIconFromFile(userDir + "/icons/toolbarButtonGraphics/general/About24.gif", 
										"Image of a About");
		JButton button1 = new JButton(icon1);
		topPanel.add(button1);
		JButton button2 = new JButton(icon2);
		topPanel.add(button2);
		JButton button3 = new JButton(icon3);
		topPanel.add(button3);
		this.getContentPane().add(topPanel);
		this.setSize(200, 300);
		this.show();
		//         /home/johnz/project/Satur/client/icons/20x20png/Battery.png
	}
}
