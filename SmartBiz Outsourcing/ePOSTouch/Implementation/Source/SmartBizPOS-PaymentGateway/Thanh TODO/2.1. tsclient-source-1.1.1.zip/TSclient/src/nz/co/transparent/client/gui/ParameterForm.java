/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Parameter.java
 *
 * Created on January 17, 2004
 */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.KeyboardFocusManager;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.*;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;


/**
 *
 * @author  John Zoetebier
 */
public class ParameterForm extends javax.swing.JInternalFrame {

	// Constants
	private static final int FIELD_LENGTH = 25;

	// Private variables
	private Map parameterMap = new HashMap();
	private Map personMap = new HashMap();
	private GenericController genericController = GenericController.getInstance();
	
	private JLabel parameterIDLabel = new JLabel("Parameter ID");
	private JLabel parameterKeyLabel = new JLabel("Parameter key");
	private JLabel parameterLabel = new JLabel("Parameter");
	private JLabel commentLabel = new JLabel("Comment");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	private JLabel dateCreatedLabel = new JLabel("Date created");
	private JLabel dateUpdatedLabel = new JLabel("Date updated");
	
	private DateFormat timeStampFormat = new SimpleDateFormat(Configuration.getProperty("format.timestamp", Constants.FORMAT_TIMESTAMP));

	private JTextField parameterIDField = new JTextField();
	private JTextField parameterKeyField = new JTextField();
	private JTextArea parameterField = new JTextArea(5, FIELD_LENGTH);
	private JTextArea commentField = new JTextArea(5, FIELD_LENGTH);
	private JTextField updaterPersonIDField = new JTextField();
	private JFormattedTextField dateCreatedField = new JFormattedTextField(timeStampFormat);
	private JFormattedTextField dateUpdatedField = new JFormattedTextField(timeStampFormat);
	
	private JPanel contentPanel = new JPanel();
	private JPanel middlePanel = new JPanel();	// To get dialogPanel left alligned
	private JPanel dialogPanel = new JPanel();

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();
	
	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public ParameterForm() {

		setName("Parameter form");
		setTitle("Parameter form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);
		addInternalFrameListener(new InternalFrameOpenedAdapter(this, parameterKeyField));

		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New parameter.");
		newButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				newButton_actionPerformed();
			 }
		});
		
		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		saveButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save parameter.");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(saveButton);

		reloadButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh parameter.");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		deleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete parameter.");
		deleteButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				deleteButton_actionPerformed(evt);
			 }
		});

		deleteButton.setEnabled(false);
		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));
		
		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setFocusTraversalPolicy(new InputOrderFocusTrafersalPolicy());
		dialogPanel.setFocusCycleRoot(true);

		// Dialog fields
		dialogPanel.add(parameterIDLabel);
		Dimension fieldDimension = new Dimension(200, parameterIDLabel.getPreferredSize().height);
		parameterIDField.setToolTipText("Generated by system.");
		parameterIDField.setEditable(false);
		parameterIDField.setColumns(FIELD_LENGTH);
		dialogPanel.add(parameterIDField);

		dialogPanel.add(parameterKeyLabel);
		dialogPanel.add(parameterKeyField);

		dialogPanel.add(parameterLabel);
		parameterField.setLineWrap(true);
		parameterField.setWrapStyleWord(true);	// wrap only on word boundary
		
		// Ensure tabs are handled by focus manager
		parameterField.setFocusTraversalKeys(
				KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,null);
		parameterField.setFocusTraversalKeys(
			KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,null);
		 
		JScrollPane parameterScrollPane = new JScrollPane(parameterField);
		dialogPanel.add(parameterScrollPane);

		dialogPanel.add(commentLabel);
		commentField.setLineWrap(true);
		commentField.setWrapStyleWord(true);	// wrap only on word boundary
		
		// Ensure tabs are handled by focus manager
		commentField.setFocusTraversalKeys(
				KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,null);
		commentField.setFocusTraversalKeys(
			KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,null);
		 
		JScrollPane commentScrollPane = new JScrollPane(commentField);
		dialogPanel.add(commentScrollPane);

		dialogPanel.add(updaterPersonIDLabel);
		updaterPersonIDField.setEditable(false);
		dialogPanel.add(updaterPersonIDField);

		dialogPanel.add(dateCreatedLabel);
		dateCreatedField.setEditable(false);
		dialogPanel.add(dateCreatedField);

		dialogPanel.add(dateUpdatedLabel);
		dateUpdatedField.setEditable(false);
		dialogPanel.add(dateUpdatedField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
		
		// Add dialogPanel to content panel 
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);

		pack();
	}

	/**
	 * Populate form using PK parameter_id
	 * @param parameterID PK parameter_id
	 */
	public void populateForm(int parameterID) {

		String msg = null;
		try {
			msg = "ParameterForm: Cannot find parameter: " + parameterID;
			parameterMap = genericController.findWhere("parameter", "parameter_id=" + parameterID);
			Integer personID = (Integer) parameterMap.get("updater_person_id");
			personMap = Updater.getUpdater(personID.intValue());
		} catch (ControllerException ce) {
			Messager.exception(this, msg + "\n" + ce.getMessage());
			return;
		} catch (FinderException fe) {
			Messager.exception(this, msg  + "\n" + fe.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		parameterIDField.setText(String.valueOf(parameterMap.get("parameter_id").toString()));
		parameterKeyField.setText(parameterMap.get("parameter_key").toString());
		parameterKeyField.setEditable(false);
		parameterKeyField.setBackground(Color.decode("#cccccc"));
		parameterField.setText(parameterMap.get("parameter").toString());

		if (parameterMap.get("comment") == null) {
			commentField.setText("");
		} else {
			commentField.setText(parameterMap.get("comment").toString());
		}
		
		commentField.setEditable(false);
		commentField.setBackground(Color.decode("#cccccc"));
		updaterPersonIDField.setText(personMap.get("user_name").toString());
		dateCreatedField.setValue(parameterMap.get("date_created"));
		dateUpdatedField.setValue(parameterMap.get("date_updated"));
	}
	
	/**
	 * Populate new form
	 * 
	 */
	public void populateNewForm() {

		newButton_actionPerformed();
	}

	private void deleteButton_actionPerformed(ActionEvent evt) {
		String msg = null;

		if (parameterMap.get("parameter_id") == null) {
			msg = "New parameter cannot be deleted";
			Messager.information(this, msg);
			return;
		}

		msg = "Continue to delete parameter ?";
		if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
			return;
		}
			
		try {
			Integer parameterID = (Integer) parameterMap.get("parameter_id");
			genericController.deleteRecord("parameter", "parameter_id=" + parameterID.intValue());
			newButton_actionPerformed();
		} catch (ControllerException ce) {
			Messager.exception(this, "ParameterForm: Error deleting parameter.\n" + ce.getMessage());
			return;
		}
	}

	private void newButton_actionPerformed() {

		parameterMap.put("parameter_id", null);
		personMap = LoginController.getPerson();

		GenericUtils.resetInputFields(dialogPanel);
		Map contactTypeMap = null;
		
		parameterIDField.setText(null);
		parameterKeyField.setText(null);
		parameterKeyField.setEditable(true);
		parameterKeyField.setBackground(Color.WHITE);
		parameterField.setText(null);
		commentField.setText(null);
		commentField.setEditable(true);
		commentField.setBackground(Color.WHITE);
		updaterPersonIDField.setText((String) LoginController.getPerson().get("user_name"));
		dateCreatedField.setValue(new Date());
		dateUpdatedField.setValue(new Date());
	}

	private void saveButton_actionPerformed(ActionEvent evt) {
		
		if (!validateForm()) {
			return;
		}
		
		// Store fields in parameterMap 
		// Convert display values to foreign keys before passing parameterMap to nz.co.transparent.client.controller
		parameterMap.put("parameter_id", parameterMap.get("parameter_id"));
		parameterMap.put("parameter_key", parameterKeyField.getText());
		parameterMap.put("parameter", parameterField.getText());
		parameterMap.put("comment", commentField.getText());
		parameterMap.put("updater_person_id", LoginController.getPerson().get("person_id"));
		parameterMap.put("date_created", dateCreatedField.getValue());
		parameterMap.put("date_updated", dateUpdatedField.getValue());

		try {
			if (parameterIDField.getText().equals("")) {
				parameterMap.put("parameter_id", null); 	// Generate key
				genericController.insertRecord("parameter", "parameter_id", parameterMap);
			} else {
				// Cast to Integer, otherwise record lookup and update will fail
				parameterMap.put("parameter_id", Integer.valueOf(parameterIDField.getText()));
				genericController.updateRecord("parameter", "parameter_id", parameterMap);
			}

			// Store parameter in cache
			Parameter.setParameter(parameterMap.get("parameter_key"). toString(), parameterMap.get("parameter"). toString());
			Integer parameterID = (Integer) parameterMap.get("parameter_id");
			populateForm(parameterID.intValue());
		} catch (UpdaterException ue) {
			String message = "Update warning !\n";
			message += "Changes have been made by an other person or process.\n";
			message += "Form will be refreshed with latest values";
			Messager.warning(this, message);
			this.populateForm(Integer.parseInt(parameterMap.get("parameter_id").toString()));
		} catch (ControllerException ce) {
			Messager.exception(this, "Error: " + ce.getMessage());
		}
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogPanel);

//		if (parameterField.getText().equals("")) {
//			parameterField.setBackground(Color.YELLOW);
//			parameterField.setToolTipText("Please enter parameter");
//			parameterField.requestFocus();
//			validationOk = false;
//		}

		if (parameterKeyField.getText().equals("")) {
			parameterKeyField.setBackground(Color.YELLOW);
			parameterKeyField.setToolTipText("Please enter parameter key");
			parameterKeyField.requestFocus();
			validationOk = false;
		}

		return validationOk;
	}
	
	private void reloadButton_actionPerformed(ActionEvent evt) {
		Integer parameterID = (Integer) parameterMap.get("parameter_id");
		
		if (parameterID == null) {
			this.newButton_actionPerformed();
		} else {
			this.populateForm(parameterID.intValue());
		}
	}
}