/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 *
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

 /*
  * Client.java
  *
  * Created on November 17, 2003, 14:08 PM
  */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.KeyboardFocusManager;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

import javax.swing.*;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;

/**
 * @author John Zoetebier
 */
public class ClientForm extends javax.swing.JInternalFrame {
    
    // Constants
    private static final int FIELD_LENGTH = 14;
    private static final int FIELD_LENGTH_SHORT = 13;
    
    // Private variables
    private Map clientMap = new HashMap();
    private Map personMap = new HashMap();
    private List titleList;
    private List countryList;
    private List insuranceCompanyList;
    private List occupationList;
    private Logger log = Logger.getLogger("nz.co.transparent.client.gui");
    private GenericController genericController =
    GenericController.getInstance();
    private SpecificController specificController =
    SpecificController.getInstance();
    
    private JLabel clientIDLabel = new JLabel("Client ID");
    private JLabel lastNameLabel = new JLabel("Last name");
    private JLabel firstNameLabel = new JLabel("First name");
    private JLabel titleIDLabel = new JLabel("Title");
    private JLabel occupationIDLabel = new JLabel("Occupation");
    private JLabel address1Label = new JLabel("Address 1");
    private JLabel address2Label = new JLabel("Address 2");
    private JLabel suburbLabel = new JLabel("Suburb");
    private JLabel cityLabel = new JLabel("City");
    private JLabel postCodeLabel = new JLabel("Postcode");
    private JLabel countryIDLabel = new JLabel("Country");
    private JLabel dateOfBirthLabel = new JLabel("Date of birth");
    private JLabel nameLastDentistLabel = new JLabel("Name last dentist");
    private JLabel referrerLabel = new JLabel("Referrer");
    private JLabel nameParentLabel = new JLabel("Name parent");
    private JLabel addressParentLabel = new JLabel("Address parent");
    private JLabel insuranceCompanyIDLabel = new JLabel("Insurance company");
    private JLabel medicalPracticionerLabel =
    new JLabel("Medical practicioner");
    private JLabel commentLabel = new JLabel("Comment");
    private JLabel updaterPersonIDLabel = new JLabel("Updater");
    private JLabel dateCreatedLabel = new JLabel("Date created");
    private JLabel dateUpdatedLabel = new JLabel("Date updated");
    
    private DateFormat shortDateFormat =
    new SimpleDateFormat(
    Parameter.getParameter("format.shortdate", "dd/MM/yyyy"));
    private DateFormat timeStampFormat =
    new SimpleDateFormat(
    Parameter.getParameter(
    "format.timestamp",
    "yyyy-MM-dd HH:mm:ss.S z"));
    
    private JTextField clientIDField = new JTextField();
    private JTextField lastNameField = new JTextField();
    private JTextField firstNameField = new JTextField();
    private JComboBox titleIDField = new JComboBox();
    private JComboBox occupationIDField = new JComboBox();
    private JTextField address1Field = new JTextField();
    private JTextField address2Field = new JTextField();
    private JTextField suburbField = new JTextField();
    private JTextField cityField = new JTextField();
    private JTextField postCodeField = new JTextField();
    private JComboBox countryIDField = new JComboBox();
    private JFormattedTextField dateOfBirthField =
    new JFormattedTextField(shortDateFormat);
    private JTextField nameLastDentistField = new JTextField();
    private JTextField referrerField = new JTextField();
    private JTextField nameParentField = new JTextField();
    private JTextField addressParentField = new JTextField();
    private JComboBox insuranceCompanyIDField = new JComboBox();
    private JTextField medicalPracticionerField = new JTextField();
    private JTextArea commentField = new JTextArea(4, FIELD_LENGTH);
    private JTextField updaterPersonIDField = new JTextField();
    private JFormattedTextField dateCreatedField =
    new JFormattedTextField(timeStampFormat);
    private JFormattedTextField dateUpdatedField =
    new JFormattedTextField(timeStampFormat);
    
    private JPanel contentPane = new JPanel();
    private JPanel middlePanel = new JPanel();
    // To get dialogForm1 left alligned
    private JPanel dialogForm1 = new JPanel();
    private JPanel dialogForm2 = new JPanel();
    private JPanel dialogForm3 = new JPanel();
    
    private JToolBar toolbarMain = new JToolBar();
    private JButton newButton = new JButton();
    private JButton saveButton = new JButton();
    private JButton reloadButton = new JButton();
    private JButton deleteButton = new JButton();
    
    private JTabbedPane tabbedPane =
    new JTabbedPane(SwingConstants.TOP, JTabbedPane.WRAP_TAB_LAYOUT);
    
    private ContactDetailTableForm contactDetailTableForm;
    private PrescriptionTableForm prescriptionTableForm;
    private InvoiceTableForm invoiceTableForm;
    
    /** Creates new ClientForm */
    public ClientForm() {
        initComponents();
    }
    
    /**
     * This method is called from within the constructor to initialize the
     * form.
     */
    private void initComponents() {
        
        setName("Client form");
        setTitle("Client form");
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        setPreferredSize(new java.awt.Dimension(600, 500));
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
        setContentPane(contentPane);
        addInternalFrameListener(
        new InternalFrameOpenedAdapter(this, lastNameField));
        
        toolbarMain.setBorder(BorderFactory.createEtchedBorder());
        toolbarMain.setFloatable(false);
        
        newButton.setIcon(
        new javax.swing.ImageIcon(
        getClass().getResource(
        "/toolbarButtonGraphics/general/New24.gif")));
        newButton.setMnemonic(KeyEvent.VK_N);
        newButton.setToolTipText("New client.");
        newButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                newButton_actionPerformed();
            }
        });
        
        toolbarMain.add(newButton);
        toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));
        
        saveButton.setIcon(
        new ImageIcon(
        getClass().getResource(
        "/toolbarButtonGraphics/general/Save24.gif")));
        saveButton.setMnemonic(KeyEvent.VK_S);
        saveButton.setToolTipText("Save client.");
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                saveButton_actionPerformed(evt);
            }
        });
        
        toolbarMain.add(saveButton);
        
        reloadButton.setIcon(
        new ImageIcon(
        getClass().getResource(
        "/toolbarButtonGraphics/general/Refresh24.gif")));
        reloadButton.setMnemonic(KeyEvent.VK_R);
        reloadButton.setToolTipText("Refresh client.");
        reloadButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                reloadButton_actionPerformed(evt);
            }
        });
        
        toolbarMain.add(reloadButton);
        toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));
        
        deleteButton.setIcon(
        new javax.swing.ImageIcon(
        getClass().getResource(
        "/toolbarButtonGraphics/general/Delete24.gif")));
        deleteButton.setMnemonic(KeyEvent.VK_D);
        deleteButton.setToolTipText("Delete client.");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                deleteButton_actionPerformed(evt);
            }
        });
        
        toolbarMain.add(deleteButton);
        toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));
        
        // make buttons left aligned
        toolbarMain.add(Box.createHorizontalGlue());
        contentPane.add(toolbarMain);
        
        dialogForm1.setLayout(new DialogLayout());
        dialogForm2.setLayout(new DialogLayout());
        dialogForm3.setLayout(new DialogLayout());
        
        // Create helper panel with gridbag layout
        //		dialogForm1.setFocusTraversalPolicy(new
        // InputOrderFocusTrafersalPolicy());
        //		dialogForm1.setFocusCycleRoot(true); // This will force focus go
        // down the colum
        
        // Setup dialog form
        dialogForm1.add(clientIDLabel);
        clientIDField.setColumns(FIELD_LENGTH);
        clientIDField.setToolTipText("Generated by system.");
        clientIDField.setEditable(false);
        dialogForm1.add(clientIDField);
        
        dialogForm1.add(lastNameLabel);
        lastNameField.setColumns(FIELD_LENGTH);
        Dimension fieldDimension = lastNameField.getPreferredSize();
        dialogForm1.add(lastNameField);
        
        dialogForm1.add(firstNameLabel);
        firstNameField.setColumns(FIELD_LENGTH);
        dialogForm1.add(firstNameField);
        
        dialogForm1.add(titleIDLabel);
        titleIDField.setEditable(true);
        titleIDField.setPreferredSize(
        new Dimension(
        fieldDimension.width,
        titleIDField.getPreferredSize().height));
        dialogForm1.add(titleIDField);
        
        dialogForm1.add(occupationIDLabel);
        occupationIDField.setEditable(true);
        occupationIDField.setPreferredSize(
        new Dimension(
        fieldDimension.width,
        occupationIDField.getPreferredSize().height));
        dialogForm1.add(occupationIDField);
        
        dialogForm1.add(address1Label);
        address1Field.setColumns(FIELD_LENGTH);
        dialogForm1.add(address1Field);
        
        dialogForm1.add(address2Label);
        address2Field.setColumns(FIELD_LENGTH);
        dialogForm1.add(address2Field);
        
        dialogForm1.add(suburbLabel);
        suburbField.setColumns(FIELD_LENGTH);
        dialogForm1.add(suburbField);
        
        // Set dialog form 2
        dialogForm2.add(cityLabel);
        cityField.setColumns(FIELD_LENGTH);
        dialogForm2.add(cityField);
        
        dialogForm2.add(postCodeLabel);
        postCodeField.setColumns(FIELD_LENGTH);
        dialogForm2.add(postCodeField);
        
        dialogForm2.add(countryIDLabel);
        countryIDField.setEditable(true);
        countryIDField.setPreferredSize(
        new Dimension(
        fieldDimension.width,
        countryIDField.getPreferredSize().height));
        dialogForm2.add(countryIDField);
        
        dialogForm2.add(dateOfBirthLabel);
        dateOfBirthField.setColumns(FIELD_LENGTH);
        dialogForm2.add(dateOfBirthField);
        
        dialogForm2.add(nameLastDentistLabel);
        nameLastDentistField.setColumns(FIELD_LENGTH);
        dialogForm2.add(nameLastDentistField);
        
        dialogForm2.add(referrerLabel);
        referrerField.setColumns(FIELD_LENGTH);
        dialogForm2.add(referrerField);
        
        dialogForm2.add(nameParentLabel);
        nameParentField.setColumns(FIELD_LENGTH);
        dialogForm2.add(nameParentField);
        
        dialogForm2.add(addressParentLabel);
        addressParentField.setColumns(FIELD_LENGTH);
        dialogForm2.add(addressParentField);
        
        // Set dialog form 3
        dialogForm3.add(insuranceCompanyIDLabel);
        insuranceCompanyIDField.setEditable(true);
        insuranceCompanyIDField.setPreferredSize(
        new Dimension(
        fieldDimension.width,
        insuranceCompanyIDField.getPreferredSize().height));
        dialogForm3.add(insuranceCompanyIDField);
        
        dialogForm3.add(medicalPracticionerLabel);
        medicalPracticionerField.setColumns(FIELD_LENGTH);
        dialogForm3.add(medicalPracticionerField);
        
        dialogForm3.add(commentLabel);
        commentField.setLineWrap(true);
        commentField.setWrapStyleWord(true); // wrap only on
        // word boundary
        // Ensure tabs are handled by focus manager
        commentField.setFocusTraversalKeys(
        KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,
        null);
        commentField.setFocusTraversalKeys(
        KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,
        null);
        JScrollPane commentScrollPane = new JScrollPane(commentField);
        dialogForm3.add(commentScrollPane);
        
        dialogForm3.add(updaterPersonIDLabel);
        updaterPersonIDField.setColumns(FIELD_LENGTH_SHORT);
        updaterPersonIDField.setEditable(false);
        dialogForm3.add(updaterPersonIDField);
        
        dialogForm3.add(dateCreatedLabel);
        dateCreatedField.setColumns(FIELD_LENGTH_SHORT);
        dateCreatedField.setEditable(false);
        dialogForm3.add(dateCreatedField);
        
        dialogForm3.add(dateUpdatedLabel);
        dateUpdatedField.setColumns(FIELD_LENGTH_SHORT);
        dateUpdatedField.setEditable(false);
        dialogForm3.add(dateUpdatedField);
        
        // Add dialogForm to content panel
        middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.X_AXIS));
        middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
        middlePanel.setFocusCycleRoot(true);
        middlePanel.setFocusTraversalPolicy(
        new InputOrderFocusTrafersalPolicy());
        middlePanel.add(dialogForm1);
        middlePanel.add(Box.createHorizontalStrut(10));
        middlePanel.add(dialogForm2);
        middlePanel.add(Box.createHorizontalStrut(10));
        middlePanel.add(dialogForm3);
        middlePanel.add(Box.createHorizontalStrut(500));
        
        contentPane.add(middlePanel);
        
        //===========================================
        // Create contact detail table
        //===========================================
        contactDetailTableForm = new ContactDetailTableForm();
        tabbedPane.addTab("Contact detail", contactDetailTableForm);
        
        //===========================================
        // Create prescription table
        //===========================================
        prescriptionTableForm = new PrescriptionTableForm();
        tabbedPane.addTab("Prescription", prescriptionTableForm);
        
        //===========================================
        // Create invoice panel
        //===========================================
        invoiceTableForm = new InvoiceTableForm();
        tabbedPane.addTab("Invoice", invoiceTableForm);
        
        //===========================================
        // Add tabbed pane to content pane
        //===========================================
        contentPane.add(tabbedPane);
        pack();
    }
    
    /**
     * Populate form using PK client_id
     *
     * @param clientID
     *                PK client_id
     */
    public void populateForm(int clientID) {
        
        String msg = null;
        try {
            msg = "ClientForm: Cannot find client: " + clientID;
            clientMap =
            genericController.findWhere("client", "client_id=" + clientID);
            
            Integer personID = (Integer) clientMap.get("updater_person_id");
            personMap = Updater.getUpdater(personID.intValue());
            
            msg = "ClientForm: Cannot find titles";
            titleList = genericController.findAll("title", "title_code");
            msg = "ClientForm: Cannot find countries";
            countryList = genericController.findAll("country", "country");
            msg = "ClientForm: insurance occupations";
            occupationList =
            genericController.findAll("occupation", "occupation");
            msg = "ClientForm: insurance companies";
            insuranceCompanyList =
            genericController.findAll(
            "insurance_company",
            "insurance_company");
        } catch (ControllerException ce) {
            Messager.exception(this, msg + "\n" + ce.getMessage());
            return;
        } catch (FinderException fe) {
            Messager.exception(this, msg + "\n" + fe.getMessage());
            return;
        }
        
        GenericUtils.resetInputFields(dialogForm3);
        GenericUtils.resetInputFields(dialogForm2);
        GenericUtils.resetInputFields(dialogForm1);
        // Fill comboboxes
        GenericUtils.updateJComboBox(
        titleIDField,
        titleList,
        "title_code",
        "title_id",
        (Integer) clientMap.get("title_id"));
        GenericUtils.updateJComboBox(
        countryIDField,
        countryList,
        "country",
        "country_id",
        (Integer) clientMap.get("country_id"));
        GenericUtils.updateJComboBox(
        occupationIDField,
        occupationList,
        "occupation",
        "occupation_id",
        (Integer) clientMap.get("occupation_id"));
        GenericUtils.updateJComboBox(
        insuranceCompanyIDField,
        insuranceCompanyList,
        "insurance_company",
        "insurance_company_id",
        (Integer) clientMap.get("insurance_company_id"));
        
        clientIDField.setText(
        String.valueOf(clientMap.get("client_id").toString()));
        lastNameField.setText((String) clientMap.get("last_name"));
        firstNameField.setText((String) clientMap.get("first_name"));
        address1Field.setText((String) clientMap.get("address1"));
        address2Field.setText((String) clientMap.get("address2"));
        suburbField.setText((String) clientMap.get("suburb"));
        cityField.setText((String) clientMap.get("city"));
        postCodeField.setText((String) clientMap.get("postcode"));
        dateOfBirthField.setValue(clientMap.get("date_of_birth"));
        nameLastDentistField.setText(
        (String) clientMap.get("name_last_dentist"));
        referrerField.setText((String) clientMap.get("referrer"));
        nameParentField.setText((String) clientMap.get("name_parent"));
        addressParentField.setText((String) clientMap.get("address_parent"));
        medicalPracticionerField.setText((String) clientMap.get("medical_practicioner"));
        commentField.setText((String) clientMap.get("comment"));
        updaterPersonIDField.setText((String) personMap.get("user_name"));
        dateCreatedField.setValue(clientMap.get("date_created"));
        dateUpdatedField.setValue(clientMap.get("date_updated"));
        
        // Set tables
        contactDetailTableForm.updateTable(clientMap);
        prescriptionTableForm.updateTable(clientMap);
        invoiceTableForm.updateTable(clientMap);
    }
    
    /**
     * Populate new form
     *
     */
    public void populateNewForm() {
        
        newButton_actionPerformed();
    }
    
    private void deleteButton_actionPerformed(ActionEvent evt) {
        String msg = null;
        
        if (clientMap.get("client_id") == null) {
            msg = "New client cannot be deleted";
            Messager.information(this, msg);
            return;
        }
        
        msg = "Continue to delete client and contact details ?";
        if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
            return;
        }
        
        Integer clientID = null;
        try {
            clientID = (Integer) clientMap.get("client_id");
            genericController.deleteRecord(
            "client",
            "client_id=" + clientID.intValue());
            newButton_actionPerformed();
        } catch (ControllerException ce) {
            Messager.exception(
            this,
            "ClientForm: Error deleting client.\n" + ce.getMessage());
            return;
        }
    }
    
    private void newButton_actionPerformed() {
        
        try {
            clientMap.put("client_id", null);
            personMap = LoginController.getPerson();
            titleList = genericController.findAll("title", "title_code");
            countryList = genericController.findAll("country", "country");
            occupationList =
            genericController.findAll("occupation", "occupation");
            insuranceCompanyList =
            genericController.findAll(
            "insurance_company",
            "insurance_company");
        } catch (ControllerException ce) {
            Messager.exception(
            this,
            "ClientForm: Error getting client data" + ce.getMessage());
            return;
        }
        
        GenericUtils.resetInputFields(dialogForm3);
        GenericUtils.resetInputFields(dialogForm2);
        GenericUtils.resetInputFields(dialogForm1);
        Map titleMap = null;
        Map countryMap = null;
        Map occupationMap = null;
        Map insuranceCompanyMap = null;
        
        // Fill combobox
        GenericUtils.updateJComboBox(titleIDField, titleList, "title_code");
        GenericUtils.updateJComboBox(countryIDField, countryList, "country");
        GenericUtils.updateJComboBox(
        occupationIDField,
        occupationList,
        "occupation");
        GenericUtils.updateJComboBox(
        insuranceCompanyIDField,
        insuranceCompanyList,
        "insurance_company");
        
        clientIDField.setText(null);
        lastNameField.setText(null);
        firstNameField.setText(null);
        address1Field.setText(null);
        address2Field.setText(null);
        suburbField.setText(null);
        cityField.setText(null);
        dateOfBirthField.setValue(null);
        String dateFormat =
        Parameter.getParameter("format.shortdate", "dd/MM/yyyy");
        dateFormat = dateFormat.toLowerCase();
        dateOfBirthField.setToolTipText("Date format: " + dateFormat);
        dateOfBirthField.setText(null);
        nameLastDentistField.setText(null);
        referrerField.setText(null);
        nameParentField.setText(null);
        addressParentField.setText(null);
        medicalPracticionerField.setText(null);
        commentField.setText(null);
        updaterPersonIDField.setText(
        (String) LoginController.getPerson().get("user_name"));
        dateCreatedField.setValue(new Date());
        dateUpdatedField.setValue(new Date());
        
        // Set tables
        contactDetailTableForm.updateTable(clientMap);
        prescriptionTableForm.updateTable(clientMap);
        invoiceTableForm.updateTable(clientMap);
    }
    
    private void saveButton_actionPerformed(ActionEvent evt) {
        
        if (!validateForm()) {
            return;
        }
        
        // Store fields in clientMap
        // Convert display values to foreign keys before passing clientMap to
        // nz.co.transparent.client.controller
        clientMap.put("first_name", firstNameField.getText());
        clientMap.put("last_name", lastNameField.getText());
        clientMap.put(
        "title_id",
        GenericUtils.getKey(
        titleList,
        "title_id",
        "title_code",
        (String) titleIDField.getSelectedItem()));
        clientMap.put(
        "occupation_id",
        GenericUtils.getKey(
        occupationList,
        "occupation_id",
        "occupation",
        (String) occupationIDField.getSelectedItem()));
        clientMap.put("address1", address1Field.getText());
        clientMap.put("address2", address2Field.getText());
        clientMap.put("suburb", suburbField.getText());
        clientMap.put("city", cityField.getText());
        clientMap.put("postcode", postCodeField.getText());
        clientMap.put(
        "country_id",
        GenericUtils.getKey(
        countryList,
        "country_id",
        "country",
        (String) countryIDField.getSelectedItem()));
        clientMap.put("date_of_birth", dateOfBirthField.getValue());
        clientMap.put("name_last_dentist", nameLastDentistField.getText());
        clientMap.put("name_parent", nameParentField.getText());
        clientMap.put("address_parent", addressParentField.getText());
        clientMap.put(
        "insurance_company_id",
        GenericUtils.getKey(
        insuranceCompanyList,
        "insurance_company_id",
        "insurance_company",
        (String) insuranceCompanyIDField.getSelectedItem()));
        clientMap.put(
        "medical_practicioner",
        medicalPracticionerField.getText());
        clientMap.put("comment", commentField.getText());
        clientMap.put(
        "updater_person_id",
        LoginController.getPerson().get("person_id"));
        clientMap.put("date_created", dateCreatedField.getValue());
        clientMap.put("date_updated", dateUpdatedField.getValue());
        
        try {
            if (clientIDField.getText().equals("")) {
                clientMap.put("client_id", null); // Generate key
                genericController.insertRecord(
                "client",
                "client_id",
                clientMap);
                
                // Update tables
                contactDetailTableForm.updateTable(clientMap);
                prescriptionTableForm.updateTable(clientMap);
            } else {
                clientMap.put(
                "client_id",
                Integer.valueOf(clientIDField.getText()));
                // Cast to Integer, otherwise record lookup and update will
                // fail
                genericController.updateRecord(
                "client",
                "client_id",
                clientMap);
            }
            
            Integer clientID = (Integer) clientMap.get("client_id");
            populateForm(clientID.intValue());
        } catch (UpdaterException ue) {
            String message = "Update warning !\n";
            message
            += "Changes have been made by an other person or process.\n";
            message += "Form will be refreshed with latest values";
            Messager.warning(this, message);
            populateForm(
            Integer.parseInt(clientMap.get("client_id").toString()));
        } catch (ControllerException ce) {
            Messager.exception(this, "Error: " + ce.getMessage());
        }
    }
    
    private boolean validateForm() {
        
        boolean validationOk = true;
        GenericUtils.resetInputFields(dialogForm3);
        GenericUtils.resetInputFields(dialogForm2);
        GenericUtils.resetInputFields(dialogForm1);
        
        if (cityField.getText().equals("")) {
            cityField.setBackground(Color.YELLOW);
            cityField.setToolTipText("Please enter City");
            cityField.requestFocus();
            validationOk = false;
        }
        
        if (address1Field.getText().equals("")) {
            address1Field.setBackground(Color.YELLOW);
            address1Field.setToolTipText("Please enter Address 1");
            address1Field.requestFocus();
            validationOk = false;
        }
        
        if (firstNameField.getText().equals("")) {
            firstNameField.setBackground(Color.YELLOW);
            firstNameField.setToolTipText("Please enter First name");
            firstNameField.requestFocus();
            validationOk = false;
        }
        
        if (lastNameField.getText().equals("")) {
            lastNameField.setBackground(Color.YELLOW);
            lastNameField.setToolTipText("Please enter Last name");
            lastNameField.requestFocus();
            validationOk = false;
        }
        
        if (titleIDField.getSelectedItem() == null || titleIDField.getSelectedItem().equals("")) {
            titleIDField.getEditor().getEditorComponent().setBackground(
            Color.YELLOW);
            titleIDField.setToolTipText("Please enter Title");
            titleIDField.requestFocus();
            validationOk = false;
        }
        
        if (countryIDField.getSelectedItem() == null || countryIDField.getSelectedItem().equals("")) {
            countryIDField.getEditor().getEditorComponent().setBackground(
            Color.YELLOW);
            countryIDField.setToolTipText("Please enter Country");
            countryIDField.requestFocus();
            validationOk = false;
        }
        
        if (occupationIDField.getSelectedItem() == null || occupationIDField.getSelectedItem().equals("")) {
            occupationIDField.getEditor().getEditorComponent().setBackground(
            Color.YELLOW);
            occupationIDField.setToolTipText("Please enter Occupation");
            occupationIDField.requestFocus();
            validationOk = false;
        }
        
        if (insuranceCompanyIDField.getSelectedItem() == null || insuranceCompanyIDField.getSelectedItem().equals("")) {
            insuranceCompanyIDField
            .getEditor()
            .getEditorComponent()
            .setBackground(
            Color.YELLOW);
            insuranceCompanyIDField.setToolTipText(
            "Please enter Insurance company");
            insuranceCompanyIDField.requestFocus();
            validationOk = false;
        }
        
        // Check if new item entered in combobox
        String msg = null;
        try {
            if (titleIDField.getSelectedIndex() == -1) {
                // Add new title silently
                Integer titleID =
                specificController.getForeignKeyTitle(
                (String) titleIDField.getSelectedItem(),
                titleList);
                clientMap.put("title_id", titleID);
                GenericUtils.updateJComboBox(
                titleIDField,
                titleList,
                "title_code",
                "title_id",
                (Integer) clientMap.get("title_id"));
            }
            
            if (countryIDField.getSelectedIndex() == -1) {
                // Add new country silently
                Integer countryID =
                genericController.getForeignKey(
                "country",
                (String) countryIDField.getSelectedItem(),
                "country",
                "country_id",
                countryList);
                clientMap.put("country_id", countryID);
                GenericUtils.updateJComboBox(
                countryIDField,
                countryList,
                "country",
                "country_id",
                (Integer) clientMap.get("country_id"));
            }
            
            if (occupationIDField.getSelectedIndex() == -1) {
                // Add new occupation silently
                Integer occupationID =
                genericController.getForeignKey(
                "occupation",
                (String) occupationIDField.getSelectedItem(),
                "occupation",
                "occupation_id",
                occupationList);
                clientMap.put("occupation_id", occupationID);
                GenericUtils.updateJComboBox(
                occupationIDField,
                occupationList,
                "occupation",
                "occupation_id",
                (Integer) clientMap.get("occupation_id"));
            }
            
            if (insuranceCompanyIDField.getSelectedIndex() == -1) {
                // Add new occupation silently
                Integer insuranceCompanyID =
                genericController.getForeignKey(
                "insurance_company",
                (String) insuranceCompanyIDField.getSelectedItem(),
                "insurance_company",
                "insurance_company_id",
                insuranceCompanyList);
                clientMap.put("insurance_company_id", insuranceCompanyID);
                GenericUtils.updateJComboBox(
                insuranceCompanyIDField,
                insuranceCompanyList,
                "insurance_company",
                "insurance_company_id",
                (Integer) clientMap.get("insurance_company_id"));
            }
            
            return validationOk;
        } catch (ControllerException ce) {
            msg = "Controller error: " + ce.getMessage();
            log.warning(msg);
            Messager.exception(this, msg);
            return false;
        }
    }
    
    private void reloadButton_actionPerformed(ActionEvent evt) {
        Integer clientID = (Integer) clientMap.get("client_id");
        
        if (clientID == null) {
            newButton_actionPerformed();
        } else {
            populateForm(clientID.intValue());
        }
    }
}