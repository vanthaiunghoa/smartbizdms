/*
 * Created on Nov 14, 2003
 * 
 * To change the template for this generated file go to Window - Preferences -
 * Java - Code Generation - Code and Comments
 */
package test;

import java.sql.*;
import java.util.logging.Logger;

import nz.co.transparent.client.db.PoolingDriverHandler;

import nz.co.transparent.client.util.Constants;

/**
 * @author johnz
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class TestClientMetaData {

	Logger log = Logger.getLogger("test");

	private void go() {

		Connection conn;
		Statement stmt;
		ResultSet clientResultSet;
		ResultSetMetaData clientMetaData;
		String sql;
		int numRecords = 0;

		try {
			// Get connection from the connection pool
			conn = DriverManager.getConnection(Constants.JDBC_URL);
			stmt = conn.createStatement();
			sql = "select * from Client, ContactDetail, ContactType";
			sql += " where (";
			sql += "	(Client.ClientID=ContactDetail.ClientID)";
			sql += "	and (ContactDetail.ContactTypeID=ContactType.ContactTypeID)";
			sql += "	and (Client.ClientID=1)";
			sql += ")";
			clientResultSet = stmt.executeQuery(sql);
			clientMetaData = clientResultSet.getMetaData();
			
			for (int i=1; i<=clientMetaData.getColumnCount(); i++) {
				System.out.println("==============================");
				System.out.println(clientMetaData.getColumnName(i) + ": ");
				System.out.println("    ColumnDisplaySize: " + clientMetaData.getColumnDisplaySize(i));
				System.out.println("    ColumnLabel: " + clientMetaData.getColumnLabel(i));
				System.out.println("    ColumnType: " + clientMetaData.getColumnType(i));
				System.out.println("    ColumnTypeName: " + clientMetaData.getColumnTypeName(i));
				System.out.println("    Precision: " + clientMetaData.getPrecision(i));
				System.out.println("    Scale: " + clientMetaData.getScale(i));
				System.out.println("    AutoIncrement: " + clientMetaData.isAutoIncrement(i));
				System.out.println("    Currency: " + clientMetaData.isCurrency(i));
				System.out.println("    Searchable: " + clientMetaData.isSearchable(i));
			}
			
			while (clientResultSet.next()) {
				for (int i=1; i<=clientMetaData.getColumnCount(); i++) {
					System.out.println("==============================");
					System.out.println(clientMetaData.getColumnName(i) + ": ");
					System.out.println("    Value: " + clientResultSet.getObject(i));
				}
				
				break;
			}
			
			stmt.close();
			clientResultSet.close();
			conn.close(); // Will go back to pool
		} catch (SQLException se) {
			String message = "SQL Exception: " + se.getMessage();
			log.warning(message);
		}
	}

	public static void main(String args[]) {
		nz.co.transparent.client.db.PoolingDriverHandler dbcPool  =  new PoolingDriverHandler("client");
		new TestClientMetaData().go();
		dbcPool.closeConnectionPool();
	}
}
