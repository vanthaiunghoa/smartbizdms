/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Dec 10, 2003
 *
 */
package nz.co.transparent.client.gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyVetoException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Logger;

import javax.swing.*;

/**
 * @author johnz
 * 
 */
public class GridMenu {

	private Logger log = Logger.getLogger("nz.co.transparent.client.gui");
	private JMenu parentMenu;
	private JDesktopPane desktopPane;
	/**
	 * Map with {InternalFrame name, JInternalFrame instance}
	 */
	private int maxRows = 20;	//maximum number of rows
	private int maxColumns = 4;	//maximum number of columns
	private int currentColumnCount = 1;
	private boolean formDirty = true;	// Set when addding an internal frame
	private ArrayList internalFrameNameList = new ArrayList(); 
	private Map internalFrameMap = new HashMap();

	/**
	 * 
	 * @param parentMenu Parent menu which will get a child menu item for each internal frame added to this class
	 */
	public GridMenu(JDesktopPane desktopPane, JMenu parentMenu) {
		this.desktopPane = desktopPane;
		this.parentMenu = parentMenu;
	}
	
	/**
	 * 
	 * @param desktopPane Parent menu which will get a child menu item for each internal frame added to this class
	 * @param parentMenu Parent menu which will get a child menu item for each internal frame added to this class
	 * @param maxRows Maximum number of menu item rows
	 * @param maxColumns Maximum number of menu item columns
	 */
	public GridMenu(JDesktopPane desktopPane, JMenu parentMenu, int maxRows, int maxColumns) {
		this.desktopPane = desktopPane;
		this.parentMenu = parentMenu;
		this.maxRows = maxRows;
		this.maxColumns = maxColumns;
	}
	
	/**
	 * Add internal frame to desktop 
	 * @param internalFrame
	 */
	public void addInternalFrame(JInternalFrame internalFrame) 
		throws GUIException {
	
		JInternalFrame[] internalFrames = desktopPane.getAllFrames();
		if (internalFrames.length >= (maxRows * maxColumns)) {
			throw new GUIException("Error 100: Maximum number of menu items exceeded");
		}

		if (internalFrames.length != internalFrameNameList.size()) {
			refreshInternalFrames();
		}

		formDirty = true;
		// Set unique name for internal frame
		StringBuffer internalFrameName = new StringBuffer();
		if (internalFrame.getName() == null) {
			internalFrameName = new StringBuffer("<Unknown>");
		} else {
			internalFrameName = new StringBuffer(internalFrame.getName());
		}

		String internalFrameNameSave = new String(internalFrameName);
		int occurences = 1;

		for (int i=0; i<internalFrameNameList.size(); i++) {
			if (!internalFrameNameList.contains(internalFrameName.toString())) {
				break;
			}
			
			occurences++;
			internalFrameName.setLength(0);
			
			if (occurences < 10) {
				internalFrameName.append(internalFrameNameSave + " [0" +   occurences + "]");
			} else {
				internalFrameName.append(internalFrameNameSave + " [" +   occurences + "]");
			}
		}
		
		internalFrameNameList.add(internalFrameName.toString());
		internalFrame.setName(internalFrameName.toString());
		internalFrame.setTitle(internalFrameName.toString());
		// Show frame
		desktopPane.add(internalFrame);
		internalFrame.setVisible(true);
		try {
			internalFrame.setSelected(true);
		} catch(java.beans.PropertyVetoException pve) {
			System.out.println(pve.getMessage());
		}
	}
	
	public void refreshMenuItems() {
	
		JInternalFrame[] internalFrames = desktopPane.getAllFrames();
		if (internalFrames.length != internalFrameNameList.size()) {
			formDirty = true;
		}

		if (!formDirty) {
			return;
		}
		
		formDirty = false;	//reset flag
		
		refreshInternalFrames();
		parentMenu.removeAll();
		setMenuGridLayout(internalFrames.length);
		//Collections.sort(internalFrameNameList);
		Iterator iterator = internalFrameNameList.iterator();
		String internalFrameName  = null;

		while (iterator.hasNext()) {
			internalFrameName = (String) iterator.next();
			final JInternalFrame internalFrame = (JInternalFrame) internalFrameMap.get(internalFrameName);
			JMenuItem menuItem = new JMenuItem();
			menuItem.setText(internalFrame.getName());
			menuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						internalFrame.setSelected(true);
					} catch (PropertyVetoException pve) {
						log.warning(pve.getMessage());
						return;
					}
				}
			});

			parentMenu.add(menuItem);
		}
	}
	
	private void refreshInternalFrames() {
	
		// Remove non-existing internal frames from internalFrameNameList
		JInternalFrame[] internalFrames = desktopPane.getAllFrames();
		String internalFrameName = null;
		internalFrameMap = new HashMap(internalFrames.length);
		for (int i=0; i<internalFrames.length; i++) {
			internalFrameMap.put(internalFrames[i].getName(), internalFrames[i]);
		}

		ArrayList copyArrayList = new ArrayList();
		Iterator iterator = internalFrameNameList.iterator();
		while (iterator.hasNext()) {
			internalFrameName = (String) iterator.next();
			if (internalFrameMap.get(internalFrameName) != null) {
				copyArrayList.add(internalFrameName);
			}
		}
		
		internalFrameNameList.clear();
		internalFrameNameList = new ArrayList(copyArrayList);
		copyArrayList =null;
	}
	
	private void setMenuGridLayout(int internalFrameCount) {
		// Calculate grid layout
		if (maxRows >=  internalFrameCount) {
			parentMenu.getPopupMenu().setLayout(new GridLayout(internalFrameCount, 1));
			return;
		}
		
		int columnsNeeded;
		columnsNeeded = (internalFrameCount / maxRows);
		if ((internalFrameCount % maxRows) != 0) {
			columnsNeeded++;
		}
		
		if (columnsNeeded != currentColumnCount) {
			currentColumnCount = columnsNeeded;
			parentMenu.getPopupMenu().setLayout(new GridLayout(maxRows, currentColumnCount));
		}
	}
	
	/**
	 * @return Maximum number of rows
	 */
	public int getMaxRows() {
		return this.maxRows;
	}
	
	/**
	 * @param maxRows Maximum number of rows
	 */
	public void setMaxRows(int maxRows) {
		this.maxRows = maxRows;
	}
	
	/**
	 * 
	 * @return Maximum number of columns
	 */
	public int getMaxColumns() {
		return this.maxColumns;
	}
	
	/**
	 * 
	 * @param maxColumns Maximum number of columns
	 */
	public void setMaxColumns(int maxColumns) {
		this.maxColumns = maxColumns;
	}
	
}