/*
 * Created on Jan 16, 2004
 *
 */
package test;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import nz.co.transparent.client.util.Constants;
import nz.co.transparent.client.util.Parameter;

/**
 * @author John Zoetebier
 * 
 */
public class TestDate {

	/**
	 * 
	 */
	public TestDate() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public static void main(String[] args) {
		
		Date date = new Date();
		String pattern = Parameter.getParameter("format.shortdate", Constants.FORMAT_SHORT_DATE);
		SimpleDateFormat localDateFormat = new SimpleDateFormat(pattern, Locale.getDefault());
		System.out.println("Date=" + localDateFormat.format(date));
	}
}
