/*
 * Created on Jan 23, 2004
 *
 */
package test;

import nz.co.transparent.client.controller.SystemDBController;
import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.DataSourceHandler;

/**
 * @author John Zoetebier
 * 
 */
public class TestSystemDBController {

	/**
	 * 
	 */
	public TestSystemDBController() {
		super();
	}

	public static void main(String[] args) {
		
		DataSourceHandler.loadCredentialsFromConfig();
		SystemDBController controller = SystemDBController.getInstance();
		try {
//			nz.co.transparent.client.controller.createUser("test_user", "pass1");
//			nz.co.transparent.client.controller.dropUser("test_user");
//			nz.co.transparent.client.controller.alterUser("admin", "client00", "'secure access'");
			controller.alterUser("test_user", "pass1", "'secure access'");
			
			System.out.println("Ready");
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		}
	}
}
