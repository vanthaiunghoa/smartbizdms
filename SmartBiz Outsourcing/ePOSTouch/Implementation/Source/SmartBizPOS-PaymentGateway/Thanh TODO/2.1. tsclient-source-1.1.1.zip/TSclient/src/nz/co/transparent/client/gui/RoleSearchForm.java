/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * RoleSearch.java
 *
 * Created on Januari 6, 2004
 */

package nz.co.transparent.client.gui;

import nz.co.transparent.client.gui.util.DialogLayout;
import nz.co.transparent.client.gui.util.InternalFrameOpenedAdapter;

import java.awt.Dimension;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;

/**
 * 
 * @author John Zoetebier
 *
 */
public class RoleSearchForm extends javax.swing.JInternalFrame {
    
	private static final int FIELD_LENGTH =20; 
	
	private JLabel roleLabel = new JLabel("Role:");
	private JTextField roleField = new JTextField();
	private JPanel contentPane = new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();
	private JButton roleSearchButton = new JButton();
	private JToolBar mainToolBar = new JToolBar();
	private RoleTableForm roleTableForm;
	private Map searchMap;
	// End of variables declaration
    
	/** Creates new form RoleSearch */
	public RoleSearchForm() {
		setName("Role search");
		setTitle("Role search");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		setContentPane(contentPane);
		addInternalFrameListener(new InternalFrameOpenedAdapter(this, roleField));

		roleSearchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Find24.gif")));
		roleSearchButton.setMnemonic(KeyEvent.VK_E);
		roleSearchButton.setToolTipText("Enter one or more of the search fields. Then click me.");
		roleSearchButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				roleSearchButton_actionPerformed();
			 }
		});
		
		mainToolBar.setBorder(BorderFactory.createEtchedBorder());
		mainToolBar.setFloatable(false);
		mainToolBar.add(Box.createRigidArea(new Dimension(5,0)));
		mainToolBar.add(roleSearchButton);

		mainToolBar.add(Box.createHorizontalGlue());	// make buttons left aligned
		contentPane.add(mainToolBar);

		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));

		dialogPanel.add(roleLabel);
		roleField.setText("");
		roleField.setColumns(FIELD_LENGTH);
		roleField.setToolTipText("Role or part of it.");
		roleField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					roleSearchButton.doClick();
				}
			}
		});
		dialogPanel.add(roleField);

		middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.X_AXIS));
		middlePanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(20, 5, 20, 5)));
		middlePanel.add(dialogPanel);
		middlePanel.add(Box.createHorizontalStrut(700));

		contentPane.add(middlePanel);

		//===========================================
		// Create role table form
		//===========================================
		roleTableForm = new RoleTableForm();
		contentPane.add(roleTableForm);
		
		//===========================================
		// Pack
		//===========================================
		pack();
	}

	private void roleSearchButton_actionPerformed() {
		searchMap = new HashMap();
		searchMap.put("role", roleField.getText());
		roleTableForm.updateTable(searchMap);
	}
}