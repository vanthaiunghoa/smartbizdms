/*
 * Created on Feb 1, 2004
 *
 */
package test;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import nz.co.transparent.client.db.DataSourceHandler;

/**
 * @author John Zoetebier
 * 
 */
public class TestRollback {

	/**
	 * 
	 */
	public TestRollback() {
		super();
	}
	
	private static void returnError() 
		throws Error {
		
		if (true) {
			throw new Error("returnError(): Error thrown");
		}
	}

	public static void main(String[] args) {
		
		DataSourceHandler.loadCredentialsFromConfig();
		DataSource dataSource = DataSourceHandler.getDataSource();
		Connection conn = null;
		Statement stmt = null;
		String sql = null;
		sql = "insert into country" +
		" set country_id=11" +
		" , country='AAA'" +
		" , updater_person_id=1";
		
		try {
			conn = dataSource.getConnection();
			// First test with true to see if insert is working
			// Then remove record and test with false (transaction mode)  
			conn.setAutoCommit(false);
			stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			
			// If in transaction mode, throw error
			if (!conn.getAutoCommit()) {
				returnError();
			}
		
			conn.commit();
		} catch (SQLException se) {
			System.out.println("SQL error:\n" + se.getMessage());

			try {
				conn.rollback();
			} catch (SQLException se2) {
				System.out.println("SQL error:\n" + se2.getMessage());
			}
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				conn.close();
			} catch (SQLException se) {
				System.out.println("SQL error:\n" + se.getMessage());
			}
		}
	}
}
