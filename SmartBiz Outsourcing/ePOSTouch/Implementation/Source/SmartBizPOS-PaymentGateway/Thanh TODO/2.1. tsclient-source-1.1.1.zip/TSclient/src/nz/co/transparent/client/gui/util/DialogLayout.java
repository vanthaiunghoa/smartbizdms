/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /**
	DialogLayout
*/
package nz.co.transparent.client.gui.util;

import java.awt.*;

public class DialogLayout implements LayoutManager {
	protected int m_divider = -1;
	protected int m_hGap = 10;
	protected int m_vGap = 2;

	public DialogLayout() {
	}

	public DialogLayout(int hGap, int vGap) {
		m_hGap = hGap;
		m_vGap = vGap;
	}

	public void addLayoutComponent(String name, Component comp) {
	}

	public void removeLayoutComponent(Component comp) {
	}

	public Dimension preferredLayoutSize(Container parent) {
		int divider = getDivider(parent);

		int w = 0;
		int h = 0;
		for (int k = 1; k < parent.getComponentCount(); k += 2) {
			Component comp = parent.getComponent(k);
			Dimension d = comp.getPreferredSize();
			w = Math.max(w, d.width);
			h += d.height + m_vGap;
		}
		h -= m_vGap;

		Insets insets = parent.getInsets();
		return new Dimension(
			divider + w + insets.left + insets.right,
			h + insets.top + insets.bottom);
	}

	public Dimension minimumLayoutSize(Container parent) {
		return preferredLayoutSize(parent);
	}

	public void layoutContainer(Container parent) {
		int divider = getDivider(parent);

		Insets insets = parent.getInsets();
		int w = parent.getWidth() - insets.left - insets.right - divider;
		int x = insets.left;
		int y = insets.top;

		for (int k = 1; k < parent.getComponentCount(); k += 2) {
			Component comp1 = parent.getComponent(k - 1);
			Component comp2 = parent.getComponent(k);
			Dimension d = comp2.getPreferredSize();

			comp1.setBounds(x, y, divider - m_hGap, d.height);
			comp2.setBounds(x + divider, y, w, d.height);
			y += d.height + m_vGap;
		}
	}

	public int getHGap() {
		return m_hGap;
	}

	public int getVGap() {
		return m_vGap;
	}

	public void setDivider(int divider) {
		if (divider > 0)
			m_divider = divider;
	}

	public int getDivider() {
		return m_divider;
	}

	protected int getDivider(Container parent) {
		if (m_divider > 0)
			return m_divider;

		int divider = 0;
		for (int k = 0; k < parent.getComponentCount(); k += 2) {
			Component comp = parent.getComponent(k);
			Dimension d = comp.getPreferredSize();
			divider = Math.max(divider, d.width);
		}
		divider += m_hGap;
		return divider;
	}

	public String toString() {
		return getClass().getName()
			+ "[hgap="
			+ m_hGap
			+ ",vgap="
			+ m_vGap
			+ ",divider="
			+ m_divider
			+ "]";
	}
}