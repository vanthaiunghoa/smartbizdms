/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Role.java
 * 
 * Created on Januari 6, 2004
 */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.*;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;

/**
 * @author John Zoetebier
 */
public class RoleForm extends javax.swing.JInternalFrame {

	// Constants
	private static final int FIELD_LENGTH = 14;

	// Private variables
	private Map roleMap = new HashMap();
	private Map personMap = new HashMap();
	private GenericController genericController =
		GenericController.getInstance();

	private JLabel roleIDLabel = new JLabel("Role ID");
	private JLabel roleCodeLabel = new JLabel("Role code");
	private JLabel roleLabel = new JLabel("Role");
	private JLabel isDefaultLabel = new JLabel("Is default");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	private JLabel dateCreatedLabel = new JLabel("Date created");
	private JLabel dateUpdatedLabel = new JLabel("Date updated");

	private DateFormat timeStampFormat =
		new SimpleDateFormat(Parameter.getParameter("format.timestamp", Constants.FORMAT_TIMESTAMP));

	private JTextField roleIDField = new JTextField();
	private JTextField roleCodeField = new JTextField();
	private JTextField roleField = new JTextField();
	private JCheckBox isDefaultField = new JCheckBox();
	private JTextField updaterPersonIDField = new JTextField();
	private JFormattedTextField dateCreatedField =
		new JFormattedTextField(timeStampFormat);
	private JFormattedTextField dateUpdatedField =
		new JFormattedTextField(timeStampFormat);

	private JPanel contentPanel = new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();

	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public RoleForm() {

		setName("Role form");
		setTitle("Role form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));

		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);
		addInternalFrameListener(new InternalFrameOpenedAdapter(this, roleField));

		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New role.");
		newButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				newButton_actionPerformed();
			}
		});

		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		saveButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save role.");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(saveButton);

		reloadButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh role.");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		deleteButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete role.");
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				deleteButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setFocusTraversalPolicy(
			new InputOrderFocusTrafersalPolicy());
		dialogPanel.setFocusCycleRoot(true);

		// Dialog fields
		dialogPanel.add(roleIDLabel);
		Dimension fieldDimension =
			new Dimension(200, roleIDLabel.getPreferredSize().height);
		roleIDField.setToolTipText("Generated by system.");
		roleIDField.setEditable(false);
		roleIDField.setColumns(FIELD_LENGTH);
		dialogPanel.add(roleIDField);

		dialogPanel.add(roleCodeLabel);
		dialogPanel.add(roleCodeField);

		dialogPanel.add(roleLabel);
		dialogPanel.add(roleField);

		dialogPanel.add(isDefaultLabel);
		dialogPanel.add(isDefaultField);

		dialogPanel.add(updaterPersonIDLabel);
		updaterPersonIDField.setEditable(false);
		dialogPanel.add(updaterPersonIDField);

		dialogPanel.add(dateCreatedLabel);
		dateCreatedField.setEditable(false);
		dialogPanel.add(dateCreatedField);

		dialogPanel.add(dateUpdatedLabel);
		dateUpdatedField.setEditable(false);
		dialogPanel.add(dateUpdatedField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));

		// Add dialogPanel to content panel
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);
		pack();
	}

	/**
	 * Populate form using PK roleID
	 * 
	 * @param roleID
	 *                Primary key
	 */
	public void populateForm(int roleID) {

		String msg = null;
		try {
			msg = "RoleForm: Cannot find role: " + roleID;
			roleMap = genericController.findWhere("role", "role_id=" + roleID);
			
			Integer personID = (Integer) roleMap.get("updater_person_id");
			personMap = Updater.getUpdater(personID.intValue());
		} catch (ControllerException ce) {
			Messager.exception(this, msg + "\n" + ce.getMessage());
			return;
		} catch (FinderException fe) {
			Messager.exception(this, msg + "\n" + fe.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		roleIDField.setText(String.valueOf(roleMap.get("role_id").toString()));
		roleCodeField.setText(roleMap.get("role_code").toString());
		roleField.setText(roleMap.get("role").toString());
		isDefaultField.setSelected(
			((Boolean) (roleMap.get("is_default"))).booleanValue());
		updaterPersonIDField.setText(personMap.get("user_name").toString());
		dateCreatedField.setValue(roleMap.get("date_created"));
		dateUpdatedField.setValue(roleMap.get("date_updated"));
	}

	/**
	 * Populate new form
	 *  
	 */
	public void populateNewForm() {

		newButton_actionPerformed();
	}

	private void deleteButton_actionPerformed(ActionEvent evt) {
		String msg = null;

		if (roleMap.get("role_id") == null) {
			msg = "New role cannot be deleted";
			Messager.information(this, msg);
			return;
		}

		msg = "Continue to delete role ?";
		if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
			return;
		}

		try {
			Integer roleID = (Integer) roleMap.get("role_id");
			genericController.deleteRecord(
				"role",
				"role_id=" + roleID.intValue());
			newButton_actionPerformed();
		} catch (ControllerException ce) {
			Messager.exception(
				this,
				"RoleForm: Error deleting role.\n" + ce.getMessage());
			return;
		}
	}

	private void newButton_actionPerformed() {

		roleMap.put("role_id", null);
		personMap = LoginController.getPerson();

		GenericUtils.resetInputFields(dialogPanel);
		Map roleMap = null;

		roleIDField.setText(null);
		roleCodeField.setText(null);
		roleField.setText(null);
		isDefaultField.setText(null);
		updaterPersonIDField.setText(
			(String) LoginController.getPerson().get("user_name"));
		dateCreatedField.setValue(new Date());
		dateUpdatedField.setValue(new Date());
	}

	private void saveButton_actionPerformed(ActionEvent evt) {

		if (!validateForm()) {
			return;
		}

		// Store fields in roleMap
		roleMap.put("role_id", roleMap.get("role_id"));
		roleMap.put("role_code", roleCodeField.getText());
		roleMap.put("role", roleField.getText());
		roleMap.put("is_default", Boolean.valueOf(isDefaultField.isSelected()));
		roleMap.put(
			"updater_person_id",
			LoginController.getPerson().get("person_id"));
		roleMap.put("date_created", dateCreatedField.getValue());
		roleMap.put("date_updated", dateUpdatedField.getValue());

		try {
			if (roleIDField.getText().equals("")) {
				roleMap.put("role_id", null); // Generate
				// key
				genericController.insertRecord("role", "role_id", roleMap);
			} else {
				// Cast to Integer, otherwise record lookup and update will
				// fail
				roleMap.put("role_id", Integer.valueOf(roleIDField.getText()));
				genericController.updateRecord("role", "role_id", roleMap);
			}

			Integer roleID = (Integer) roleMap.get("role_id");
			// If is_default has been set, switch off any other default
			genericController.switchOffOtherDefault(
				"role",
				"role_id",
				roleID,
				isDefaultField.isSelected());
			populateForm(roleID.intValue());
		} catch (UpdaterException ue) {
			String message = "Update warning !\n";
			message
				+= "Changes have been made by an other person or process.\n";
			message += "Form will be refreshed with latest values";
			Messager.warning(this, message);
			this.populateForm(
				Integer.parseInt(roleMap.get("role_id").toString()));
		} catch (ControllerException ce) {
			Messager.exception(this, "Error: " + ce.getMessage());
		}
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogPanel);

		if (roleField.getText().equals("")) {
			roleField.setBackground(Color.YELLOW);
			roleField.setToolTipText("Please enter role");
			roleField.requestFocus();
			validationOk = false;
		}

		return validationOk;
	}

	private void reloadButton_actionPerformed(ActionEvent evt) {
		Integer roleID = (Integer) roleMap.get("role_id");

		if (roleID == null) {
			this.newButton_actionPerformed();
		} else {
			this.populateForm(roleID.intValue());
		}
	}
}