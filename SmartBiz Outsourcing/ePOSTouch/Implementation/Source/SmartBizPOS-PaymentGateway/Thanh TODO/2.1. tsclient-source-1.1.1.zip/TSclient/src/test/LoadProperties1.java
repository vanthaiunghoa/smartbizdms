/*
 * Created on Oct 25, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import java.io.*;
import java.util.Properties;

/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class LoadProperties1 {

	public static void main(String[] args) 
		throws Exception {
		
		// When running via Ant we pass root folder as argument
		String rootFolder = "";
		if (args.length == 1) {
			rootFolder = args[0] + "/";
		}		

		System.getProperties().list(System.out);
		File projectFile = new File(rootFolder + "resource/project.properties");
		if (!projectFile.exists()) {
			System.out.println("Properties file doews not exist: " + projectFile);
		}
		
		FileInputStream fis = new FileInputStream(projectFile);
		Properties projectProperties = new Properties();
		projectProperties.load(fis);
		fis.close();
		projectProperties.list(System.out);
		
	}
}
