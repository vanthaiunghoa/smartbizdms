/*
 * Created on Nov 26, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

import nz.co.transparent.client.util.Constants;

import nz.co.transparent.client.db.PoolingDriverHandler;

/**
 * @author johnz
 * 
 * Purpose: check optimistic locking
 * Check is based on field DateUpdated
 *
 */
public class TestOptimisticLocking {

	private Logger log = Logger.getLogger("test");
	/**
	 * 
	 */
	public TestOptimisticLocking() {
		super();
	}

	private void go() {
		
		PoolingDriverHandler databaseConnectionPool = new PoolingDriverHandler();
		Connection conn;
		
		try {
			conn = DriverManager.getConnection(Constants.JDBC_URL);
			// If AutoCommit is true then we are not using a transaction
			// Changes to the database by other clients are immediately visible to this client
			// If AutoCommit is false then we are running in transaction mode
			// Changes to the database by other clients are visible after commit or rollback
			//conn.setAutoCommit(false);
		} catch (SQLException se) {
			log.warning("Cannot get SQL connection");
			return;
		}
		
		ResultSet rset = null;
		Statement stmt = null;
		Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = formatter.format(new Date());
		String sql;
		sql = "update Client";
		sql += " set DateUpdated='" + date + "'";
		sql += " where (ClientID=1);";
		
		try {
			stmt = conn.createStatement();
			sql = "select DateUpdated from Client";
			sql += " where (ClientID=1);";
			rset = stmt.executeQuery(sql);
			rset.next();
			Date oldDate = rset.getDate("DateUpdated"); 
			System.out.println("Old date=" + oldDate.getTime());
			
			// Run transaction TestTransaction1 to update date from commend prompt
			
			rset = stmt.executeQuery(sql);
			rset.next();
			Date newDate = rset.getDate("DateUpdated");  
			System.out.println("New date=" + newDate.getTime());

			if (oldDate.equals(newDate)) {
				System.out.println("DateUpdated has NOT changed");
			} else {
				System.out.println("DateUpdated has changed");
			}
			
//			sql = "update Client";
//			sql += " set DateUpdated='" + date + "'";
//			sql += " where (ClientID=1);";
//			stmt.execute(sql);
//			conn.commit();
		} catch (SQLException se) {
			log.warning("SQL failed: " + se.getMessage());
			try {
				conn.rollback();
			} catch (SQLException se2) {
				log.warning("Rollback failed: " + se2.getMessage());
			}
		}
		
		try {
			stmt.close();
			conn.close();
		} catch (SQLException se) {
			log.warning("Close failed: " + se.getMessage());
		}
		
		System.out.println("TestOptimisticLocking ready");

	}
	
	public static void main(String[] args) {
		new TestOptimisticLocking().go();
	}
}
