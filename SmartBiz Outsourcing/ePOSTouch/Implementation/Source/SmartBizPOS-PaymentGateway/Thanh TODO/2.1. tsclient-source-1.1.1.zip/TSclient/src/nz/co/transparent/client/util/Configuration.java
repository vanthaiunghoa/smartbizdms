/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Nov 30, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package nz.co.transparent.client.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import org.apache.xerces.impl.dv.util.Base64;

/**
 * To retrieve and store application wide configuration settings
 * There are only static methods as configation settings must be the same throughout the system 
 * 
 * @author johnz
 *
 */
public class Configuration {

	private static Logger log = Logger.getLogger("util");
	private static Properties configuration;
	
	// Load properties
	// In test environment we derive client directory from classes path using /classes folder
	//		to avoid having to add VM arguments to all test classes
	// In production environment we pass JVM argument client.dir using -D parameter
	static {
		configuration = new Properties();

                System.out.println("client.dir=" + System.getProperty("client.dir"));
		if (System.getProperty("client.dir") == null) {
			loadConfigFromFile(getClientDir());
		} else {
			// Production environment
			loadConfigFromFile(System.getProperty("client.dir"));
		}
	}
	
	/**
	 * 
	 */
	public Configuration() {
		super();
		
	}

	private static void loadConfigFromFile(String clientDir) {

		String fileSeparator = System.getProperty("file.separator");
		String resourceFileName = clientDir + fileSeparator + "resource" + fileSeparator + "config.properties";
		String msg = null;
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		
		try {
			fis = new FileInputStream(new File(resourceFileName));
			bis = new BufferedInputStream(fis);
			configuration.load(bis);
			configuration.put("client.dir", clientDir);
		} catch (FileNotFoundException fnfe) {
			msg= "Configuration::loadConfigFromFile() : Resource file does not exist: " + resourceFileName +".\n Please check startup parameter -Dclient.dir";
			log.warning(msg);
			Messager.warning(null, msg);
		} catch (IOException ioe) {
			msg= "Error reading configuration file:\n" + ioe.getMessage();
			log.warning(msg);
			Messager.warning(null, msg);
		} finally {
			try {
				if (fis != null) {
					fis.close();
				}
				
				if (bis != null) {
					bis.close();
				}
			} catch (IOException ioe) {
				msg= ioe.getMessage();
				log.warning(msg);
			}
		}
	}
	
	/**
	 * Store configuration settings in file sorted on key 
	 *
	 */
	public static void storeConfiguration() {

		String clientDir = getProperty("client.dir", ".");
		String fileSeparator = System.getProperty("file.separator");
		String resourceFileName = clientDir + fileSeparator + "resource" + fileSeparator + "config.properties";
		String msg = null;
		PrintWriter pwriter = null;
		
		try {
			pwriter = new PrintWriter(new FileOutputStream(new File(resourceFileName)));
			Enumeration keys = configuration.keys();
			List keyList = new LinkedList();
			
			while (keys.hasMoreElements()){
				keyList.add(keys.nextElement());
			}
			
			Collections.sort(keyList);
			Iterator iterator = keyList.iterator();
			StringBuffer buffer = new StringBuffer();
			String key = null;
			buffer.append("#TS Client properties file\n");
			buffer.append("#" + new Date() + "\n");

			while (iterator.hasNext()) {
				key = iterator.next().toString();
				if (!key.equalsIgnoreCase("client.dir")) {
					buffer.append(key + "=" + configuration.getProperty(key) + "\n");
				}
			}
			
			pwriter.write(buffer.toString().toCharArray());
		} catch (FileNotFoundException fnfe) {
			msg= "Resource file does not exist: " + resourceFileName +".\n Please check startup parameter -Dclient.dir";
			log.warning(msg);
			Messager.warning(null, msg);
		} finally {
			if (pwriter != null) {
				pwriter.close();
			}
		}
	}
	
	public static void loadConfigAsResource() {
			InputStream is  = Configuration.class.getResourceAsStream("/config.properties");
		
		if (is == null) {
			log.warning("getResourceAsStream(\"/config.properties\") failed");
			return;
		}

		try {
			configuration.load(is);
			is.close();
		} catch (IOException ioe) {
			log.warning("Error loading configuration file config.properties");
			return;
		}
	}
	
	/**
	 * Get property
	 * @param propertyName Name of property
	 * @param defaultValue Default value returned in case property does not exist
	 * @return String with property value
	 */
	public static String getProperty(String propertyName, String defaultValue) {

		if (configuration.containsKey(propertyName)) {
			return configuration.getProperty(propertyName); 
		} else {
			return defaultValue;
		}
	}
	
	/**
	 * Set value of property
	 * @param propertyName Name of property
	 * @param propertyValue Value of property
	 */
	public static void setProperty(String propertyName, String propertyValue) {
		
		configuration.put(propertyName, propertyValue); 
	}

	/**
	 * Get property decoded from Base64
	 * @param propertyName Name of property
	 * @param defaultValue Default value returned in case property does not exist
	 * @return String with property value
	 */
	public static String getDecodedProperty(String propertyName, String defaultValue) {

		if (configuration.containsKey(propertyName)) {
			if (Base64.decode(configuration.getProperty(propertyName)) == null) {
				return defaultValue;
			} else {
				byte[] bytes = Base64.decode(configuration.getProperty(propertyName));
				StringBuffer returnValue  = new StringBuffer();
				for (int i = 0; i < bytes.length; i++) {
					returnValue.append((char) bytes[i]);
				}
				
				return returnValue.toString();
			}
		} else {
			return defaultValue;
		}
	}
	
	/**
	 * Set value of property in Base64 encoding
	 * This is reuiqred for properties with special characters like carriage return, tab etc
	 * 
	 * @param propertyName Name of property
	 * @param propertyValue Value of property
	 */
	public static void setEncodedProperty(String propertyName, String propertyValue) {
		
		byte[] bytes = new byte[propertyValue.length()];
		
		for (int i = 0; i < bytes.length; i++) {
			bytes[i] = (byte) propertyValue.charAt(i);
		}
		
		configuration.put(propertyName,  new String(Base64.encode(bytes))); 
	}

	/**
	 * Get base directory from classpath
	 *
	 */
	private static String getClientDir() {
		
		String fileSeparator = System.getProperty("file.separator");
		String classpath =  System.getProperty("java.class.path");
		String[] classpaths = classpath.split(System.getProperty("path.separator"));
		String search = fileSeparator + "build" + fileSeparator + "classes";
		String clientDir = null;
		String msg = null;
		

//		System.out.println("Configuration:: java.class.path=" + System.getProperty("java.class.path"));
//		System.getProperties().list(System.out);

		// Search for classes folder (test environment) or tsclient.jar (production environment)				
		if (classpath.indexOf(search) > -1) {
		} else {
			search = "tsclient.jar";
		}
		
                for (int i=0; i<classpaths.length; i++) {
			if (classpaths[i].indexOf(search) > -1) {
				clientDir = classpaths[i];
				break;
			}
		}
		
		// jar file is in lib folder: strip subfolder
		// classes is subfolder
		if (clientDir == null) {
			msg = "Configuration:: classpath must have classes subfolder or tsclient.jar";
			Messager.warning(null, msg);
			log.warning(msg);
			System.exit(1);
		}
		
		
		search = fileSeparator + "build" + fileSeparator + "classes";
		if (clientDir.indexOf(search) > -1) {
			clientDir = clientDir.substring(0, clientDir.indexOf(search));
		} else {
			search = fileSeparator + "lib" + fileSeparator + "tsclient.jar"; 
			
			if (clientDir.indexOf(search) > -1) {
				clientDir = clientDir.substring(0, clientDir.indexOf(search));
			} else {
				clientDir = "";
			}
		}
		
		return clientDir;
	}
}