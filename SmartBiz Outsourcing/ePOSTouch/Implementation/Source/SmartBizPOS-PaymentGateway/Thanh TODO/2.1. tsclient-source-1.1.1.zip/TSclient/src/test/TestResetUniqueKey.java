/*
 * Created on Feb 2, 2004
 *
 */
package test;

import java.sql.SQLException;

import nz.co.transparent.client.db.DataSourceHandler;
import nz.co.transparent.client.db.SQL;

/**
 * @author John Zoetebier
 * 
 */
public class TestResetUniqueKey {

	/**
	 * 
	 */
	public TestResetUniqueKey() {
		super();
	}

	public static void main(String[] args) 
		throws SQLException {
		
		DataSourceHandler.loadCredentialsFromConfig();
//		SQL.resetUniqueKey("title", "title_id");
//		System.out.println("Next unique key of title is: " + SQL.getUniqueKey("title", "title_id"));
		SQL.resetUniqueKey("person", "person_id");
		System.out.println("Next unique key of person is: " + SQL.getUniqueKey("person", "person_id"));
		
	}
}
