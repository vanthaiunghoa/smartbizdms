/*
 * Created on Nov 8, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */


import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import nz.co.transparent.client.db.PoolingDriverHandler;

public class TestSpecialChars {

	// This test uses ConnectionPool.close() to check database corruption
	public static void main(String[] args) {
		
		nz.co.transparent.client.db.PoolingDriverHandler dbConnectionPool  =  new PoolingDriverHandler("client");
		
		// Now, we can use JDBC as we normally would.
		// Using the connect string
		//  jdbc:apache:commons:dbcp:example
		// The general form being:
		//  jdbc:apache:commons:dbcp:<name-of-pool>
		//

		Connection conn = null;
		PreparedStatement pstmt = null;
		Statement stmt = null;
		ResultSet rset = null;
		String sql;

		long startTime = new Date().getTime();
		long currentTime;
		System.out.println("Creating connection.");
		
		try {
			conn = DriverManager.getConnection("jdbc:apache:commons:dbcp:testPool");
			System.out.println("Connection time=" + (new Date().getTime() - startTime));
			System.out.println("Creating statement.");

			// Clean table 
			stmt = conn.createStatement();
			rset = stmt.executeQuery("delete from Test;");

			sql = "insert into APP.Test " +
				"set TestID=? " +
				", TextField=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, 1);
			pstmt.setString(2, "Test single quote O'reilly");
			rset = pstmt.executeQuery();
			System.out.println("Executing statement.");
		} catch(SQLException e) {
			e.printStackTrace();
			try { pstmt.close(); } catch(Exception e1) { }
			try { conn.close(); } catch(Exception e2) { }
			return;
		}
		
		try { pstmt.close(); } catch(Exception e2) { }
		try { conn.close(); } catch(Exception e2) { }

		// Close connection pool
		try {
			dbConnectionPool.closeConnectionPool();
		} catch (Exception e) {
			System.out.println("Exception thrown closing connection pool:");
			System.out.println(e.getMessage());
		}
		
		System.out.println("Test: ready !");
	}
}
