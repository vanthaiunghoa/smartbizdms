/*
 * Created on Jan 18, 2004
 *
 */
package test;

import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.DataSourceHandler;
import nz.co.transparent.client.report.EnvelopReporter;
import nz.co.transparent.client.util.Configuration;

/**
 * @author John Zoetebier
 * 
 */
public class TestPrintEnvelopReport {

	/**
	 * 
	 */
	public TestPrintEnvelopReport() {
		super();
	}

	public static void main(String[] args) {

		boolean preview = true;

		// Get credential from configuration file
		DataSourceHandler.setUserName(Configuration.getProperty("login.username", ""));
		DataSourceHandler.setPassword(Configuration.getProperty("login.password", ""));

		try {
			EnvelopReporter.print(1, preview);
			
			if (!preview) {
				System.exit(0);
			}
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
		}
	}
}
