/*
 * Created on Jan 26, 2004
 *
 */
package test;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

/**
 * @author John Zoetebier
 * 
 */
public class TestJDialog extends JFrame {

	/**
	 * 
	 */
	public TestJDialog() {
		super();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(700, 500);
		setVisible(true);
	}
	
	public void showDialog() {
		
		JDialog dialog = new JDialog(this, true);
		dialog.setTitle("Password");
		JLabel passwordLabel = new JLabel("Enter your password:");
		JPasswordField passwordField = new JPasswordField(15);
		Container content = dialog.getContentPane();
		content.setLayout(new BorderLayout());
		JPanel panel1 = new JPanel();
		panel1.setLayout(new BoxLayout(panel1, BoxLayout.X_AXIS));
		panel1.add(passwordLabel);
		panel1.add(Box.createHorizontalStrut(5));
		panel1.add(passwordField);
		content.add(panel1, BorderLayout.NORTH);
		
		JButton okButton = new JButton("Ok");
		JButton cancelButton = new JButton("Cancel");
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.add(Box.createGlue());
		buttonPanel.add(okButton);
		buttonPanel.add(Box.createHorizontalStrut(5));
		buttonPanel.add(cancelButton);
		buttonPanel.add(Box.createGlue());
		content.add(buttonPanel, BorderLayout.CENTER);
		dialog.setSize(300, 100);
		dialog.show();
	}

	public static void main(String[] args) {
		
		TestJDialog frame = new TestJDialog();
		frame.showDialog();
	}
}
