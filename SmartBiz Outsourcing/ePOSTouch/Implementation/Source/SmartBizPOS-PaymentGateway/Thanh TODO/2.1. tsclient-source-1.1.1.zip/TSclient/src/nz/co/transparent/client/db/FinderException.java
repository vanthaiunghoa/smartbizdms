/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 package nz.co.transparent.client.db;

/**
 * Application exception thrown if finder method cannot find a record 
 *
 * @author John Zoetebier
 * @version 1.0
 */
public class FinderException extends Exception {

    /**
     * Creates a default <code>FinderException</code> instance.
     */
	public FinderException() {
		this("No record found");
	}

	/**
	 * 
	 * @param message Message to display with FinderException.getMessage()
	 */
	public FinderException(String message) {
		super(message);
	}

    /**
     * Creates a <code>FinderException</code> instance and chains an
     * exception.
     *
     * @param e The exception to wrap and chain.
     */
    public FinderException(Throwable e) {
        super(e);
    }
}