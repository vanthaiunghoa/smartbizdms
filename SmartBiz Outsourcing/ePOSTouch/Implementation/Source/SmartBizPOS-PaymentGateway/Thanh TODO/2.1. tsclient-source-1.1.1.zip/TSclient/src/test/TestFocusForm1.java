/*
 * Focus.java
 *
 * Created on Januari 3, 2004
 */

package test;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.*;

import javax.swing.*;

/**
 *
 * @author  John Zoetebier
 */
public class TestFocusForm1 extends javax.swing.JFrame {

	// Constants
	private static final int FIELD_LENGTH = 14;

	private JLabel occupationIDLabel = new JLabel("Focus ID");
	private JLabel occupationLabel = new JLabel("Focus");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	
	private JTextField occupationIDField = new JTextField();
	private JTextField occupationField = new JTextField();
	private JTextField updaterPersonIDField = new JTextField();
	
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();
	
	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public TestFocusForm1() {
		super();

		setName("Focus form");
		setTitle("Focus form");
		setResizable(true);
		addWindowListener(new WindowAdapter() {
			public void windowOpened(WindowEvent e) {
				requestFocusFor(occupationIDField);
			}
		});
		
		Container contentPanel = getContentPane();
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setText("new");
		newButton.setMnemonic(KeyEvent.VK_N);
		
		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		saveButton.setText("save");
		saveButton.setMnemonic(KeyEvent.VK_S);

		toolbarMain.add(saveButton);

		reloadButton.setText("reload");
		reloadButton.setMnemonic(KeyEvent.VK_R);

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		deleteButton.setText("delete");
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete occupation.");
		
		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));
		
		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new GridLayout(0,2));

		// Dialog fields
		dialogPanel.add(occupationIDLabel);
		dialogPanel.add(occupationIDField);

		dialogPanel.add(occupationLabel);
		occupationField.setColumns(FIELD_LENGTH);
		occupationField.requestFocusInWindow();
		dialogPanel.add(occupationField);

		dialogPanel.add(updaterPersonIDLabel);
		dialogPanel.add(updaterPersonIDField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
		
		// Add dialogPanel to content panel 
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);

		setSize(700, 600);
		pack();
		setVisible(true);
	}
	
	private void requestFocusFor(final JComponent comp) {

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				comp.setRequestFocusEnabled(true);
				comp.requestFocus();
			}
		});
	}
	
	public static void main (String[] args) {
		
		new TestFocusForm1();
	}
}
