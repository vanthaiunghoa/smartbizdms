/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Invoice.java
 *
 * Created on November 23, 2003, 14:08 PM
 */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.KeyboardFocusManager;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

import javax.swing.*;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;


/**
 *
 * @author  John Zoetebier
 */
public class InvoiceForm extends javax.swing.JInternalFrame {

	private static Map columnPropertyMap;
	private static List columnPropertyMapList = new ArrayList();

	static {
		columnPropertyMap = new HashMap(2);
		columnPropertyMap.put("columnName" , "payment_id");
		columnPropertyMap.put("columnHeader", "Payment ID");
		columnPropertyMapList.add(columnPropertyMap);

		columnPropertyMap = new HashMap(2);
		columnPropertyMap.put("columnName" , "payment_date");
		columnPropertyMap.put("columnHeader", "Payment date");
		columnPropertyMap.put("isDate", Boolean.TRUE);
		columnPropertyMapList.add(columnPropertyMap);

		columnPropertyMap = new HashMap(2);
		columnPropertyMap.put("columnName" , "amount");
		columnPropertyMap.put("columnHeader", "Amount");
		columnPropertyMap.put("isCurrency", Boolean.TRUE);
		columnPropertyMapList.add(columnPropertyMap);

		columnPropertyMap = new HashMap(2);
		columnPropertyMap.put("columnName" , "tender");
		columnPropertyMap.put("columnHeader", "Tender");
		columnPropertyMapList.add(columnPropertyMap);
	}
	
	// Constants
	private static final int FIELD_LENGTH = 14;

	// Private variables
	private Map invoiceMap = new HashMap();
	private Map clientMap = new HashMap();
	private Map personMap = new HashMap();
	private Logger log = Logger.getLogger("nz.co.transparent.client.gui");
	private SpecificController invoiceController = SpecificController.getInstance();
	private GenericController genericController = GenericController.getInstance();
	
	private JLabel invoiceIDLabel = new JLabel("Invoice ID");
	private JLabel clientIDLabel = new JLabel("Client");
	private JLabel invoiceDateLabel = new JLabel("Invoice date");
	private JLabel amountLabel = new JLabel("Amount");
	private JLabel commentLabel = new JLabel("Comment");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	private JLabel dateCreatedLabel = new JLabel("Date created");
	private JLabel dateUpdatedLabel = new JLabel("Date updated");
	
	private DateFormat shortDateFormat = new SimpleDateFormat(Parameter.getParameter("format.shortdate", Constants.FORMAT_SHORT_DATE));
	private DateFormat timeStampFormat = new SimpleDateFormat(Parameter.getParameter("format.timestamp", Constants.FORMAT_TIMESTAMP));
	private NumberFormat amountDisplayFormat = NumberFormat.getCurrencyInstance();
	private NumberFormat amountEditFormat = NumberFormat.getNumberInstance();

	private JTextField invoiceIDField = new JTextField();
	private JTextField clientIDField = new JTextField();
	private JFormattedTextField invoiceDateField = new JFormattedTextField(shortDateFormat);
	private JFormattedTextField amountField = new JFormattedTextField(
			new DefaultFormatterFactory(
				new NumberFormatter(amountDisplayFormat),
				new NumberFormatter(amountDisplayFormat),
				new NumberFormatter(amountEditFormat)
				)
			);
	private JTextArea commentField = new JTextArea(4, FIELD_LENGTH);
	private JTextField updaterPersonIDField = new JTextField();
	private JFormattedTextField dateCreatedField = new JFormattedTextField(timeStampFormat);
	private JFormattedTextField dateUpdatedField = new JFormattedTextField(timeStampFormat);
	
	private JPanel contentPane = new JPanel();
	private JPanel middlePanel = new JPanel();	// To get dialogPanel left alligned
	private JPanel dialogPanel = new JPanel();
	private JPanel tablePanel  = new JPanel();

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();
	
	private JButton paymentNewButton = new JButton();
	private JButton paymentUpdateButton = new JButton();
	private JButton paymentDeleteButton = new JButton();

	private JScrollPane tableScrollPane = new JScrollPane();
	private JToolBar mainToolbar = new JToolBar();
	private JToolBar paymentToolbar = new JToolBar();
	/**
	 * <code>JTable</code> displays payment details.
	 */
	private JTable paymentTable = new JTable ();
	private GenericTableModel paymentTableModel = new GenericTableModel(columnPropertyMapList);
	private PaymentForm paymentForm;
	
	/** Creates new InvoiceForm */
	public InvoiceForm() {
		initComponents();
	}
    
	/** 
	 * Initialize the form.
	 */
	private void initComponents() {
		
		setName("Invoice form");
		setTitle("Invoice form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		setContentPane(contentPane);
		try {
			setSelected(true);
		} catch (java.beans.PropertyVetoException e1) {
			e1.printStackTrace();
		}

		addInternalFrameListener(new InternalFrameOpenedAdapter(this, invoiceDateField));

		mainToolbar.setBorder(BorderFactory.createEtchedBorder());
		mainToolbar.setFloatable(false);

		newButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New invoice.");
		newButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				newButton_actionPerformed();
			 }
		});
		
		mainToolbar.add(newButton);
		mainToolbar.add(Box.createRigidArea(new Dimension(5,0)));

		saveButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save invoice.");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		mainToolbar.add(saveButton);

		reloadButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh invoice.");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		mainToolbar.add(reloadButton);
		mainToolbar.add(Box.createRigidArea(new Dimension(5,0)));

		deleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete invoice.");
		deleteButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				deleteButton_actionPerformed(evt);
			 }
		});
		
		mainToolbar.add(deleteButton);
		mainToolbar.add(Box.createRigidArea(new Dimension(5,0)));
		
		// make buttons left aligned
		mainToolbar.add(Box.createHorizontalGlue());
		contentPane.add(mainToolbar);

		// Create helper panel with gridbag layout
		dialogPanel.setFocusTraversalPolicy(new InputOrderFocusTrafersalPolicy());
		dialogPanel.setFocusCycleRoot(true);	// This will force focus go down the colum
		dialogPanel.setLayout(new DialogLayout());

		// Set dialog fields
		dialogPanel.add(invoiceIDLabel);
		invoiceIDField.setColumns(FIELD_LENGTH);
		invoiceIDField.setToolTipText("Generated by system.");
		invoiceIDField.setEditable(false);
		dialogPanel.add(invoiceIDField);

		dialogPanel.add(clientIDLabel);
		clientIDField.setEditable(false);
		dialogPanel.add(clientIDField);

		dialogPanel.add(invoiceDateLabel);
		invoiceDateField.setColumns(FIELD_LENGTH);
		dialogPanel.add(invoiceDateField);

		amountDisplayFormat.setMinimumFractionDigits(2);
		dialogPanel.add(amountLabel);
		amountField.setColumns(FIELD_LENGTH);
		dialogPanel.add(amountField);

		dialogPanel.add(commentLabel);
		commentField.setLineWrap(true);
		commentField.setWrapStyleWord(true);	// wrap only on word boundary
		// Ensure tabs are handled by focus manager
		commentField.setFocusTraversalKeys(
				KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,null);
		commentField.setFocusTraversalKeys(
			KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,null);
		 
		JScrollPane commentScrollPane = new JScrollPane(commentField);
		dialogPanel.add(commentScrollPane);

		dialogPanel.add(updaterPersonIDLabel);
		updaterPersonIDField.setEditable(false);
		dialogPanel.add(updaterPersonIDField);

		dialogPanel.add(dateCreatedLabel);
		dateCreatedField.setEditable(false);
		dialogPanel.add(dateCreatedField);

		dialogPanel.add(dateUpdatedLabel);
		dateUpdatedField.setEditable(false);
		dialogPanel.add(dateUpdatedField);
		
		// Create help panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
		
		// Add dialogPanel to content panel 
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPane.add(middlePanel);

		// Toolbar for payment detail table
		paymentToolbar.setBorder(BorderFactory.createEtchedBorder());
		paymentToolbar.setFloatable(false);

		paymentNewButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif")));
		paymentNewButton.setToolTipText("New payment");
		paymentNewButton.setMnemonic(KeyEvent.VK_C);
		paymentNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (invoiceMap.get("invoice_id") == null) {
					Messager.information((JFrame) MainFrame.getInstance(), "Please enter invoice first");
					return;
				}
				
				paymentForm = new PaymentForm();
				paymentForm.populateNewForm(invoiceMap);
				MainFrame.openFrame(paymentForm);
			}
		});
		
		paymentUpdateButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Edit24.gif")));
		paymentUpdateButton.setToolTipText("Update payment");
		paymentUpdateButton.setMnemonic(KeyEvent.VK_U);
		paymentUpdateButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Get paymentID from table
				int index = paymentTable.getSelectedRow();
				if (index < 0) {
					Messager.information((JFrame) MainFrame.getInstance(), "Please select a row in table");
					return;
				}

				Integer paymentID = (Integer) paymentTable.getValueAt(index, 0);
				paymentForm = new PaymentForm();
				paymentForm.populateForm(paymentID.intValue());
				MainFrame.openFrame(paymentForm);
			}
		});
		
		paymentDeleteButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif")));
		paymentDeleteButton.setToolTipText("Delete payment");
		paymentDeleteButton.setMnemonic(KeyEvent.VK_L);
		paymentDeleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Get paymentID from table
				int index = paymentTable.getSelectedRow();
				if (index < 0) {
					Messager.information((JFrame) MainFrame.getInstance(), "Please select a row in table");
					return;
				}

				Integer paymentID = (Integer) paymentTable.getValueAt(index, 0);
				try {
					genericController.deleteRecord("payment", "payment_id=" + paymentID);
					//genericController.deleteRecord("payment", "payment_id=" + paymentID);
					// reload only table with contact details, not rest of form
					Integer invoiceID = (Integer) invoiceMap.get("invoice_id");
					// Set payment table model
					paymentTableModel.setMapList(invoiceController.findPayments(invoiceID.intValue()));
					GenericUtils.updateTable(paymentTable, paymentTableModel);
				} catch (ControllerException ce) {
					String msg = "ClientForm: error deleting payment. " + ce.getMessage();
					log.warning(msg);
					Messager.exception(null, msg);
					return;
				}
			}
		});

		paymentToolbar.add(paymentNewButton);
		paymentToolbar.add(Box.createRigidArea(new Dimension(5,0)));
		paymentToolbar.add(paymentUpdateButton);
		paymentToolbar.add(Box.createRigidArea(new Dimension(5,0)));
		paymentToolbar.add(paymentDeleteButton);
		paymentToolbar.add(Box.createGlue());
		contentPane.add(paymentToolbar);
		
		paymentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		paymentTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		paymentTable.setToolTipText("Select a row, then click on button in toolbar");
		paymentTable.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() >= 2) {
					paymentUpdateButton.doClick();
				}
			}
		});
		tableScrollPane = new JScrollPane(paymentTable);
		tableScrollPane.setSize(tablePanel.getMaximumSize().width -10, tablePanel.getMaximumSize().width -10);
		tableScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		tableScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

		tablePanel.setLayout(new BoxLayout(tablePanel, BoxLayout.X_AXIS));
		tablePanel.setBorder(BorderFactory.createCompoundBorder(
						BorderFactory.createEtchedBorder(), 
						BorderFactory.createEmptyBorder(10, 5, 10, 5)
						));
		tablePanel.add(tableScrollPane);
		contentPane.add(tablePanel);
		
		pack();
	}

	/**
	 * Populate form using PK invoice_id
	 * @param invoiceID PK invoice_id
	 */
	public void populateForm(int invoiceID) {

		String msg = null;
		try {
			msg = "InvoiceForm: Cannot find invoice: " + invoiceID;
			invoiceMap = genericController.findWhere("invoice", "invoice_id=" + invoiceID);

			Integer clientID = (Integer) invoiceMap.get("client_id");
			msg = "InvoiceForm: Cannot client: " + clientID;
			clientMap = genericController.findWhere("client", "client_id=" + clientID.intValue());
			
			Integer personID = (Integer) invoiceMap.get("updater_person_id");
			personMap = Updater.getUpdater(personID.intValue());
		} catch (ControllerException ce) {
			Messager.exception(this, msg + "\n" + ce.getMessage());
			return;
		} catch (FinderException fe) {
			Messager.exception(this, msg  + "\n" + fe.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		invoiceIDField.setText(GenericUtils.setText(invoiceMap.get("invoice_id")));
		clientIDField.setText(GenericUtils.setText(clientMap.get("last_name")));
		invoiceDateField.setValue(invoiceMap.get("invoice_date"));
		amountField.setValue(invoiceMap.get("amount"));
		commentField.setText(GenericUtils.setText(invoiceMap.get("comment")));
		updaterPersonIDField.setText(GenericUtils.setText(personMap.get("user_name")));
		dateCreatedField.setValue(invoiceMap.get("date_created"));
		dateUpdatedField.setValue(invoiceMap.get("date_updated"));
		
		// Set payment table model
		try {
			paymentTableModel.setMapList(invoiceController.findPayments(invoiceID));
			GenericUtils.updateTable(paymentTable, paymentTableModel);
		} catch (ControllerException ce) {
			Messager.exception(this, "InvoiceForm: Error getting payments\n" + ce.getMessage());
			return;
		}
	}

	/**
	 * Populate new form
	 * 
	 * @param clientMap Map of Client
	 */
	public void populateNewForm(Map clientMap) {

		this.clientMap = clientMap;
		newButton_actionPerformed();
	}

	private void deleteButton_actionPerformed(ActionEvent evt) {
		String msg = null;

		if (invoiceMap.get("invoice_id") == null) {
			msg = "New invoice cannot be deleted";
			Messager.information(this, msg);
			return;
		}

		msg = "Continue to delete invoice and payments ?";
		if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
			return;
		}
			
		try {
			Integer invoiceID = (Integer) invoiceMap.get("invoice_id");
			genericController.deleteRecord("invoice", "invoice_id=" + invoiceID.intValue());
			newButton_actionPerformed();
		} catch (ControllerException ce) {
			Messager.exception(this, "InvoiceForm: Error deleting invoice.\n" + ce.getMessage());
			return;
		}
	}

	private void newButton_actionPerformed() {

		invoiceMap.put("invoice_id", null);
		personMap = LoginController.getPerson();

		GenericUtils.resetInputFields(dialogPanel);
		invoiceIDField.setText(null);
		clientIDField.setText(clientMap.get("last_name").toString());
		String dateFormat = Parameter.getParameter("format.shortdate", Constants.FORMAT_SHORT_DATE);
		dateFormat = dateFormat.toLowerCase();
		invoiceDateField.setToolTipText("Date format: " + dateFormat);
		invoiceDateField.setValue(new Date());
		amountField.setValue(null);
		commentField.setText(null);
		updaterPersonIDField.setText((String) LoginController.getPerson().get("user_name"));
		dateCreatedField.setValue(new Date());
		dateUpdatedField.setValue(new Date());
		
		// Set payment table model
		paymentTableModel = new GenericTableModel(columnPropertyMapList);
		GenericUtils.updateTable(paymentTable, paymentTableModel);
	}

	private void saveButton_actionPerformed(ActionEvent evt) {
		
		if (!validateForm()) {
			return;
		}
		
		// Store fields in invoiceMap 
		// Convert display values to foreign keys before passing invoiceMap to nz.co.transparent.client.controller
		// Primary key field set later on
		invoiceMap.put("client_id", clientMap.get("client_id"));
		invoiceMap.put("invoice_date", invoiceDateField.getValue());
		invoiceMap.put("amount", amountField.getValue());
		invoiceMap.put("comment", commentField.getText());
		invoiceMap.put("updater_person_id", LoginController.getPerson().get("person_id"));
		invoiceMap.put("date_created", dateCreatedField.getValue());
		invoiceMap.put("date_updated", dateUpdatedField.getValue());

		try {
			if (invoiceIDField.getText().equals("")) {
				invoiceMap.put("invoice_id", null); 	// Generate key
				genericController.insertRecord("invoice", "invoice_id", invoiceMap);
			} else {
				//	Convert PK to Integer, otherwise record lookup and update will fail
				invoiceMap.put("invoice_id", Integer.valueOf(invoiceIDField.getText()));
				genericController.updateRecord("invoice", "invoice_id", invoiceMap);
			}
			
			Integer invoiceID = (Integer) invoiceMap.get("invoice_id");
			populateForm(invoiceID.intValue());
		} catch (UpdaterException ue) {
			String message = "Update warning !\n";
			message += "Changes have been made by an other person or process.\n";
			message += "Form will be refreshed with latest values";
			Messager.warning(this, message);
			populateForm(Integer.parseInt(invoiceMap.get("invoice_id").toString()));
		} catch (ControllerException ce) {
			Messager.exception(this, "Error: " + ce.getMessage());
		}
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogPanel);

		if (amountField.getText().equals("")) {
			amountField.setBackground(Color.YELLOW);
			amountField.setToolTipText("Please enter amount");
			amountField.requestFocus();
			validationOk = false;
		}

		if (invoiceDateField.getText().equals("")) {
			invoiceDateField.setBackground(Color.YELLOW);
			invoiceDateField.setToolTipText("Please enter invoice date");
			invoiceDateField.requestFocus();
			validationOk = false;
		}

			return validationOk;
	}
	
	private void reloadButton_actionPerformed(ActionEvent evt) {
		Integer invoiceID = (Integer) invoiceMap.get("invoice_id");
		
		if (invoiceID == null) {
			this.newButton_actionPerformed();
		} else {
			this.populateForm(invoiceID.intValue());
		}
	}
}