/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 *
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

 /*
  * Created on Jan 5, 2004
  *
  */
package nz.co.transparent.client.gui.util;

import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.SwingUtilities;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;

/**
 * Adapter for handling opening of JInternalframe
 * @author John Zoetebier
 *
 */
public class InternalFrameOpenedAdapter extends InternalFrameAdapter {
    
    private JInternalFrame internalFrame;
    private JComponent initialFocusComponent;
    
    public InternalFrameOpenedAdapter(JInternalFrame internalFrame, JComponent initialFocusComponent) {
        this.internalFrame = internalFrame;
        this.initialFocusComponent = initialFocusComponent;
    }
    
        /* (non-Javadoc)
         * @see javax.swing.event.InternalFrameAdapter#internalFrameOpened(javax.swing.event.InternalFrameEvent)
         */
    public void internalFrameOpened(InternalFrameEvent ifE) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    internalFrame.setMaximum(true);
                } catch (java.beans.PropertyVetoException pvE) {
                    System.out.println(pvE.getMessage());
                }
            }
        });
        
        if (initialFocusComponent != null) {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    initialFocusComponent.setRequestFocusEnabled(true);
                    initialFocusComponent.requestFocus();
                }
            });
        }
        
        //super.internalFrameOpened(e);
    }
}