/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Client.java
 *
 * Created on November 19, 2003, 14:08 PM
 */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.KeyboardFocusManager;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

import javax.swing.*;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;


/**
 *
 * @author  John Zoetebier
 */
public class PaymentForm extends javax.swing.JInternalFrame {

	// Constants
	private static final int FIELD_LENGTH = 14;

	// Private variables
	private Map paymentMap = new HashMap();
	private Map clientMap = new HashMap();
	private Map invoiceMap = new HashMap();
	private Map personMap = new HashMap();
	private List tenderList;
	private Logger log = Logger.getLogger("nz.co.transparent.client.gui");
	private GenericController genericController = GenericController.getInstance();
	
	private JLabel paymentIDLabel = new JLabel("Payment ID");
	private JLabel clientIDLabel = new JLabel("Client");
	private JLabel invoiceIDLabel = new JLabel("Invoice");
	private JLabel tenderIDLabel = new JLabel("Tender");
	private JLabel paymentDateLabel = new JLabel("Payment date");
	private JLabel amountLabel = new JLabel("Amount");
	private JLabel commentLabel = new JLabel("Comment");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	private JLabel dateCreatedLabel = new JLabel("Date created");
	private JLabel dateUpdatedLabel = new JLabel("Date updated");
	
	private DateFormat shortDateFormat = new SimpleDateFormat(Parameter.getParameter("format.shortdate", Constants.FORMAT_SHORT_DATE));
	private DateFormat timeStampFormat = new SimpleDateFormat(Parameter.getParameter("format.timestamp", Constants.FORMAT_TIMESTAMP));
	private NumberFormat amountDisplayFormat;
	private NumberFormat amountEditFormat;

	private JTextField paymentIDField = new JTextField();
	private JTextField clientIDField = new JTextField();
	private JTextField invoiceIDField = new JTextField();
	private JComboBox tenderIDField = new JComboBox();
	private JFormattedTextField paymentDateField = new JFormattedTextField(shortDateFormat);
	private JFormattedTextField amountField;
	private JTextArea commentField = new JTextArea(4, FIELD_LENGTH);
	private JTextField updaterPersonIDField = new JTextField();
	private JFormattedTextField dateCreatedField = new JFormattedTextField(timeStampFormat);
	private JFormattedTextField dateUpdatedField = new JFormattedTextField(timeStampFormat);
	
	private JPanel contentPanel = new JPanel();
	private JPanel middlePanel = new JPanel();	// To get dialogPanel left alligned
	private JPanel dialogPanel = new JPanel();

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();
	
	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public PaymentForm() {
		initComponents();
	}
    
	/** This method is called from within the constructor to
	 * initialize the form.
	 */
	private void initComponents() {
		
		setName("Payment form");
		setTitle("Payment form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);
		try {
			setSelected(true);
		} catch (java.beans.PropertyVetoException e1) {
			e1.printStackTrace();
		}

		addInternalFrameListener(new InternalFrameOpenedAdapter(this, paymentDateField));

		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New payment.");
		newButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				newButton_actionPerformed();
			 }
		});
		
		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		saveButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save payment.");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(saveButton);

		reloadButton.setIcon(new ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh payment.");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));

		deleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete payment.");
		deleteButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				deleteButton_actionPerformed(evt);
			 }
		});
		
		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5,0)));
		
		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setFocusTraversalPolicy(new InputOrderFocusTrafersalPolicy());
		dialogPanel.setFocusCycleRoot(true);	// This will force focus go down the colum

		// Dialog fields
		dialogPanel.add(paymentIDLabel);
		Dimension fieldDimension = new Dimension(200, paymentIDLabel.getPreferredSize().height);
		paymentIDField.setToolTipText("Generated by system.");
		paymentIDField.setEditable(false);
		dialogPanel.add(paymentIDField);

		dialogPanel.add(clientIDLabel);
		clientIDField.setEditable(false);
		dialogPanel.add(clientIDField);

		dialogPanel.add(invoiceIDLabel);
		invoiceIDField.setEditable(false);
		dialogPanel.add(invoiceIDField);

		dialogPanel.add(paymentDateLabel);
		paymentDateField.setEditable(true);
		dialogPanel.add(paymentDateField);

		dialogPanel.add(amountLabel);
		amountDisplayFormat = NumberFormat.getCurrencyInstance();
		amountDisplayFormat.setMinimumFractionDigits(2);
		amountEditFormat = NumberFormat.getNumberInstance();
		amountField= new JFormattedTextField(
				new DefaultFormatterFactory(
					new NumberFormatter(amountDisplayFormat),
					new NumberFormatter(amountDisplayFormat),
					new NumberFormatter(amountEditFormat)
					)
				);
		amountField.setEditable(true);
		dialogPanel.add(amountField);

		dialogPanel.add(tenderIDLabel);
		tenderIDField.setEditable(true);
		dialogPanel.add(tenderIDField);

		dialogPanel.add(commentLabel);
		commentField.setLineWrap(true);
		commentField.setWrapStyleWord(true);	// wrap only on word boundary
		// Ensure tabs are handled by focus manager
		commentField.setFocusTraversalKeys(
				KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,null);
		commentField.setFocusTraversalKeys(
			KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,null);
		 
		JScrollPane commentScrollPane = new JScrollPane(commentField);
		dialogPanel.add(commentScrollPane);

		dialogPanel.add(updaterPersonIDLabel);
		updaterPersonIDField.setEditable(false);
		dialogPanel.add(updaterPersonIDField);

		dialogPanel.add(dateCreatedLabel);
		dateCreatedField.setEditable(false);
		dialogPanel.add(dateCreatedField);

		dialogPanel.add(dateUpdatedLabel);
		dateUpdatedField.setEditable(false);
		dialogPanel.add(dateUpdatedField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
		
		// Add dialogPanel to content panel 
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);

		pack();
	}

	/**
	 * Populate form using primary key
	 * @param paymentID primary key
	 */
	public void populateForm(int paymentID) {

		String msg = null;
		try {
			msg = "PaymentForm: Cannot find payment: " + paymentID;
			paymentMap = genericController.findWhere("payment", "payment_id=" + paymentID);

			Integer invoiceID = (Integer) paymentMap.get("invoice_id");
			msg = "PaymentForm: Cannot find invoice: " + invoiceID;
			invoiceMap = genericController.findWhere("invoice", "invoice_id=" + invoiceID);
			
			Integer clientID = (Integer) invoiceMap.get("client_id");
			msg = "PaymentForm: Cannot find client: " + clientID;
			clientMap = genericController.findWhere("client", "client_id=" + clientID);

			Integer personID = (Integer) paymentMap.get("updater_person_id");
			personMap = Updater.getUpdater(personID.intValue());

			msg = "PaymentForm: Cannot find tenders";
			tenderList = genericController.findAll("tender", "tender");
		} catch (ControllerException ce) {
			Messager.exception(this, msg + "\n" + ce.getMessage());
			return;
		} catch (FinderException fe) {
			Messager.exception(this, msg  + "\n" + fe.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		// Fill combobox
		GenericUtils.updateJComboBox(tenderIDField, tenderList, "tender", "tender_id", (Integer) paymentMap.get("tender_id"));

		paymentIDField.setText(String.valueOf(paymentMap.get("payment_id").toString()));
		invoiceIDField.setText(invoiceMap.get("invoice_id").toString());
		clientIDField.setText((String) clientMap.get("last_name"));
		paymentDateField.setValue(paymentMap.get("payment_date"));
		amountField.setValue(paymentMap.get("amount"));
		commentField.setText((String) paymentMap.get("comment"));
		updaterPersonIDField.setText((String) personMap.get("user_name"));
		dateCreatedField.setValue(paymentMap.get("date_created"));
		dateUpdatedField.setValue(paymentMap.get("date_updated"));
	}
	
	public void populateNewForm(Map invoiceMap) {

		this.invoiceMap = invoiceMap;

		try {
			clientMap = genericController.findWhere("client", "client_id=" + invoiceMap.get("client_id"));
		} catch (FinderException fe) {
			Messager.exception(this, "PaymentForm: Error getting client" + fe.getMessage());
			return;
		} catch (ControllerException ce) {
			Messager.exception(this, "PaymentForm: Error getting client" + ce.getMessage());
			return;
		}
		
		newButton_actionPerformed();
	}

	private void newButton_actionPerformed() {

		try {
			paymentMap.put("payment_id", null);
			personMap = LoginController.getPerson();
			tenderList = genericController.findAll("tender", "tender"); 
		} catch (ControllerException ce) {
			Messager.exception(this, "PaymentForm: Error getting payment data" + ce.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		Map tenderMap = null;
		
		// Fill combobox
		GenericUtils.updateJComboBox(tenderIDField, tenderList, "tender");
		
		paymentIDField.setText(null);
		invoiceIDField.setText(invoiceMap.get("invoice_id").toString());
		clientIDField.setText(clientMap.get("last_name").toString());
		paymentDateField.setValue(new Date());
		amountField.setValue(null);
		commentField.setText(null);
		updaterPersonIDField.setText(LoginController.getPerson().get("user_name").toString());
		dateCreatedField.setValue(new Date());
		dateUpdatedField.setValue(new Date());
	}

	private void saveButton_actionPerformed(ActionEvent evt) {
		
		if (!validateForm()) {
			return;
		}
		
		// Store fields in paymentMap 
		// Convert display values to foreign keys before passing paymentMap to nz.co.transparent.client.controller
		//paymentMap.put("invoice_id", paymentMap.get("invoice_id"));
		paymentMap.put("invoice_id", invoiceIDField.getText());
		paymentMap.put("payment_date", paymentDateField.getValue());
		paymentMap.put("amount", amountField.getValue());
		paymentMap.put("tender_id", GenericUtils.getKey(tenderList, "tender_id", "tender", (String) tenderIDField.getSelectedItem()));
		paymentMap.put("comment", commentField.getText());
		paymentMap.put("updater_person_id", LoginController.getPerson().get("person_id"));
		paymentMap.put("date_created", dateCreatedField.getValue());
		paymentMap.put("date_updated", dateUpdatedField.getValue());

		try {
			if (paymentIDField.getText().equals("")) {
				paymentMap.put("payment_id", null); 	// Generate key
				genericController.insertRecord("payment", "payment_id", paymentMap);
			} else {
				paymentMap.put("payment_id", Integer.valueOf(paymentIDField.getText()));	// Cast to Integer, otherwise record lookup and update will fail
				genericController.updateRecord("payment", "payment_id", paymentMap);
			}
			
			Integer paymentID = (Integer) paymentMap.get("payment_id");
			populateForm(paymentID.intValue());
		} catch (UpdaterException ue) {
			String message = "Update warning !\n";
			message += "Changes have been made by an other person or process.\n";
			message += "Form will be refreshed with latest values";
			Messager.warning(this, message);
			populateForm(Integer.parseInt(paymentMap.get("payment_id").toString()));
		} catch (ControllerException ce) {
			Messager.exception(this, "Error: " + ce.getMessage());
		}
	}

	private void deleteButton_actionPerformed(ActionEvent evt) {
		String msg = null;

		if (paymentMap.get("payment_id") == null) {
			msg = "New payment cannot be deleted";
			Messager.information(this, msg);
			return;
		}

		msg = "Continue to delete payment ?";
		if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
			return;
		}
			
		try {
			Integer paymentID = (Integer) paymentMap.get("payment_id");
			genericController.deleteRecord("payment", "payment_id=" + paymentID.intValue());
			newButton_actionPerformed();
		} catch (ControllerException ce) {
			Messager.exception(this, "PaymentForm: Error deleting payment.\n" + ce.getMessage());
			return;
		}
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogPanel);
		
		if (paymentDateField.getText().equals("")) {
			paymentDateField.setBackground(Color.YELLOW);
			paymentDateField.setToolTipText("Please enter payment date");
			paymentDateField.requestFocus();
			validationOk = false;
		}

		if (amountField.getText().equals("")) {
			amountField.setBackground(Color.YELLOW);
			amountField.setToolTipText("Please enter amount");
			amountField.requestFocus();
			validationOk = false;
		}

		if (tenderIDField.getSelectedItem().equals("")) {
			tenderIDField.getEditor().getEditorComponent().setBackground(Color.YELLOW);
			tenderIDField.setToolTipText("Please enter contact type");
			tenderIDField.requestFocus();
			validationOk = false;
		}

		// Check if new item entered in combobox
		String msg = null;
		try {
			if (tenderIDField.getSelectedIndex() == -1) {
				// Add new tender silently, if required
				paymentMap.put("tender_id", genericController.getForeignKey("tender", (String) tenderIDField.getSelectedItem(), "tender", "tender_id", tenderList));
				GenericUtils.updateJComboBox(tenderIDField, tenderList, "tender", "tender_id", (Integer) paymentMap.get("tender_id"));
			}

			return validationOk;
		} catch (ControllerException ce) {
			msg = "Controller error: " + ce.getMessage();
			log.warning(msg);
			Messager.exception(this, msg);
			return false;
		}
	}
	
	private void reloadButton_actionPerformed(ActionEvent evt) {
		Integer paymentID = (Integer) paymentMap.get("payment_id");
		
		if (paymentID == null) {
			this.newButton_actionPerformed();
		} else {
			this.populateForm(paymentID.intValue());
		}
	}

}