/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Dec 17, 2003
 *
 */
package nz.co.transparent.client.gui.util;

import nz.co.transparent.client.gui.GenericTableModel;

import java.awt.Color;
import java.awt.Component;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumnModel;

/**
 * @author johnz
 * 
 */
public class GenericUtils {

	private static DefaultTableCellRenderer defaultTableCellRendererLeft  = new DefaultTableCellRenderer();
	private static DefaultTableCellRenderer defaultTableCellRendererRight = new DefaultTableCellRenderer();

	static {
		defaultTableCellRendererLeft.setHorizontalAlignment(SwingConstants.LEFT);
		defaultTableCellRendererRight.setHorizontalAlignment(SwingConstants.RIGHT);
	}
	
	/**
	 * 
	 */
	private GenericUtils() {
		super();
	}


	
	/**
	 * Search for searchValue in list.
	 * Return value of keyColumName in list
	 * 
	 * @param list List to be searched for searchValue
	 * @param keyColumnName Name of column which value is returned
	 * @param searchColumnName Column name to search
	 * @param searchValue Vlue to search for
	 * @return Value of keyColumnName in row found
	 */
	public static Object getKey(List list, String keyColumnName, String searchColumnName,  String searchValue) {
		
		Iterator iterator = list.iterator();
		String listValue = null;
		while (iterator.hasNext()) {
			Map recordMap = (Map) iterator.next();
			listValue = (String) recordMap.get(searchColumnName);
			if (listValue != null) {
				if (listValue.equals(searchValue)) {
					return recordMap.get(keyColumnName);
				}
			}
		}
		
		return null;
	}

	/**
	 * Fill combobox with values of list.
	 * Make row whith matchIndex selected row
	 * 
	 * @param comboBox JCombobox to be filled with displayColumnName of list
	 * @param list List with <code>Map</code> entries. Each meap entry has {ColumnName, ColumnValue} pairs
	 * @param displayColumnName Name of column to display in comboBox
	 * @param matchColumnName Name of column to match up with matchIndex
	 * @param matchIndex Value of index to match with
	 */
	public static void updateJComboBox(JComboBox comboBox, List list, String displayColumnName, String matchColumnName, Integer matchIndex) {
	
		comboBox.removeAllItems();
		Map recordMap;
		Iterator iterator = list.iterator();
		Integer selectedListValue = null; 
		while (iterator.hasNext()) {
			recordMap = (Map) iterator.next();
			comboBox.addItem(recordMap.get(displayColumnName));
			selectedListValue = (Integer) recordMap.get(matchColumnName); 

			if (selectedListValue.equals(matchIndex)) {
				comboBox.setSelectedItem(recordMap.get(displayColumnName));
			}
		}
	}

	public static void updateJComboBox(JComboBox comboBox, List list, String displayColumnName) {
	
		comboBox.removeAllItems();
		
		if (list == null) {
			return;
		}
		
		Map recordMap;
		Iterator iterator = list.iterator();
		Boolean isDefault = null; 
		while (iterator.hasNext()) {
			recordMap = (Map) iterator.next();
			comboBox.addItem(recordMap.get(displayColumnName));
			isDefault = (Boolean) recordMap.get("is_default");
			
			if (isDefault != null && isDefault.equals(Boolean.TRUE)) {
				comboBox.setSelectedItem(recordMap.get(displayColumnName));
			}
		}
	}
	
	/**
	 * Reset background color and tool tips of input fields
	 *
	 */
	public static void resetInputFields(JPanel panel) {
		Component[] components = panel.getComponents();
		JTextField textField = null;

		for (int i=0; i<components.length; i++) {
			if (components[i] instanceof JTextField) {
				textField = (JTextField) components[i];
				if (textField.isEditable()) { 
					textField.setBackground(Color.WHITE);
					textField.setToolTipText("");
				}
			} else if (components[i] instanceof JComboBox) {
				JComboBox comboField = (JComboBox) components[i];
				comboField.getEditor().getEditorComponent().setBackground(Color.WHITE);
				comboField.setToolTipText("");
			}
		}
	}
	
	/**
	 * Refresh the contents of table 
	 * Previous selection will be preserved, if still present
	 * 
	 */
	public static void updateTable(JTable table, GenericTableModel tableModel) {
		Integer prevSelected = null; // Preserve the previous selection
		int index = table.getSelectedRow();
		
		try {
			if (index >= 0) {
				prevSelected = (Integer) table.getValueAt(index, 0);
			}
		} catch (IndexOutOfBoundsException ie) {
			// Can happen if new list in GenerciTableModel smaller in size
			// Ignore
			index = -1;
		}

		// Reset the table data
		table.setModel(tableModel);
		TableColumnModel tableColumnModel = table.getColumnModel();
		
		for (int i=0; i<tableModel.getColumnCount(); i++) {
			if (tableModel.getColumnProperty(i, "isCurrency") != null && tableModel.getColumnProperty(i, "isCurrency").equals(Boolean.TRUE)) {
				tableColumnModel.getColumn(i).setCellRenderer( defaultTableCellRendererRight);
			} else {
				tableColumnModel.getColumn(i).setCellRenderer( defaultTableCellRendererLeft);
			}
		}

		table.revalidate();
		table.repaint();
		
		if (prevSelected == null) {
			return;
		}
		
		// Reselect the previous item if it still exists
		Integer selectKey;
		for (int i=0; i < table.getRowCount(); i++) {
			selectKey = (Integer) table.getValueAt(i, 0);

			if (selectKey.equals(prevSelected) ) {
				table.setRowSelectionInterval(i,i);
				break;
			}
		}
	}
	
	/**
	 * Return String or null
	 * @param obj
	 * @return If null, return null. Otherwise return <code>String</code>
	 */
	public static String setText(Object obj) {
		return (obj == null ? null : obj.toString());
	}

}