/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

package test;


public class ImportDatabase {

	public static void main(String[] args) {
//		
//		System.out.println();
//
//		try {
//			Class.forName("com.mckoi.JDBCDriver").newInstance();
//		} catch (Exception e) {
//			System.out.println(
//				"Unable to register the JDBC Driver.\n"
//					+ "Make sure the classpath is correct.\n"
//					+ "For example on Win32;  java -cp ../../mckoidb.jar;. SimpleApplicationDemo\n"
//					+ "On Unix;  java -cp ../../mckoidb.jar:. SimpleApplicationDemo");
//			return;
//		}
//
//		// This URL specifies we are connecting.
//		String url = "jdbc:mckoi://localhost";
//
//		// The username/password for the database.  This will be the username/
//		// password for the user that has full control over the database.
//		// ( Don't use this demo username/password in your application! )
//		String username = "admin_user";
//		String password = "client00";
//
//		// Make a connection with the database.  This will create the database
//		// and log into the newly created database.
//		Connection connection;
//		try {
//			connection = DriverManager.getConnection(url, username, password);
//		} catch (SQLException e) {
//			System.out.println(
//				"Unable to create the database.\n"
//					+ "The reason: "
//					+ e.getMessage());
//			return;
//		}
//
//		// --- Set up the database ---
//
//		try {
//			// Create a Statement object to execute the queries on,
//			Statement statement = connection.createStatement();
//			ResultSet result;
//
//			System.out.println("-- Creating Tables --");
//
//			// Create tables from resource/clientDB.sql
//			FileInputStream fis =
//				new FileInputStream("../../resource/clientDB.sql");
//			BufferedInputStream bufferedReader = new BufferedInputStream(fis);
//
//			//while 
//			
//			statement.executeQuery(
//				"CREATE TABLE xxxData (rowid INTEGER NOT NULL INDEX_BLIST, geo_rowid INTEGER NOT NULL INDEX_BLIST, product_rowid INTEGER NOT NULL INDEX_BLIST, period_rowid INTEGER NOT NULL INDEX_BLIST, measure1 FLOAT, measure2 FLOAT)");
//			statement.executeQuery(
//				"CREATE TABLE xxxGeo (geo_rowid INTEGER NOT NULL INDEX_BLIST, geo_id VARCHAR(10), geo_descr VARCHAR(128), geo_longdescr VARCHAR(255))");
//			statement.executeQuery(
//				"CREATE TABLE xxxPeriod (period_rowid INTEGER NOT NULL INDEX_BLIST, period_id VARCHAR(10), period_descr VARCHAR(128), period_longdescr VARCHAR(255))");
//			statement.executeQuery(
//				"CREATE TABLE xxxProduc (produc_rowid INTEGER NOT NULL INDEX_BLIST, produc_id VARCHAR(10), produc_descr VARCHAR(128), produc_longdescr VARCHAR(255))");
//
//			// Insert records into the tables,
//
//			System.out.println("-- Inserting Data --");
//
//			System.out.println("-- Adding to xxxData Table --");
//
//			try {
//
//				FileInputStream fis =
//					new FileInputStream(new File("Data_yyy.txt"));
//				Reader r = new BufferedReader(new InputStreamReader(fis));
//				StreamTokenizer st = new StreamTokenizer(r);
//				boolean done = false;
//				st.lowerCaseMode(true);
//				st.eolIsSignificant(true);
//				st.parseNumbers();
//				st.whitespaceChars(';', ';');
//
//				int rowid = 1, i;
//				double[] data = new double[5];
//				String query;
//
//				connection.setAutoCommit(false);
//
//				while (!done) {
//					for (i = 0;(i < 6) && (!done); i++) {
//						switch (st.nextToken()) {
//							case StreamTokenizer.TT_NUMBER :
//								data[i] = st.nval;
//								break;
//
//							case StreamTokenizer.TT_WORD :
//								System.out.println("WORD {" + st.nval + "}");
//								break;
//
//							case StreamTokenizer.TT_EOL :
//								query =
//									"INSERT INTO xxxData VALUES ("
//										+ rowid
//										+ ","
//										+ (int) data[0]
//										+ ","
//										+ (int) data[1]
//										+ ","
//										+ (int) data[2]
//										+ ","
//										+ data[3]
//										+ ","
//										+ data[4]
//										+ ")";
//								statement.executeQuery(query);
//								rowid++;
//								if ((rowid % 1000) == 0) {
//									System.out.println(
//										"committing row " + rowid);
//									connection.commit();
//								}
//								break;
//
//							case StreamTokenizer.TT_EOF :
//								done = true;
//								break;
//
//							default :
//								break;
//						}
//					}
//				}
//
//				connection.commit();
//				connection.setAutoCommit(true);
//				fis.close();
//			} catch (Exception ex) {
//				ex.printStackTrace();
//			}
//
//			System.out.println("-- Adding to xxxGeo Table --");
//
//			try {
//				BufferedReader in =
//					new BufferedReader(new FileReader("Geo_yyy.txt"));
//				String line;
//				int i;
//
//				connection.setAutoCommit(false);
//
//				while ((line = in.readLine()) != null) {
//					StringTokenizer st = new StringTokenizer(line, ";");
//					boolean done = false;
//					StringBuffer query;
//
//					query = new StringBuffer("INSERT INTO xxxGeo VALUES ('");
//					for (i = 0; i < 4; i++) {
//						query.append(st.nextToken());
//						if (i < 3)
//							query.append("','");
//					}
//					query.append("')");
//					System.out.println(query);
//					statement.executeQuery(query.toString());
//				}
//
//				connection.commit();
//				connection.setAutoCommit(true);
//			} catch (Exception ex) {
//				ex.printStackTrace();
//			}
//
//			System.out.println("-- Adding to xxxPeriod Table --");
//
//			try {
//				BufferedReader in =
//					new BufferedReader(new FileReader("Period_yyy.txt"));
//				String line;
//				int i;
//
//				connection.setAutoCommit(false);
//
//				while ((line = in.readLine()) != null) {
//					StringTokenizer st = new StringTokenizer(line, ";");
//					boolean done = false;
//					StringBuffer query;
//
//					query = new StringBuffer("INSERT INTO xxxPeriod VALUES ('");
//					for (i = 0; i < 4; i++) {
//						query.append(st.nextToken());
//						if (i < 3)
//							query.append("','");
//					}
//					query.append("')");
//					System.out.println(query);
//					statement.executeQuery(query.toString());
//				}
//
//				connection.commit();
//				connection.setAutoCommit(true);
//			} catch (Exception ex) {
//				ex.printStackTrace();
//			}
//
//			System.out.println("-- Adding to xxxProduc Table --");
//
//			try {
//				BufferedReader in =
//					new BufferedReader(new FileReader("Produc_yyy.txt"));
//				String line;
//				int i;
//
//				connection.setAutoCommit(false);
//
//				while ((line = in.readLine()) != null) {
//					StringTokenizer st = new StringTokenizer(line, ";");
//					boolean done = false;
//					StringBuffer query;
//
//					query = new StringBuffer("INSERT INTO xxxProduc VALUES ('");
//					for (i = 0; i < 4; i++) {
//						query.append(st.nextToken());
//						if (i < 3)
//							query.append("','");
//					}
//					query.append("')");
//					System.out.println(query);
//					statement.executeQuery(query.toString());
//				}
//
//				connection.commit();
//				connection.setAutoCommit(true);
//			} catch (Exception ex) {
//				ex.printStackTrace();
//			}
//			System.out.println("--- Complete ---");
//
//			// Close the statement and the connection.
//			statement.close();
//			connection.close();
//
//		} catch (SQLException e) {
//			System.out.println(
//				"An error occured\n"
//					+ "The SQLException message is: "
//					+ e.getMessage());
//
//		}
//
//		// Close the the connection.
//		try {
//			connection.close();
//		} catch (SQLException e2) {
//			e2.printStackTrace(System.err);
//		}
//
//	}
	}
}
