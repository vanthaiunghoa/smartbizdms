/*
 * Created on Oct 23, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

/*
 * 	To test this program from the command line.
 * 	Go to folder with EmbeddedDatabaseDemo.class
 * 	File nz.co.transparent.client.db.conf is in /resource folder of project
 * 	In shell type: 
 * 	java -cp $MCKOI_HOME/mckoidb.jar:.. test.EmbeddedDatabaseDemo
 */
 
import java.sql.*;
import java.util.Date;

public class EmbeddedDatabaseDemo {

	public static void main(String[] args) {

		// Register the Mckoi JDBC Driver
		try {
			Class.forName("com.mckoi.JDBCDriver").newInstance();
		} catch (Exception e) {
			System.out.println(
					"Unable to register the JDBC Driver.\n"
						+ "Make sure the JDBC driver is in the\n"
						+ "classpath.\n");
			System.exit(1);
		}

		// This URL specifies we are connecting with a local database
		// within the file system.  
		// './nz.co.transparent.client.db.conf' is the path of the
		// configuration file of the database to embed.
		//String url = "jdbc:mckoi:local://./nz.co.transparent.client.db.conf";
		
        // This setting of nz.co.transparent.client.db.conf works on Eclipse but not on Netbeans.
        // On Netbeans either use Ant script in test/build.xml or pass nz.co.transparent.client.db.con as a parameter
        String dbconf = "resource/nz.co.transparent.client.db.conf";
		if (args.length == 1) {
			dbconf = args[0];
		}
		
		String url = "jdbc:mckoi:local://" + dbconf;

		// The username / password to connect under.
		String username = "admin_user";
		String password = "client00";

		// Make a connection with the local database.
		Connection connection;
		
		// Check to see if connection is pooled
		long startTime = new Date().getTime();
		long currentTime;
		for (int n=0; n <1; n++) {
			System.out.println("=======");
			System.out.println("n=" + n);
			try {
				connection = DriverManager.getConnection(url, username, password);
				System.out.println("Connection time=" + (new Date().getTime() - startTime));
			} catch (SQLException e) {
				System.out.println(
					"Unable to make a connection to the database.\n"
						+ "The reason: "
						+ e.getMessage());
				System.exit(1);
				return;
			}
	
			try {
	
				// .... Use 'connection' to talk to database ....
	
				// Close the connection when finished,
				connection.close();
				startTime = new Date().getTime();
	
			} catch (SQLException e) {
				System.out.println(
					"An error occured\n"
						+ "The SQLException message is: "
						+ e.getMessage());
				return;
			}
		}
		
		System.out.println("Ready testing embedded database");
	}
}
