/*
 * Created on Jan 21, 2004
 *
 */
package test;

import java.io.File;
import java.io.FileOutputStream;

import nz.co.transparent.client.util.Configuration;
import nz.co.transparent.client.util.SymmetricEncrypter;

/**
 * @author John Zoetebier
 * 
 */
public class TestSymmetricEncrypter {

	/**
	 * 
	 */
	public TestSymmetricEncrypter() {
		super();
	}

	public static void  encrypt(String text) 
		throws Exception {

			String fileName = Configuration.getProperty("client.dir", "") + "/resource/test.txt";
			FileOutputStream fos = new FileOutputStream(new File(fileName));
			
			byte[] encryptionBytes = null;
			encryptionBytes = SymmetricEncrypter.encrypt(text);
			System.out.println(encryptionBytes);
			System.out.println(encryptionBytes.length);
			fos.write(encryptionBytes);
			fos.close();
	}

	public static void main(String[] args) 
		throws Exception {

			encrypt("password");
	}
}
