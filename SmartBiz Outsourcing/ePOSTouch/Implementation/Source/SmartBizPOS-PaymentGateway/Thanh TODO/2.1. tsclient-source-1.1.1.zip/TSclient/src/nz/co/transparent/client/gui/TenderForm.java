/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Tender.java
 * 
 * Created on Januari 6, 2004
 */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.*;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;

/**
 * @author John Zoetebier
 */
public class TenderForm extends javax.swing.JInternalFrame {

	// Constants
	private static final int FIELD_LENGTH = 14;

	// Private variables
	private Map tenderMap = new HashMap();
	private Map personMap = new HashMap();
	private GenericController genericController =
		GenericController.getInstance();

	private JLabel tenderIDLabel = new JLabel("Tender ID");
	private JLabel tenderLabel = new JLabel("Tender");
	private JLabel isDefaultLabel = new JLabel("Is default");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	private JLabel dateCreatedLabel = new JLabel("Date created");
	private JLabel dateUpdatedLabel = new JLabel("Date updated");

	private DateFormat timeStampFormat =
		new SimpleDateFormat(Parameter.getParameter("format.timestamp", Constants.FORMAT_TIMESTAMP));

	private JTextField tenderIDField = new JTextField();
	private JTextField tenderField = new JTextField();
	private JCheckBox isDefaultField = new JCheckBox();
	private JTextField updaterPersonIDField = new JTextField();
	private JFormattedTextField dateCreatedField =
		new JFormattedTextField(timeStampFormat);
	private JFormattedTextField dateUpdatedField =
		new JFormattedTextField(timeStampFormat);

	private JPanel contentPanel = new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();

	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public TenderForm() {

		setName("Tender form");
		setTitle("Tender form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));

		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);
		addInternalFrameListener(
			new InternalFrameOpenedAdapter(this, tenderField));

		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New tender.");
		newButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				newButton_actionPerformed();
			}
		});

		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		saveButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save tender.");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(saveButton);

		reloadButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh tender.");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		deleteButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete tender.");
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				deleteButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setFocusTraversalPolicy(
			new InputOrderFocusTrafersalPolicy());
		dialogPanel.setFocusCycleRoot(true);

		// Dialog fields
		dialogPanel.add(tenderIDLabel);
		Dimension fieldDimension =
			new Dimension(200, tenderIDLabel.getPreferredSize().height);
		tenderIDField.setToolTipText("Generated by system.");
		tenderIDField.setEditable(false);
		tenderIDField.setColumns(FIELD_LENGTH);
		dialogPanel.add(tenderIDField);

		dialogPanel.add(tenderLabel);
		dialogPanel.add(tenderField);

		dialogPanel.add(isDefaultLabel);
		dialogPanel.add(isDefaultField);

		dialogPanel.add(updaterPersonIDLabel);
		updaterPersonIDField.setEditable(false);
		dialogPanel.add(updaterPersonIDField);

		dialogPanel.add(dateCreatedLabel);
		dateCreatedField.setEditable(false);
		dialogPanel.add(dateCreatedField);

		dialogPanel.add(dateUpdatedLabel);
		dateUpdatedField.setEditable(false);
		dialogPanel.add(dateUpdatedField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));

		// Add dialogPanel to content panel
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);
		pack();
	}

	/**
	 * Populate form using PK tenderID
	 * 
	 * @param tenderID
	 *                Primary key
	 */
	public void populateForm(int tenderID) {

		String msg = null;
		try {
			msg = "TenderForm: Cannot find tender: " + tenderID;
			tenderMap =
				genericController.findWhere("tender", "tender_id=" + tenderID);
			
			Integer personID = (Integer) tenderMap.get("updater_person_id");
			personMap = Updater.getUpdater(personID.intValue());
		} catch (ControllerException ce) {
			Messager.exception(this, msg + "\n" + ce.getMessage());
			return;
		} catch (FinderException fe) {
			Messager.exception(this, msg + "\n" + fe.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		tenderIDField.setText(
			String.valueOf(tenderMap.get("tender_id").toString()));
		tenderField.setText(tenderMap.get("tender").toString());
		isDefaultField.setSelected(
			((Boolean) (tenderMap.get("is_default"))).booleanValue());
		updaterPersonIDField.setText(personMap.get("user_name").toString());
		dateCreatedField.setValue(tenderMap.get("date_created"));
		dateUpdatedField.setValue(tenderMap.get("date_updated"));
	}

	/**
	 * Populate new form
	 *  
	 */
	public void populateNewForm() {

		newButton_actionPerformed();
	}

	private void deleteButton_actionPerformed(ActionEvent evt) {
		String msg = null;

		if (tenderMap.get("tender_id") == null) {
			msg = "New tender cannot be deleted";
			Messager.information(this, msg);
			return;
		}

		msg = "Continue to delete tender ?";
		if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
			return;
		}

		try {
			Integer tenderID = (Integer) tenderMap.get("tender_id");
			genericController.deleteRecord(
				"tender",
				"tender_id=" + tenderID.intValue());
			newButton_actionPerformed();
		} catch (ControllerException ce) {
			Messager.exception(
				this,
				"TenderForm: Error deleting tender.\n" + ce.getMessage());
			return;
		}
	}

	private void newButton_actionPerformed() {

		tenderMap.put("tender_id", null);
		personMap = LoginController.getPerson();

		GenericUtils.resetInputFields(dialogPanel);
		Map tenderMap = null;

		tenderIDField.setText(null);
		tenderField.setText(null);
		isDefaultField.setText(null);
		updaterPersonIDField.setText(
			(String) LoginController.getPerson().get("user_name"));
		dateCreatedField.setValue(new Date());
		dateUpdatedField.setValue(new Date());
	}

	private void saveButton_actionPerformed(ActionEvent evt) {

		if (!validateForm()) {
			return;
		}

		// Store fields in tenderMap
		tenderMap.put("tender_id", tenderMap.get("tender_id"));
		tenderMap.put("tender", tenderField.getText());
		tenderMap.put(
			"is_default",
			Boolean.valueOf(isDefaultField.isSelected()));
		tenderMap.put(
			"updater_person_id",
			LoginController.getPerson().get("person_id"));
		tenderMap.put("date_created", dateCreatedField.getValue());
		tenderMap.put("date_updated", dateUpdatedField.getValue());

		try {
			if (tenderIDField.getText().equals("")) {
				tenderMap.put("tender_id", null); // Generate
				// key
				genericController.insertRecord(
					"tender",
					"tender_id",
					tenderMap);
			} else {
				// Cast to Integer, otherwise record lookup and update will
				// fail
				tenderMap.put(
					"tender_id",
					Integer.valueOf(tenderIDField.getText()));
				genericController.updateRecord(
					"tender",
					"tender_id",
					tenderMap);
			}

			Integer tenderID = (Integer) tenderMap.get("tender_id");
			// If is_default has been set, switch off any other default
			genericController.switchOffOtherDefault(
				"tender",
				"tender_id",
				tenderID,
				isDefaultField.isSelected());
			populateForm(tenderID.intValue());
		} catch (UpdaterException ue) {
			String message = "Update warning !\n";
			message
				+= "Changes have been made by an other person or process.\n";
			message += "Form will be refreshed with latest values";
			Messager.warning(this, message);
			this.populateForm(
				Integer.parseInt(tenderMap.get("tender_id").toString()));
		} catch (ControllerException ce) {
			Messager.exception(this, "Error: " + ce.getMessage());
		}
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogPanel);

		if (tenderField.getText().equals("")) {
			tenderField.setBackground(Color.YELLOW);
			tenderField.setToolTipText("Please enter tender");
			tenderField.requestFocus();
			validationOk = false;
		}

		return validationOk;
	}

	private void reloadButton_actionPerformed(ActionEvent evt) {
		Integer tenderID = (Integer) tenderMap.get("tender_id");

		if (tenderID == null) {
			this.newButton_actionPerformed();
		} else {
			this.populateForm(tenderID.intValue());
		}
	}
}