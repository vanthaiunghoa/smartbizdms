/*
 * Created on Dec 8, 2003
 *
 */
package test;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.*;

/**
 * @author johnz
 * 
 */
public class TestJList extends JFrame {

	private JList list;
	/**
	 * 
	 */
	public TestJList() {
		super();
		
		Container content = getContentPane();
		content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
		
		JTextField text1 = new JTextField("Some test field");
		content.add(text1);
		
		JButton focusButton = new JButton("Change focus");
		focusButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				list.requestFocus();
			}
		});
		
		content.add(focusButton);

		Vector vector = new Vector();
		vector.add("Item 1");
		vector.add("Item 2");
		vector.add("Item 3");
		vector.add("Item 4 something longer text");
		vector.add("Item 5");
		vector.add("Item 6");
		vector.add("Item 7");
		vector.add("Item 8");
		vector.add("Item 9");
		vector.add("Item 10");
		list = new JList(vector);
		list.setVisibleRowCount(5);
		list.setFixedCellWidth(600);
		JScrollPane scrollPane = new JScrollPane(list);
		scrollPane.getViewport().add(list);
		//scrollPane.getViewport().setSize(600,200);
		//scrollPane.setSize(600,200);
		
		content.add(scrollPane);

		setSize(400, 300);
		pack();
		show();
	}

	public static void main(String[] args) {
		new TestJList();
	}
}
