/*
 * Created on Dec 14, 2003
 *
 */
package test;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;

import nz.co.transparent.client.db.DataSourceHandler;
import nz.co.transparent.client.db.ResultSetMetaDataHandler;

/**
 * Test ResultSetMetaDataHandler
 * 
 * @author John Zoetebier
 * 
 */
public class TestResultSetMetaData {

	private String[] columnProperties = {
		"catalog_name",
		"column_class_name",
		"column_label",
		"column_name",
		"column_type_name",
		"schema_name",
		"table_name",
		"column_display_size",
		"column_type",
		"precision",
		"scale"
	};
		
	/**
	 * 
	 */
	public TestResultSetMetaData() {
		super();
	}
	
	public void go() {
		
		DataSource dataSource= DataSourceHandler.getDataSource();
		QueryRunner runner = new QueryRunner(dataSource);
		ResultSetHandler rsh = new ResultSetMetaDataHandler();
		String sql = "select * from Client";
		List columnList = null;
		try {
			columnList = (List) runner.query(sql, rsh);
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}
		
		Iterator iterator = columnList.iterator();
		String fieldName = null;
		Map columnMap = null;
		
		while (iterator.hasNext()) {
			columnMap = (Map) iterator.next();
			System.out.println("column_name = " + columnMap.get("column_name"));
			for (int i=0; i<columnProperties.length; i++) {
				System.out.println("   " + columnProperties[i] + " = " + columnMap.get(columnProperties[i]));
			}
		}
		
		System.out.println("==> Ready");
	}
	
	public static void main(String[] args) {
		new TestResultSetMetaData().go();
	}
}
