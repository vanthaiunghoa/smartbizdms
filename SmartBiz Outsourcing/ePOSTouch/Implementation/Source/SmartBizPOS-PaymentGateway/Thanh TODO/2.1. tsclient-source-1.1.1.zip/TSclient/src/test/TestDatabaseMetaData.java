/*
 * Created on Jan 11, 2004
 *
 */
package test;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

import javax.sql.DataSource;

import nz.co.transparent.client.db.DataSourceHandler;

/**
 * @author John Zoetebier
 * 
 */
public class TestDatabaseMetaData {

	/**
	 * 
	 */
	public TestDatabaseMetaData() {
		super();
	}

	public void go() {
		
		DataSource dataSource = DataSourceHandler.getDataSource() ;
		Connection connection = null;
		DatabaseMetaData metaData = null;

		try {
			connection = dataSource.getConnection();
			metaData = connection.getMetaData();
			System.out.println("JDBC major version=" + metaData.getJDBCMajorVersion());
			System.out.println("JDBC minor version=" + metaData.getJDBCMinorVersion());
		} catch (SQLException se) {
			System.out.println("SQL error\n" + se.getMessage());
			return;
		}
	}

	public static void main(String[] args) {
		new TestDatabaseMetaData().go();
	}
}
