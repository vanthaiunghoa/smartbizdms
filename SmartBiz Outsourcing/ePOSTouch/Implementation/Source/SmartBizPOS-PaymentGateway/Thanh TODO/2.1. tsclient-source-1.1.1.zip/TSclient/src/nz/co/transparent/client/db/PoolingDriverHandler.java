/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Nov 16, 2003
 * 
 * To change the template for this generated file go to Window - Preferences -
 * Java - Code Generation - Code and Comments
 */
package nz.co.transparent.client.db;

import java.util.logging.Logger;

import org.apache.commons.dbcp.*;
import org.apache.commons.pool.impl.GenericObjectPool;

import nz.co.transparent.client.util.Configuration;
import nz.co.transparent.client.util.Constants;

/**
 * @author johnz
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class PoolingDriverHandler {

	private Logger log = Logger.getLogger("nz.co.transparent.client.db");
	private GenericObjectPool connectionPool;

	public PoolingDriverHandler() {
		this(Constants.DATABASE_CONNECTION_POOL_NAME);
	}
	
	/**
	 * 
	 * @param poolName name of the database connection pool
	 */
	public PoolingDriverHandler(String poolName) {
		// Register the Mckoi JDBC Driver
		// required if you don't use the jdbc.drivers system property.
		log.info("Loading underlying JDBC driver.");
		String message;
		try {
			Class.forName("com.mckoi.JDBCDriver").newInstance();
		} catch (Exception e) {
			message =
				"Unable to register the JDBC Driver.\n"
					+ "Make sure the JDBC driver is in the\n"
					+ "classpath.\n";
			log.warning(message);
			return;
		}

		message = "JDBC driver instantiated.";
		log.info(message);
		
		//
		// First, we'll need a ObjectPool that serves as the
		// actual pool of connections.
		//
		// We'll use a GenericObjectPool instance, although
		// any ObjectPool implementation will suffice.
		//
		connectionPool = new GenericObjectPool(null);
		connectionPool.setWhenExhaustedAction(GenericObjectPool.WHEN_EXHAUSTED_GROW);
		connectionPool.setMaxActive(Integer.parseInt(Configuration.getProperty("dbcp.maxactive", Constants.DBCP_MAX_ACTIVE)));
		connectionPool.setMaxWait(Integer.parseInt(Configuration.getProperty("dbcp.maxwait", Constants.DBCP_MAX_WAIT)));
		connectionPool.setMaxIdle(Integer.parseInt(Configuration.getProperty("dbcp.maxidle", Constants.DBCP_MAX_IDLE)));
		connectionPool.setMinIdle(Integer.parseInt(Configuration.getProperty("dbcp.minidle", Constants.DBCP_MIN_IDLE)));
		
		//
		// Next, we'll create a ConnectionFactory that the
		// pool will use to create Connections.
		// We'll use the DriverManagerConnectionFactory,
		// using the connect string passed in the command line
		// arguments.
		//
		//ConnectionFactory connectionFactory = new
		// DriverManagerConnectionFactory(connectURI,null);
		//String url = "jdbc:mckoi:local://resource/db.conf";

		String url;
 
		if (Configuration.getProperty("server.mode", "embedded").equalsIgnoreCase("server")) {
			url =
				"jdbc:mckoi://"
					+ Configuration.getProperty("server.name", "localhost")
					+ ":"
					+ Configuration.getProperty("server.port", "9157");
		} else {
			url = "jdbc:mckoi:local://resource/nz.co.transparent.client.db.conf";
		}
		String username = Configuration.getProperty("database.username", "");
		String password = Configuration.getProperty("database.password", "");

		ConnectionFactory connectionFactory =
			new DriverManagerConnectionFactory(url, username, password);

		//
		// Now we'll create the PoolableConnectionFactory, which wraps
		// the "real" Connections created by the ConnectionFactory with
		// the classes that implement the pooling functionality.
		//
		PoolableConnectionFactory poolableConnectionFactory =
			new PoolableConnectionFactory(
				connectionFactory, connectionPool, null, null, false, true);

		//
		// Finally, we create the PoolingDriver itself...
		//
		PoolingDriver driver = new PoolingDriver();

		//
		// ...and register our pool with it.
		//
		driver.registerPool(poolName, connectionPool);

		//
		// Now we can just use the connect string
		// "jdbc:apache:commons:dbcp:example"
		// to access our pool of Connections.
		//
	}

	/**
	 * Close connection pool.
	 * Will close the real connections in the pool
	 * Use this method before application shutdown
	 */
	public void closeConnectionPool() {
		try {
			connectionPool.close();
		} catch (Exception e) {
			log.warning("Problem closing database connection pool");
			log.warning(e.getMessage());
		}
	}
	
	/**
	 * Add an idle connection to the connection pool
	 * Purpose: pre-loading of idle connections speeds of connection time by client
	 * Note: maximum number of idle connections will never exceed maximum number of idle connections
	 */
	public void addIdleConnection()
		throws Exception {
		connectionPool.addObject();
	}
	
	/**
	 * Add idle connections to the connection pool
	 * Purpose: pre-loading of idle connections speeds up connection time by client
	 * Note: maximum number of idle connections will not exceed <code>MaxIdle</code>
	 * @param idleConnectionCount Number of idleConnections
	 */
	public void addIdleConnection(int idleConnectionCount)
		throws Exception {
		
		for (int i=0; i < idleConnectionCount; i++) {
			connectionPool.addObject();
		}
	}
}