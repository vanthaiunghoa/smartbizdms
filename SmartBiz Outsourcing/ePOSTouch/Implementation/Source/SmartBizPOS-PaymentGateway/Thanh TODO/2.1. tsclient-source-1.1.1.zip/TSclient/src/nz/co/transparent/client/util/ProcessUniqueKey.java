/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Feb 2, 2004
 *
 */
package nz.co.transparent.client.util;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.DataSourceHandler;
import nz.co.transparent.client.db.SQL;

/**
 * @author John Zoetebier
 * 
 */
public class ProcessUniqueKey {

	/**
	 * 
	 */
	public ProcessUniqueKey() {
		super();
	}

	public static void main(String[] args) {
		
		// The userName/password for the database.  This will be the userName/
		// password for the user that has full control over the database.
		// ( Don't use this demo userName/password in your application! )
		// Get usernam and password from command args, if possible
		String userName = "";
		String password = "";

		if (args.length > 1) {
			System.out.println("UserName and Password passed as arguments");
			userName = args[0];
			password = args[1];
		} else {
			System.out.println("UserName and Password derived from configuration file config.properties");
			userName = Configuration.getProperty("login.username", "");
			password = Configuration.getProperty("login.password", "");
		}

		if (userName.equals("")) {
			throw new RuntimeException("ProcessUniqueKey:: syntax = util.ProcessUniqueKey <database_userName> <database_password>");
		}
		
		if (password.equals("")) {
			throw new RuntimeException("ProcessUniqueKey:: syntax = util.ProcessUniqueKey <database_userName> <database_password>");
		}
		
		// Setup datasource 
		DataSourceHandler.setPassword(password);
		DataSourceHandler.setUserName(userName);
		DataSource dataSource = DataSourceHandler.getDataSource();
		Connection connection = null;

		try {
			connection = dataSource.getConnection();
			connection.setAutoCommit(false);
		} catch (SQLException e) {
			System.out.println(
				"ProcessUniqueKey:: Unable to get database connection.\n"
					+ e.getMessage());
			System.exit(0);
		}

		// --- Set up the database ---

		try {
			DatabaseMetaData  metaData = connection.getMetaData();
			String[] types = {"TABLE"};
			ResultSet rst = metaData.getTables(null, "APP", "%", types);
			String tableName = null;
			String columnName = null;
			ResultSet rst2 = null;
			while (rst.next()) {
				tableName = rst.getString("TABLE_NAME");
				rst2 = metaData.getPrimaryKeys(null, "APP", tableName);
				rst2.next();
				columnName = rst2.getString("COLUMN_NAME");
				System.out.println("TableName=" + tableName);
				System.out.println("   ColumnName=" + columnName);
				SQL.resetUniqueKey(tableName, columnName);
			}
		} catch (SQLException e) {
			System.out.println("An error occured: " + e.getMessage());
			try {
				connection.rollback();
				connection.close();
				return;
			} catch (Exception e2) {
				return;
			}
		}

		// Close the the connection.
		try {
			connection.commit();
			connection.close();
			DataSourceHandler.closeDataSource();
		} catch (SQLException e2) {
			e2.printStackTrace(System.err);
		} catch (ControllerException ce) {
			System.out.println("ProcessSQL nz.co.transparent.client.controller exception::\n" + ce.getMessage());
		}
		
		System.out.println("ProcessUniqueKey ready");
	}
}
