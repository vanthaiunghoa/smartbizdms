/*
 * Created on Dec 26, 2003
 *  
 */
package test;

/**
 * @author John Zoetebier
 *  
 */

//Could anybody tell me why do I get "alfa" right-aligned in one column 
// and "alfa" left aligned in the other column, 
// instead of getting "alfa" right-aligned and "omega" left-aligned with the simple code below?

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

public class TestJTable2 extends JFrame {
	//	   private variables
	private JTable jTable1;
	private DefaultTableCellRenderer defaultTableCellRenderer1,
		defaultTableCellRenderer2;
	private TableColumn tableColumn1, tableColumn2;
	private TableColumnModel tableColumnModel;
	private DefaultTableModel defaultTableModel;

	public TestJTable2() {
		//	   sets some parameters of the window
		this.setSize(500, 500);
		this.getContentPane().setLayout(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

		//	   instantiates and places JTable component at a good position on
		//the window 
		jTable1 = new JTable();
		jTable1.setBounds(new Rectangle(89, 97, 221, 136));

		//	   instantiates and sets right alignment to a CellRenderer
		defaultTableCellRenderer1 = new DefaultTableCellRenderer();
		defaultTableCellRenderer1.setHorizontalAlignment(SwingConstants.RIGHT);

		//	   instantiates and sets left alignment to another CellRenderer
		defaultTableCellRenderer2 = new DefaultTableCellRenderer();
		defaultTableCellRenderer2.setHorizontalAlignment(SwingConstants.LEFT);

		//	   instantiates and sets a TableColumn to use the instantiated  CellRenderer
		tableColumn1 = new TableColumn(0);
		tableColumn1.setCellRenderer(defaultTableCellRenderer1);

		//	   instantiates and sets another TableColumn to use the other
		//instantiated CellRenderer 
		tableColumn2 = new TableColumn(1);
		tableColumn2.setCellRenderer(defaultTableCellRenderer2);

		//	   adds TableColumn?s to a new TableColumnModel
		tableColumnModel = new DefaultTableColumnModel();
		tableColumnModel.addColumn(tableColumn1);
		tableColumnModel.addColumn(tableColumn2);

		//	   instantiates a TableModel in order to be used by the JTable component 
		defaultTableModel =
			new DefaultTableModel(new Object[][] { 
											   { "alfa", "omega" }
			}, new Object[] { "A", "B" });

		//	   sets the JTable to use instantiated TableModel and ColumnModel
		jTable1.setModel(defaultTableModel);
		jTable1.setColumnModel(tableColumnModel);
	  TableColumnModel columnModel = jTable1.getColumnModel();
	  columnModel.getColumn(0).setCellRenderer( defaultTableCellRenderer1 );
	  columnModel.getColumn(1).setCellRenderer( defaultTableCellRenderer2 );

		//	   puts the JTable component into the window
		this.getContentPane().add(jTable1);
	}

	public static void main(String[] args) {
		//	   starts the application
		new TestJTable2().show();
	}
}