/*
 * ProcessSQLTest.java
 * JUnit based test
 *
 * Created on November 8, 2004, 3:33 PM
 */

package nz.co.transparent.client.util;

import junit.framework.*;
import java.sql.*;
import java.io.*;
import javax.sql.DataSource;
import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.DataSourceHandler;

/**
 *
 * @author johnz
 */
public class ProcessSQLTest extends TestCase {
    
    public ProcessSQLTest(String testName) {
        super(testName);
    }

    protected void setUp() throws java.lang.Exception {
    }

    protected void tearDown() throws java.lang.Exception {
    }

    public static junit.framework.Test suite() {
        junit.framework.TestSuite suite = new junit.framework.TestSuite(ProcessSQLTest.class);
        
        return suite;
    }

    /**
     * Test of main method, of class nz.co.transparent.client.util.ProcessSQL.
     */
    public void testMain() {
        System.out.println("testMain");
        
        // TODO add your test code below by replacing the default call to fail.
        //fail("The test case is empty.");
        
        String[] args = {""};
    }
    
    // TODO add test methods here. The name must begin with 'test'. For example:
    // public void testHello() {}
    
}
