package test;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

/**
 * @author johnz
 */
public class TestWidget extends JFrame {
	
	JTextArea textArea;
	JTextField text1;

	private void go() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		String comments = "When vertical scrollbar is visible you have to tab twice to set focus to next field\n";
		comments += "When vertical scrollbar is not visible you have to tab only one to set focus to next field\n";
		textArea = new JTextArea(comments, 4, 1);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setFocusTraversalKeys(
				KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,null);
		textArea.setFocusTraversalKeys(
			KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,null);
		//textArea.setNextFocusableComponent(text1);

		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setPreferredSize(new Dimension(150,100));
		//textArea.setMaximumSize(new Dimension(150, 100));
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		setContentPane(panel);
		//panel.add(textArea);
		panel.add(scrollPane);
		panel.add(Box.createRigidArea(new Dimension(10, 0)));
		text1 = new JTextField("Test 1");
		panel.add(text1);
		panel.add(Box.createRigidArea(new Dimension(10, 0)));
		JTextField text2 = new JTextField("Test 2");
		panel.add(text2);
		panel.add(Box.createRigidArea(new Dimension(10, 0)));
		JButton button1 = new JButton("Click Me");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String text = textArea.getText();
				System.out.println("text=" + text);
			}
		});
		
		panel.add(button1);
		//setSize(500, 600);
		pack();
		show();
	}
	
	public static void main (String [] args) {
		
		new TestWidget().go();
	}
}
