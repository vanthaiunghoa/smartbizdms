/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * ContactType.java
 * 
 * Created on Januari 2, 2004
 */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.*;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;

/**
 * @author John Zoetebier
 */
public class ContactTypeForm extends javax.swing.JInternalFrame {

	// Private variables
	private Map contactTypeMap = new HashMap();
	private Map personMap = new HashMap();
	private GenericController genericController =
		GenericController.getInstance();

	private JLabel contactTypeIDLabel = new JLabel("Contact type ID");
	private JLabel contactTypeLabel = new JLabel("ContactType");
	private JLabel isDefaultLabel = new JLabel("Is default");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	private JLabel dateCreatedLabel = new JLabel("Date created");
	private JLabel dateUpdatedLabel = new JLabel("Date updated");

	private DateFormat timeStampFormat =
		new SimpleDateFormat(Parameter.getParameter("format.timestamp", Constants.FORMAT_TIMESTAMP));

	private JTextField contactTypeIDField = new JTextField();
	private JTextField contactTypeField = new JTextField();
	private JCheckBox isDefaultField = new JCheckBox();
	private JTextField updaterPersonIDField = new JTextField();
	private JFormattedTextField dateCreatedField =
		new JFormattedTextField(timeStampFormat);
	private JFormattedTextField dateUpdatedField =
		new JFormattedTextField(timeStampFormat);

	private JPanel contentPanel = new JPanel();
	private JPanel middlePanel = new JPanel();
	// To get dialogPanel left alligned
	private JPanel dialogPanel = new JPanel();

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();

	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public ContactTypeForm() {

		setName("Contact type form");
		setTitle("Contact type form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);
		addInternalFrameListener(
			new InternalFrameOpenedAdapter(
				this,
				contactTypeField));

		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New contact type.");
		newButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				newButton_actionPerformed();
			}
		});

		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		saveButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save contact type.");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(saveButton);

		reloadButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh contact type.");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		deleteButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete contact type.");
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				deleteButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setFocusTraversalPolicy(
			new InputOrderFocusTrafersalPolicy());
		dialogPanel.setFocusCycleRoot(true);

		// Dialog fields
		dialogPanel.add(contactTypeIDLabel);
		Dimension fieldDimension =
			new Dimension(200, contactTypeIDLabel.getPreferredSize().height);
		contactTypeIDField.setToolTipText("Generated by system.");
		contactTypeIDField.setEditable(false);
		dialogPanel.add(contactTypeIDField);

		dialogPanel.add(contactTypeLabel);
		dialogPanel.add(contactTypeField);

		dialogPanel.add(isDefaultLabel);
		dialogPanel.add(isDefaultField);

		dialogPanel.add(updaterPersonIDLabel);
		updaterPersonIDField.setEditable(false);
		dialogPanel.add(updaterPersonIDField);

		dialogPanel.add(dateCreatedLabel);
		dateCreatedField.setEditable(false);
		dialogPanel.add(dateCreatedField);

		dialogPanel.add(dateUpdatedLabel);
		dateUpdatedField.setEditable(false);
		dialogPanel.add(dateUpdatedField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));

		// Add dialogPanel to content panel
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);

		pack();
	}

	/**
	 * Populate form using PK contactTypeID
	 * 
	 * @param contactTypeID
	 *                Primary key
	 */
	public void populateForm(int contactTypeID) {

		String msg = null;
		try {
			msg = "ContactTypeForm: Cannot find contactType: " + contactTypeID;
			contactTypeMap =
				genericController.findWhere(
					"contact_type",
					"contact_type_id=" + contactTypeID);
			Integer personID =
				(Integer) contactTypeMap.get("updater_person_id");
			personMap = Updater.getUpdater(personID.intValue());
		} catch (ControllerException ce) {
			Messager.exception(this, msg + "\n" + ce.getMessage());
			return;
		} catch (FinderException fe) {
			Messager.exception(this, msg + "\n" + fe.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		contactTypeIDField.setText(
			String.valueOf(contactTypeMap.get("contact_type_id").toString()));
		contactTypeField.setText(contactTypeMap.get("contact_type").toString());
		isDefaultField.setSelected(
			((Boolean) (contactTypeMap.get("is_default"))).booleanValue());
		updaterPersonIDField.setText(personMap.get("user_name").toString());
		dateCreatedField.setValue(contactTypeMap.get("date_created"));
		dateUpdatedField.setValue(contactTypeMap.get("date_updated"));
	}

	/**
	 * Populate new form
	 *  
	 */
	public void populateNewForm() {

		newButton_actionPerformed();
	}

	private void deleteButton_actionPerformed(ActionEvent evt) {
		String msg = null;

		if (contactTypeMap.get("contact_type_id") == null) {
			msg = "New contact type cannot be deleted";
			Messager.information(this, msg);
			return;
		}

		msg = "Continue to delete contact type ?";
		if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
			return;
		}

		try {
			Integer contactTypeID =
				(Integer) contactTypeMap.get("contact_type_id");
			genericController.deleteRecord(
				"contact_type",
				"contact_type_id=" + contactTypeID.intValue());
			newButton_actionPerformed();
		} catch (ControllerException ce) {
			Messager.exception(
				this,
				"ContactTypeForm: Error deleting contact type.\n"
					+ ce.getMessage());
			return;
		}
	}

	private void newButton_actionPerformed() {

		contactTypeMap.put("contact_type_id", null);
		personMap = LoginController.getPerson();

		GenericUtils.resetInputFields(dialogPanel);
		Map contactTypeMap = null;

		contactTypeIDField.setText(null);
		contactTypeField.setText(null);
		isDefaultField.setText(null);
		updaterPersonIDField.setText(
			(String) LoginController.getPerson().get("user_name"));
		dateCreatedField.setValue(new Date());
		dateUpdatedField.setValue(new Date());
	}

	private void saveButton_actionPerformed(ActionEvent evt) {

		if (!validateForm()) {
			return;
		}

		// Store fields in contactTypeMap
		// Convert display values to foreign keys before passing contactTypeMap
		// to nz.co.transparent.client.controller
		contactTypeMap.put(
			"contact_type_id",
			contactTypeMap.get("contact_type_id"));
		contactTypeMap.put("contact_type", contactTypeField.getText());
		contactTypeMap.put(
			"is_default",
			Boolean.valueOf(isDefaultField.isSelected()));
		contactTypeMap.put(
			"updater_person_id",
			LoginController.getPerson().get("person_id"));
		contactTypeMap.put("date_created", dateCreatedField.getValue());
		contactTypeMap.put("date_updated", dateUpdatedField.getValue());

		try {
			if (contactTypeIDField.getText().equals("")) {
				contactTypeMap.put("contact_type_id", null); // Generate
				// key
				genericController.insertRecord(
					"contact_type",
					"contact_type_id",
					contactTypeMap);
			} else {
				// Cast to Integer, otherwise record lookup and update will
				// fail
				contactTypeMap.put(
					"contact_type_id",
					Integer.valueOf(contactTypeIDField.getText()));
				genericController.updateRecord(
					"contact_type",
					"contact_type_id",
					contactTypeMap);
			}

			Integer contactTypeID =
				(Integer) contactTypeMap.get("contact_type_id");
			// If is_default has been set, switch off any other default
			genericController.switchOffOtherDefault(
				"contact_type",
				"contact_type_id",
				contactTypeID,
				isDefaultField.isSelected());
			populateForm(contactTypeID.intValue());
		} catch (UpdaterException ue) {
			String message = "Update warning !\n";
			message
				+= "Changes have been made by an other person or process.\n";
			message += "Form will be refreshed with latest values";
			Messager.warning(this, message);
			this.populateForm(
				Integer.parseInt(
					contactTypeMap.get("contact_type_id").toString()));
		} catch (ControllerException ce) {
			Messager.exception(this, "Error: " + ce.getMessage());
		}
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogPanel);

		if (contactTypeField.getText().equals("")) {
			contactTypeField.setBackground(Color.YELLOW);
			contactTypeField.setToolTipText("Please enter contactType");
			contactTypeField.requestFocus();
			validationOk = false;
		}

		return validationOk;
	}

	private void reloadButton_actionPerformed(ActionEvent evt) {
		Integer contactTypeID = (Integer) contactTypeMap.get("contact_type_id");

		if (contactTypeID == null) {
			this.newButton_actionPerformed();
		} else {
			this.populateForm(contactTypeID.intValue());
		}
	}
}