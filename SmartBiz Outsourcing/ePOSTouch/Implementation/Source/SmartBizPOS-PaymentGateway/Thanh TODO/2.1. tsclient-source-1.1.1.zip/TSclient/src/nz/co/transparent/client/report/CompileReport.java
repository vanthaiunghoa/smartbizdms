/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Jan 14, 2004
 *
 */
package nz.co.transparent.client.report;

import dori.jasper.engine.JRException;
import dori.jasper.engine.JasperCompileManager;
import nz.co.transparent.client.util.Configuration;

/**
 * @author John Zoetebier
 * 
 */
public class CompileReport {

	/**
	 * 
	 */
	public CompileReport() {
		super();
	}
	
	public void compile(String reportName) {
		
		String fileSeparator = System.getProperty("file.separator");
		String fileName = Configuration.getProperty("client.dir", "") + fileSeparator + "resource" + fileSeparator + reportName +".xml";
		// Set path for temporary compilation files. This ensures <report_name>.java file is not overriden on folder containing <report_name>.xml
		System.setProperty("jasper.reports.compile.temp", Configuration.getProperty("client.dir", "") + "/temp");
		System.setProperty("jasper.reports.compile.keep.java.file", "true");
		
		try {
			String result = JasperCompileManager.compileReportToFile(fileName);
			System.out.println("result=" + result);
		} catch (JRException je) {
			System.out.println(je.getMessage());
		}
	}

	public static void main(String[] args) {
		
		new CompileReport().compile("CardReport");
	}
}