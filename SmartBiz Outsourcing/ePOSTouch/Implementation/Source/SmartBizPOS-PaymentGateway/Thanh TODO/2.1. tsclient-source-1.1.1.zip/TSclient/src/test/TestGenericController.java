/*
 * Created on Dec 13, 2003
 *
 */
package test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import nz.co.transparent.client.controller.GenericController;
import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.FinderException;
import nz.co.transparent.client.db.UpdaterException;

/**
 * @author johnz
 * 
 */
public class TestGenericController {

	/**
	 * 
	 */
	public TestGenericController() {
		super();
	}
	
	public void existsRecord() {
		
		Map columnMap = null;
		boolean found = false;
		try {
			GenericController controller = GenericController.getInstance();
			String where = "person_id=? and role_id=?";
			Integer personID = new Integer(3);
			Integer roleID = new Integer(2);
			Object[] params = new Object[2];
			params[0] = personID;
			params[1] = roleID;
			found = controller.existsRecord("person_role", where, params);

			if (found) {
				System.out.println("found");
			} else {
				System.out.println("NOT found");
			}

			System.out.println("==> Ready");
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		}
	}

	public void findWhere() {
		
		Map columnMap = null;
		try {
			GenericController controller = GenericController.getInstance();
			columnMap = controller.findWhere("title", "title_code = 'Mrs'");
		} catch (FinderException ce) {
			System.out.println(ce.getMessage());
			return;
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		}

		Set columnSet = columnMap.keySet();
		Iterator mapIterator = columnSet.iterator();
		String columnName = null;
		 while (mapIterator.hasNext()) {
			columnName = (String) mapIterator.next();
			System.out.println(columnName + "=" + columnMap.get(columnName));
		 }
		
		System.out.println("==> Ready");
	}

	public void findAll() {
		
		List recordList = null;
		Map columnMap = null;
		String columnName = null;
		Iterator iterator2 = null;

		try {
			GenericController controller = GenericController.getInstance();
			recordList = controller.findAll("title", "title_code");
			Iterator iterator = recordList.iterator();
			int i = 0;
			while (iterator.hasNext()) {
				System.out.println("===" + i++);
				columnMap = (Map) iterator.next();
				Set keySet = columnMap.keySet();
				iterator2 = keySet.iterator();
				
				while (iterator2.hasNext()) {
					columnName = (String) iterator2.next();
					System.out.println("   " + columnName +"=" + columnMap.get(columnName));
				}
			}
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		}

		System.out.println("==> findAll ready");
	}

	public void insertRecord() {
		
		Map columnMap = new HashMap();
		columnMap.put("title_id", null);	// Force to generate a unique key
		columnMap.put("title_code", "A");
		columnMap.put("title", "Test title for A");
		columnMap.put("date_created", null);
		columnMap.put("date_updated", null);
		columnMap.put("updater_person_id", new Integer(3));
		
		try {
			GenericController controller = GenericController.getInstance();
			controller.insertRecord("title", "title_id", columnMap);
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		}

		System.out.println("==> Ready");
	}

	public void insertRecord2() {
		
		Map columnMap = new HashMap();
		columnMap.put("role_code", "A");
		columnMap.put("role", "Test title for A");
		columnMap.put("date_created", null);
		columnMap.put("date_updated", null);
		columnMap.put("updater_person_id", new Integer(3));
		
		try {
			GenericController controller = GenericController.getInstance();
			controller.insertRecord("role", "role_code", columnMap);
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		}

		System.out.println("==> Ready");
	}

	public void insertMultiple() {
		
		Map clientMap = new HashMap();
		Map contactDetailMap = new HashMap();
		
		clientMap.put("client_id", null);
		clientMap.put("first_name", "joe1");
		clientMap.put("last_name", "blocks");
		clientMap.put("address1", "some address");
		clientMap.put("city", "myCity");
		clientMap.put("title_id", new Integer(1));
		clientMap.put("occupation_id", new Integer(1));
		clientMap.put("insurance_company_id", new Integer(1));
		clientMap.put("updater_person_id", new Integer(1));
		
		try {
			GenericController controller = GenericController.getInstance();
			controller.insertRecord("client", "client_id", clientMap);
			
			Integer clientID = (Integer) clientMap.get("client_id");
			contactDetailMap.put("contact_detail_id", null);
			contactDetailMap.put("client_id", clientID);
			contactDetailMap.put("contact_type_id", new Integer(1));
			contactDetailMap.put("contact_detail", "contact 1");
			controller.insertRecord("contact_detail", "contact_detail_id", contactDetailMap);
			
			contactDetailMap.put("contact_detail_id", null);
			contactDetailMap.put("client_id", clientID);
			contactDetailMap.put("contact_type_id", new Integer(2));
			contactDetailMap.put("contact_detail", "contact 2");
			controller.insertRecord("contact_detail", "contact_detail_id", contactDetailMap);

			// cascade delete
			String[] childTables = {"contact_detail", "payment"};
			//nz.co.transparent.client.controller.insertMultipleRecord("client", "client_id", clientID, childTables);
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		}

		System.out.println("==> Ready");
	}

	public void updateRecord() {
		
		try {
			GenericController controller = GenericController.getInstance();
//			Map columnMap = nz.co.transparent.client.controller.findWhere("title", "title_code='A'");
//			columnMap.put("title", "Title changed 111");
//			nz.co.transparent.client.controller.updateRecord("title", "title_id", columnMap);
			Map columnMap = controller.findWhere("client", "client_id=5");
			//columnMap.put("client_id", new String("5")); // wil not work, must be Integer
			columnMap.put("first_name", "first_name 5");
			controller.updateRecord("client", "client_id", columnMap);
		} catch (FinderException ce) {
			System.out.println("FinderException: " + ce.getMessage());
			return;
		} catch (UpdaterException ce) {
			System.out.println("UpdaterException: " + ce.getMessage());
			return;
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		}

		System.out.println("==> updateRecord ready ");
	}

	public void deleteRecord() {
		
		try {
			GenericController controller = GenericController.getInstance();
			controller.deleteRecord("role", "rol_code='A'");
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		}

		System.out.println("==> deleteRecord ready ");
	}

	public static void main(String[] args) {
		new TestGenericController().existsRecord();
		//new TestGenericController().findWhere();
		//new TestGenericController().findAll();
		//new TestGenericController().insertRecord();
		//new TestGenericController().insertRecord2();
		//new TestGenericController().updateRecord();
		//new TestGenericController().deleteRecord();
		//new TestGenericController().insertMultiple();
	}
}
