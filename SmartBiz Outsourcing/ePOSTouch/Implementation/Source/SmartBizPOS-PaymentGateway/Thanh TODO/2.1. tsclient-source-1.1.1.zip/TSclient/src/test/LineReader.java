/*
 * Created on Oct 29, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import java.io.*;

/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class LineReader {
	
	File file;
	FileInputStream fis;
	Reader reader;

	public LineReader(File fileIn) {
		file = fileIn;
		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException fnfe) {
			throw new RuntimeException(fnfe);
		}
		
		reader = new BufferedReader(new InputStreamReader(fis));
	}
	public StringBuffer nextLine() throws IOException {
		
		StringBuffer buffer = new StringBuffer();
		int intChar = 0;
		String eol = System.getProperty("line.separator");
		String compare;
		char character;
		
		try {
			while (true) {
				intChar = reader.read();
				if (intChar == -1) {	// EOF
					if (buffer.length() > 0) {
						return buffer;
					} else {
						return null;
					} 
				}

				character = (char) intChar;
				compare = String.valueOf(character); 
				if (eol.equals(compare)) {
					break; 
				}

				buffer.append(character); 							
			}
			
			return buffer;		
		} catch (IOException ie) {
			throw new IOException("Error reading file: " + file);
		} 	
	}
}
