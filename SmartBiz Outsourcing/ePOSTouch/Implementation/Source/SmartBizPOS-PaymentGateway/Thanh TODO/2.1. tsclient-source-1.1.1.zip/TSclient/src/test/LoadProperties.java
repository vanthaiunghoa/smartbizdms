/*
 * Created on Oct 25, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import java.io.*;
import java.util.Properties;

/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class LoadProperties {

	public static void main(String[] args) 
		throws Exception {
		
		//System.getProperties().list(System.out);
		new LoadProperties().go();
	}
	
	private void go() 
		throws Exception {
		
		// Subfolder resource mut be in classpath
		Properties projectProperties = new Properties();
		InputStream is  = this.getClass().getResourceAsStream("/project.properties");
		projectProperties.load(is);
		is.close();
		projectProperties.list(System.out);
		
	}
}
