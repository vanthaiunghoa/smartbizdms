/*
 * Created on Nov 14, 2003
 * 
 * To change the template for this generated file go to Window - Preferences -
 * Java - Code Generation - Code and Comments
 */
package test;

import java.sql.*;
import java.util.logging.Logger;

import nz.co.transparent.client.db.PoolingDriverHandler;


/**
 * @author johnz
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class TestMetaData1 {

	Logger log = Logger.getLogger("test");

	private void go() {

		TestMetaData2 metaData2 = new TestMetaData2(); 
		ResultSetMetaData metaData = metaData2.getMetaData();
		//metaData2 = null;	// Ensure there are no links anymore with metaData origin
		
		try {
			for (int i=1; i<=metaData.getColumnCount(); i++) {
				System.out.println("==============================");
				System.out.println(metaData.getColumnName(i) + ": ");
				System.out.println("    ColumnDisplaySize: " + metaData.getColumnDisplaySize(i));
				System.out.println("    ColumnLabel: " + metaData.getColumnLabel(i));
				System.out.println("    ColumnType: " + metaData.getColumnType(i));
				System.out.println("    ColumnTypeName: " + metaData.getColumnTypeName(i));
				System.out.println("    Precision: " + metaData.getPrecision(i));
				System.out.println("    Scale: " + metaData.getScale(i));
				System.out.println("    AutoIncrement: " + metaData.isAutoIncrement(i));
				System.out.println("    Currency: " + metaData.isCurrency(i));
				System.out.println("    Searchable: " + metaData.isSearchable(i));
			}
		} catch (SQLException se) {
			log.warning("SQL error: " + se.getMessage());
		}
			
	}

	public static void main(String args[]) {
		nz.co.transparent.client.db.PoolingDriverHandler dbcPool  =  new PoolingDriverHandler("client");
		new TestMetaData1().go();
		dbcPool.closeConnectionPool();
	}
}
