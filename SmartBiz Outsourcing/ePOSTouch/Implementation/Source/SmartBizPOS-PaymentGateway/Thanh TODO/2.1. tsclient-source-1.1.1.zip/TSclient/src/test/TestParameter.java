/*
 * Created on Jan 23, 2004
 *
 */
package test;

import nz.co.transparent.client.db.DataSourceHandler;
import nz.co.transparent.client.util.Parameter;

/**
 * @author John Zoetebier
 * 
 */
public class TestParameter {

	/**
	 * 
	 */
	public TestParameter() {
		super();
	}

	public static void main(String[] args) {
		
		// Load DataSourceHandler
		DataSourceHandler.loadCredentialsFromConfig();
		System.out.println(Parameter.getParameter("format.shortdate", ""));
		System.out.println(Parameter.getParameter("format.shortdate", ""));
		System.out.println(Parameter.getParameter("format.timestamp", ""));
		System.out.println("Ready");
	}
}
