/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Created on Jan 25, 2004
 *  
 */
package nz.co.transparent.client.util;

import java.util.HashMap;
import java.util.Map;

import nz.co.transparent.client.controller.GenericController;
import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.FinderException;

/**
 * @author John Zoetebier
 *  
 */
public class Updater {

	/**
	 *  
	 */
	private Updater() {
		super();
	}

	public static Map getUpdater(int personID) 
		throws ControllerException {

		try {
			return GenericController.getInstance().findWhere(
				"person",
				"person_id=" + personID);
		} catch (FinderException fe) {
			// Can happen if person has been removed fro system
			Map personMap = new HashMap();
			personMap.put("person_id", new Integer(0));
			personMap.put("user_name", "<unknown>");
			return personMap;
		}
	}
}