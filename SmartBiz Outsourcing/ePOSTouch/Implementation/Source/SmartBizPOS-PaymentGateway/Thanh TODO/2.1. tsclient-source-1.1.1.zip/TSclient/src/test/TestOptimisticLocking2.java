/*
 * Created on Nov 26, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import nz.co.transparent.client.util.Constants;

import nz.co.transparent.client.db.PoolingDriverHandler;

/**
 * @author johnz
 * 
 * Purpose: check optimistic locking
 * Check is based on transaction processing in McKoi
 *
 */
public class TestOptimisticLocking2 {

	/**
	 * 
	 */
	public TestOptimisticLocking2() {
		super();
	}

	private void go() {
		
		PoolingDriverHandler databaseConnectionPool = new PoolingDriverHandler("client");
		Connection conn;
		
		try {
			conn = DriverManager.getConnection(Constants.JDBC_URL);
			// If AutoCommit is true then we are not using a transaction
			// Changes to the database by other clients are immediately visible to this client
			// If AutoCommit is false then we are running in transaction mode
			// Changes to the database by other clients are visible after commit or rollback
			conn.setAutoCommit(false);
		} catch (SQLException se) {
			System.out.println("Cannot get SQL connection");
			return;
		}
		
		ResultSet rset = null;
		Statement stmt = null;
		String sql;
		
		try {
			stmt = conn.createStatement();
			sql = "select DateUpdated from Client";
			sql += " where (ClientID=1);";
			rset = stmt.executeQuery(sql);
			rset.next();
			Date oldDate = rset.getDate("DateUpdated"); 
			System.out.println("Old date=" + oldDate.getTime());
			System.out.println("Start other transaction now");
			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException ie) {
				System.out.println("Sleep interrupted");
			}
			
			System.out.println("Continued after sleep");
			Format formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String date = formatter.format(new Date());
			sql = "update Client";
			sql += " set DateUpdated='" + date + "'";
			sql += " where (ClientID=1);";
			stmt.execute(sql);
			conn.commit();
			
			sql = "select DateUpdated from Client";
			sql += " where (ClientID=1);";
			rset = stmt.executeQuery(sql);
			rset.next();
			Date newDate = rset.getDate("DateUpdated");  
			System.out.println("New date=" + newDate.getTime());

		} catch (SQLException se) {
			System.out.println("SQL failed: " + se.getMessage());
			try {
				conn.rollback();
				System.out.println("Transaction rollback");
			} catch (SQLException se2) {
				System.out.println("Rollback failed: " + se2.getMessage());
			}
		}
		
		try {
			stmt.close();
			conn.close();
		} catch (SQLException se) {
			System.out.println("Close failed: " + se.getMessage());
		}
		
		System.out.println("TestOptimisticLocking ready");

	}
	
	public static void main(String[] args) {
		new TestOptimisticLocking2().go();
	}
}
