/*
 * Created on Oct 23, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package test;

/**
 * @author johnz
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

/*
 * 	To test this program from the command line.
 * 	Go to folder with EmbeddedDatabaseDemo.class
 * 	Ensure file nz.co.transparent.client.db.conf is in the root folder of project
 * 	In shell type: 
 * 	java -cp $MCKOI_HOME/mckoidb.jar:.. test.EmbeddedDatabaseDemo
 */
 
import java.sql.*;

public class ConnectToServer {

	public static void main(String[] args) {

		// Register the Mckoi JDBC Driver
		try {
			Class.forName("com.mckoi.JDBCDriver").newInstance();
		} catch (Exception e) {
			System.out.println(
					"Unable to register the JDBC Driver.\n"
						+ "Make sure the JDBC driver is in the\n"
						+ "classpath.\n");
			System.exit(1);
		}

		// This URL specifies we are connecting with McKoi server on port 9157
		String server = "localhost";
		if (args.length == 1) {
			server = args[0];
		}
		
		String url = "jdbc:mckoi://" + server;

		// The username / password to connect under.
		String username = "admin_user";
		String password = "client00";

		// Make a connection with the local database.
		Connection connection;
		try {
			connection = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			System.out.println(
				"Unable to make a connection to the database.\n"
					+ "The reason: "
					+ e.getMessage());
			System.exit(1);
			return;
		}

		try {

			// .... Use 'connection' to talk to database ....

			// Close the connection when finished,
			connection.close();

		} catch (SQLException e) {
			System.out.println(
				"An error occured\n"
					+ "The SQLException message is: "
					+ e.getMessage());
			return;
		}
		
		System.out.println("Ready testing connection to McKoi server");

	}

}
