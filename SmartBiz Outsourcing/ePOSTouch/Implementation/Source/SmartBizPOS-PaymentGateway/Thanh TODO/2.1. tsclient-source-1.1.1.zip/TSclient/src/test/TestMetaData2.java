/*
 * Created on Nov 14, 2003
 * 
 * To change the template for this generated file go to Window - Preferences -
 * Java - Code Generation - Code and Comments
 */
package test;

import java.sql.*;
import java.util.logging.Logger;

import nz.co.transparent.client.db.PoolingDriverHandler;

import nz.co.transparent.client.util.Constants;

/**
 * @author johnz
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class TestMetaData2 {

	Logger log = Logger.getLogger("test");
	nz.co.transparent.client.db.PoolingDriverHandler dbcPool  =  new PoolingDriverHandler("client");

	public java.sql.ResultSetMetaData getMetaData() {

		Connection conn;
		Statement stmt;
		ResultSet resultSet;
		ResultSetMetaData metaData = null;
		String sql;
		int numRecords = 0;

		try {
			// Get connection from the connection pool
			conn = DriverManager.getConnection(Constants.JDBC_URL);
			stmt = conn.createStatement();
			sql = "select * from Client, ContactDetail, ContactType";
			sql += " where (";
			sql += "	(Client.ClientID=ContactDetail.ClientID)";
			sql += "	and (ContactDetail.ContactTypeID=ContactType.ContactTypeID)";
			sql += "	and (Client.ClientID=1)";
			sql += ")";
			resultSet = stmt.executeQuery(sql);
			metaData = resultSet.getMetaData();
			System.out.println("Before: " + metaData.getColumnCount());

			stmt.close();
			// MetaData not available after close SQL statement
			System.out.println("A1: " + metaData.getColumnCount());
			resultSet.close();
			conn.close(); // Will go back to pool
		} catch (SQLException se) {
			String message = "SQL Exception: " + se.getMessage();
			log.warning(message);
		}

		return metaData;
	}

}
