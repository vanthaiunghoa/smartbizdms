/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * Occupation.java
 * 
 * Created on Januari 3, 2004
 */

package nz.co.transparent.client.gui;
import nz.co.transparent.client.gui.util.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.*;

import nz.co.transparent.client.controller.*;

import nz.co.transparent.client.db.*;

import nz.co.transparent.client.util.*;

/**
 * @author John Zoetebier
 */
public class OccupationForm extends javax.swing.JInternalFrame {

	// Constants
	private static final int FIELD_LENGTH = 14;

	// Private variables
	private Map occupationMap = new HashMap();
	private Map personMap = new HashMap();
	private GenericController genericController =
		GenericController.getInstance();

	private JLabel occupationIDLabel = new JLabel("Occupation ID");
	private JLabel occupationLabel = new JLabel("Occupation");
	private JLabel isDefaultLabel = new JLabel("Is default");
	private JLabel updaterPersonIDLabel = new JLabel("Updater");
	private JLabel dateCreatedLabel = new JLabel("Date created");
	private JLabel dateUpdatedLabel = new JLabel("Date updated");

	private DateFormat timeStampFormat =
		new SimpleDateFormat(Parameter.getParameter("format.timestamp", Constants.FORMAT_TIMESTAMP));

	private JTextField occupationIDField = new JTextField();
	private JTextField occupationField = new JTextField();
	private JCheckBox isDefaultField = new JCheckBox();
	private JTextField updaterPersonIDField = new JTextField();
	private JFormattedTextField dateCreatedField =
		new JFormattedTextField(timeStampFormat);
	private JFormattedTextField dateUpdatedField =
		new JFormattedTextField(timeStampFormat);

	private JPanel contentPanel = new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();

	private JButton newButton = new JButton();
	private JButton saveButton = new JButton();
	private JButton reloadButton = new JButton();
	private JButton deleteButton = new JButton();

	private JToolBar toolbarMain = new JToolBar();

	/** Creates new form */
	public OccupationForm() {

		setName("Occupation form");
		setTitle("Occupation form");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));

		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
		setContentPane(contentPanel);
		addInternalFrameListener(
			new InternalFrameOpenedAdapter(this, occupationField));

		toolbarMain.setBorder(BorderFactory.createEtchedBorder());
		toolbarMain.setFloatable(false);

		newButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/New24.gif")));
		newButton.setMnemonic(KeyEvent.VK_N);
		newButton.setToolTipText("New occupation.");
		newButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				newButton_actionPerformed();
			}
		});

		toolbarMain.add(newButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		saveButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Save24.gif")));
		saveButton.setMnemonic(KeyEvent.VK_S);
		saveButton.setToolTipText("Save occupation.");
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				saveButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(saveButton);

		reloadButton.setIcon(
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Refresh24.gif")));
		reloadButton.setMnemonic(KeyEvent.VK_R);
		reloadButton.setToolTipText("Refresh occupation.");
		reloadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				reloadButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(reloadButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		deleteButton.setIcon(
			new javax.swing.ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Delete24.gif")));
		deleteButton.setMnemonic(KeyEvent.VK_D);
		deleteButton.setToolTipText("Delete occupation.");
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				deleteButton_actionPerformed(evt);
			}
		});

		toolbarMain.add(deleteButton);
		toolbarMain.add(Box.createRigidArea(new Dimension(5, 0)));

		// make buttons left aligned
		toolbarMain.add(Box.createHorizontalGlue());
		contentPanel.add(toolbarMain);

		//============================================
		// 
		// Start fields
		//
		//============================================

		// Dialog panel
		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setFocusTraversalPolicy(
			new InputOrderFocusTrafersalPolicy());
		dialogPanel.setFocusCycleRoot(true);

		// Dialog fields
		dialogPanel.add(occupationIDLabel);
		Dimension fieldDimension =
			new Dimension(200, occupationIDLabel.getPreferredSize().height);
		occupationIDField.setToolTipText("Generated by system.");
		occupationIDField.setEditable(false);
		dialogPanel.add(occupationIDField);

		dialogPanel.add(occupationLabel);
		occupationField.setColumns(FIELD_LENGTH);
		dialogPanel.add(occupationField);

		dialogPanel.add(isDefaultLabel);
		dialogPanel.add(isDefaultField);

		dialogPanel.add(updaterPersonIDLabel);
		updaterPersonIDField.setEditable(false);
		dialogPanel.add(updaterPersonIDField);

		dialogPanel.add(dateCreatedLabel);
		dateCreatedField.setEditable(false);
		dialogPanel.add(dateCreatedField);

		dialogPanel.add(dateUpdatedLabel);
		dateUpdatedField.setEditable(false);
		dialogPanel.add(dateUpdatedField);

		// Create middle panel to layout dialog panel
		middlePanel.setLayout(new BorderLayout());
		middlePanel.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));

		// Add dialogPanel to content panel
		middlePanel.add(dialogPanel, BorderLayout.WEST);
		contentPanel.add(middlePanel);
		pack();
	}

	/**
	 * Populate form using PK occupationID
	 * 
	 * @param occupationID
	 *                Primary key
	 */
	public void populateForm(int occupationID) {

		String msg = null;
		try {
			msg = "OccupationForm: Cannot find occupation: " + occupationID;
			occupationMap =
				genericController.findWhere(
					"occupation",
					"occupation_id=" + occupationID);
			Integer personID = (Integer) occupationMap.get("updater_person_id");
			personMap = Updater.getUpdater(personID.intValue());
		} catch (ControllerException ce) {
			Messager.exception(this, msg + "\n" + ce.getMessage());
			return;
		} catch (FinderException fe) {
			Messager.exception(this, msg + "\n" + fe.getMessage());
			return;
		}

		GenericUtils.resetInputFields(dialogPanel);
		occupationIDField.setText(
			String.valueOf(occupationMap.get("occupation_id").toString()));
		occupationField.setText(occupationMap.get("occupation").toString());
		isDefaultField.setSelected(
			((Boolean) (occupationMap.get("is_default"))).booleanValue());
		updaterPersonIDField.setText(personMap.get("user_name").toString());
		dateCreatedField.setValue(occupationMap.get("date_created"));
		dateUpdatedField.setValue(occupationMap.get("date_updated"));
	}

	/**
	 * Populate new form
	 *  
	 */
	public void populateNewForm() {

		newButton_actionPerformed();
	}

	private void deleteButton_actionPerformed(ActionEvent evt) {
		String msg = null;

		if (occupationMap.get("occupation_id") == null) {
			msg = "New occupation cannot be deleted";
			Messager.information(this, msg);
			return;
		}

		msg = "Continue to delete occupation ?";
		if (Messager.question(this, msg) != JOptionPane.YES_OPTION) {
			return;
		}

		try {
			Integer occupationID = (Integer) occupationMap.get("occupation_id");
			genericController.deleteRecord(
				"occupation",
				"occupation_id=" + occupationID.intValue());
			newButton_actionPerformed();
		} catch (ControllerException ce) {
			Messager.exception(
				this,
				"OccupationForm: Error deleting occupation.\n"
					+ ce.getMessage());
			return;
		}
	}

	private void newButton_actionPerformed() {

		occupationMap.put("occupation_id", null);
		personMap = LoginController.getPerson();

		GenericUtils.resetInputFields(dialogPanel);
		Map occupationMap = null;

		occupationIDField.setText(null);
		occupationField.setText(null);
		isDefaultField.setText(null);
		updaterPersonIDField.setText(
			(String) LoginController.getPerson().get("user_name"));
		dateCreatedField.setValue(new Date());
		dateUpdatedField.setValue(new Date());
	}

	private void saveButton_actionPerformed(ActionEvent evt) {

		if (!validateForm()) {
			return;
		}

		// Store fields in occupationMap
		// Convert display values to foreign keys before passing occupationMap
		// to nz.co.transparent.client.controller
		occupationMap.put("occupation_id", occupationMap.get("occupation_id"));
		occupationMap.put("occupation", occupationField.getText());
		occupationMap.put(
			"is_default",
			Boolean.valueOf(isDefaultField.isSelected()));
		occupationMap.put(
			"updater_person_id",
			LoginController.getPerson().get("person_id"));
		occupationMap.put("date_created", dateCreatedField.getValue());
		occupationMap.put("date_updated", dateUpdatedField.getValue());

		try {
			if (occupationIDField.getText().equals("")) {
				occupationMap.put("occupation_id", null); // Generate
				// key
				genericController.insertRecord(
					"occupation",
					"occupation_id",
					occupationMap);
			} else {
				// Cast to Integer, otherwise record lookup and update will
				// fail
				occupationMap.put(
					"occupation_id",
					Integer.valueOf(occupationIDField.getText()));
				genericController.updateRecord(
					"occupation",
					"occupation_id",
					occupationMap);
			}

			Integer occupationID = (Integer) occupationMap.get("occupation_id");
			// If is_default has been set, switch off any other default
			genericController.switchOffOtherDefault(
				"occupation",
				"occupation_id",
				occupationID,
				isDefaultField.isSelected());
			populateForm(occupationID.intValue());
		} catch (UpdaterException ue) {
			String message = "Update warning !\n";
			message
				+= "Changes have been made by an other person or process.\n";
			message += "Form will be refreshed with latest values";
			Messager.warning(this, message);
			this.populateForm(
				Integer.parseInt(
					occupationMap.get("occupation_id").toString()));
		} catch (ControllerException ce) {
			Messager.exception(this, "Error: " + ce.getMessage());
		}
	}

	private boolean validateForm() {

		boolean validationOk = true;
		GenericUtils.resetInputFields(dialogPanel);

		if (occupationField.getText().equals("")) {
			occupationField.setBackground(Color.YELLOW);
			occupationField.setToolTipText("Please enter occupation");
			occupationField.requestFocus();
			validationOk = false;
		}

		return validationOk;
	}

	private void reloadButton_actionPerformed(ActionEvent evt) {
		Integer occupationID = (Integer) occupationMap.get("occupation_id");

		if (occupationID == null) {
			this.newButton_actionPerformed();
		} else {
			this.populateForm(occupationID.intValue());
		}
	}
}