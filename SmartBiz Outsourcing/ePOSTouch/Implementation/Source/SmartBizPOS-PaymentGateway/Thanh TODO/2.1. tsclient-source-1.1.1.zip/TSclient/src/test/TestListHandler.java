/*
 * Created on Dec 17, 2003
 *
 */
package test;

import nz.co.transparent.client.gui.util.GenericUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


/**
 * @author johnz
 * 
 */
public class TestListHandler {

	/**
	 * 
	 */
	public TestListHandler() {
		super();
	}

	public void go() {
		
		ArrayList list = new ArrayList();
		Map recordMap = new HashMap();
		
		for (int i=0; i<5; i++) {
			recordMap = new HashMap();
			recordMap.put("key", new Integer(i));
			recordMap.put("a_field", "A" + i);
			recordMap.put("search_field", "search for " + i);
			list.add(recordMap);
		}
		
		Object value = GenericUtils.getKey(list, "key", "search_field", "search for 4");
		System.out.println("value=" + value);
	}
	
	public static void main(String[] args) {
		new TestListHandler().go();
	}
}
