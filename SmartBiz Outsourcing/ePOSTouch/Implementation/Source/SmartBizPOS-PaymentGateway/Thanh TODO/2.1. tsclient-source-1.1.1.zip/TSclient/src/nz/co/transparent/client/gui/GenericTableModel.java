/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 package nz.co.transparent.client.gui;

import java.text.NumberFormat;
import java.util.*;
import javax.swing.table.*;

/**
 * This is a generic table model that can be used by any GUI
 * Pass columnMap with mapping of ColumnName => ColumnLabel
 * 
 * @author John Zoetebier
 * @version 1.0
 */
public class GenericTableModel extends AbstractTableModel {

	/**
	 * <code>ArrayList</code> with column properties
	 * Each entry is a <code>Map</code> with properties of a column
	 */
	private List columnMapList = new ArrayList (5);
	/**
	 * <code>ArrayList</code> with one row for each record to be displayed
	 * The columns to display are derived from column properties
	 */
	private List recordList = new ArrayList (5);

	/**
	 * Maps field names to column names
	 */
//	private String [] columnNames;
//	private String [] columnHeaders;
	private NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.getDefault());

	/**
	 * Controller is responsible to set data 
	 * GUI is responsible to set column map before rendering the JTable
	 */
	public GenericTableModel(List columnMapList) {
		this.columnMapList = columnMapList;
	}
    
    /**
     * Returns the column count of the table.
     *
     * @return An integer indicating the number or columns in the table.
     */
    public int getColumnCount() {
        return this.columnMapList.size();
    }

	/**
	 * Returns the name of a column header at a given column index.
	 *
	 * @param column The specified column index.
	 * @return A String containing the column name.
	 */
	public String getColumnName (int column) {
		return (String) ((Map) columnMapList.get(column)).get("columnHeader");
	}

    /**
     * Returns the number of rows in the table.
     *
     * @return An integer indicating the number of rows in the table.
     */
    public int getRowCount() {
        return this.recordList.size();
    }

    /**
     * Gets a value from a specified index in the table.
     *
     * @param row An integer representing the row index.
     * @param column An integer representing the column index.
     * @return The object located at the specified row and column.
     */
    public Object getValueAt(int row, int column) {
		Map recordMap = (Map) this.recordList.get(row);
		Map columnMap = (Map) this.columnMapList.get(column);
        // Do some markup if required
		String columnName = (String) getColumnProperty(column, "columnName");
		Object returnValue = recordMap.get(columnName);

		if (returnValue != null && columnMap.get("isCurrency") != null && columnMap.get("isCurrency").equals(Boolean.TRUE)) {
			returnValue = currencyFormat.format(returnValue);
        }
        
		return returnValue;
    }

    /**
     * Sets the cell value at a specified index.
     *
     * @param obj The object that is placed in the table cell.
     * @param row The row index.
     * @param column The column index.
     */
    public void setValueAt(Object obj, int row, int column) {
        Map recordMap = (Map) this.recordList.get(row);
		recordMap.put(getColumnProperty(column, "columnName"), obj);
    }

    /**
     * Given a row and column index, indicates if a table cell can be edited.
     *
     * @param row Specified row index.
     * @param column Specified column index.
     * @return A boolean indicating if a cell is editable.
     */
    public boolean isCellEditable (int row, int column) {
        return false;
    }


    /**
     * Set MapList
     * 
     * @param mapList List with record map
     */
	public void setMapList(List mapList) {

		this.recordList = mapList;
	}
    
    /**
     * Add field values of recordMap to array recordList
     * Prefered method is <code>setMapList</code> 
     * @param recordMap Map with fielname to value mapping
     */
    public void addRecordMap (Map recordMap) {

		this.recordList.add(recordMap);
	}
    
	/**
	 * Returns the property if column referenced by column index
	 *
	 * @param column The specified column index.
	 * @return Object property
	 */
	public Object getColumnProperty (int column, String propertyName) {
		return ((Map) columnMapList.get(column)).get(propertyName);
	}


}