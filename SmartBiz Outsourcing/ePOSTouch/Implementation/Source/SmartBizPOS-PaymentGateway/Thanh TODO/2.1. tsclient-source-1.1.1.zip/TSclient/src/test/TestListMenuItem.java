/*
 * Created on Dec 5, 2003
 */
package test;

import nz.co.transparent.client.gui.ListMenuItem;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Vector;

import javax.swing.*;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;

/**
 * @author johnz
 *
 */
public class TestListMenuItem extends JFrame {

	static JMenuBar menuBar  = new JMenuBar();
	static JMenu fileMenu = new JMenu();
	static JMenuItem fileMenuItem1 = new JMenuItem();
	static JMenuItem fileMenuItem2 = new JMenuItem();
	static JMenu actionMenu = new JMenu();
	static JMenuItem actionMenuItem1 = new JMenuItem("Action item 1");
	static JMenuItem actionMenuItem2 = new JMenuItem("Action item 2");
	static JMenuItem actionMenuItem3 = new JMenuItem("Action item 3");
	static JMenu windowMenu = new JMenu();
	static JMenu helpMenu = new JMenu("Help");
	static JMenuItem helpContentMenuItem = new JMenuItem("Content");
	static JMenuItem helpAboutMenuItem = new JMenuItem("About");
	static ListMenuItem windowListMenuItem = new ListMenuItem();
	
	static JDesktopPane desktopPane = new JDesktopPane();
	static JInternalFrame internalFrame1 = new JInternalFrame();
	static JInternalFrame internalFrame2 = new JInternalFrame();
	
	/**
	 * 
	 */
	public TestListMenuItem() {
		super();
	}
	
	public void go() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		addWindowListener(new WindowAdapter() {
			public void windowOpened(WindowEvent e) {
				setExtendedState(Frame.MAXIMIZED_BOTH);
			}
		});
		
		Container content = getContentPane();
		content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
		getContentPane().add(desktopPane, java.awt.BorderLayout.CENTER);
		fileMenu.setText("File");
		fileMenu.setMnemonic('F');
		fileMenuItem1.setText("File item 1");
		fileMenuItem2.setText("File item 2");
		fileMenu.add(fileMenuItem1);
		fileMenu.add(fileMenuItem2);
		menuBar.add(fileMenu);

		actionMenu.setText("Action");
		actionMenu.setMnemonic('A');
		actionMenu.add(actionMenuItem1);
		actionMenu.add(actionMenuItem2);
		actionMenu.add(actionMenuItem3);
		menuBar.add(actionMenu);

		windowMenu.setText("Window");
		windowMenu.setMnemonic('W');
		
		windowListMenuItem.setPreviousMenu(actionMenu);
		windowListMenuItem.setNextMenu(helpMenu);
		windowMenu.add(windowListMenuItem);
		menuBar.add(windowMenu);

		helpMenu.setMnemonic('H');
		helpMenu.add(helpContentMenuItem);
		helpMenu.add(helpAboutMenuItem);
		menuBar.add(helpMenu);
		setJMenuBar(menuBar);

		internalFrame1.setName("InternalFrame 1");
		internalFrame1.setTitle("InternalFrame 1");
		internalFrame1.setClosable(true);
		internalFrame1.setResizable(true);
		
		internalFrame2.setName("InternalFrame 2");
		internalFrame2.setTitle("InternalFrame 2");
		internalFrame2.setClosable(true);
		internalFrame2.setResizable(true);
		internalFrame2.setLocation(internalFrame1.getWidth(), 0);

		JButton testButton1 = new JButton("Test 1");
		testButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final JInternalFrame internalFrame2 = new JInternalFrame("InternalFrame 2");
				internalFrame2.setName("InternalFrame 2");
				internalFrame2.setClosable(true);
				internalFrame2.setSize(300,200);
				Dimension screenDimension = Toolkit.getDefaultToolkit().getScreenSize();
				int x = (int) (Math.random() * screenDimension.width) - internalFrame2.getWidth();
				x = Math.max(x,internalFrame1.getWidth());
				int y = (int) (Math.random() * screenDimension.height)  - internalFrame2.getHeight();
				y = Math.max(y,internalFrame1.getHeight());
				internalFrame2.setLocation(x,y);
				internalFrame2.addInternalFrameListener(new InternalFrameAdapter() {
					public void internalFrameClosed(InternalFrameEvent e) {
						removeInternalFrame(internalFrame2);
					}
				});
				openInternalFrame(internalFrame2);
			}
		});
		
		internalFrame1.getContentPane().add(testButton1);
		internalFrame1.setSize(400,200);
		openInternalFrame(internalFrame1);

		setSize(new Dimension(500,400));
		pack();
		show();
	}
	    
	/**
	 * Each internal frame is opened by calling this static method 
	 * @param internalFrame
	 */
	public static void openInternalFrame(JInternalFrame internalFrame) {
		
		// Add to window menu list
		StringBuffer internalFrameName = new StringBuffer();
		if (internalFrame.getName() == null) {
			internalFrameName = new StringBuffer("<Unknown>");
		} else {
			internalFrameName = new StringBuffer(internalFrame.getName());
		}

		String internalFrameNameSave = new String(internalFrameName);
		Vector nameVector = windowListMenuItem.getInternalFrameNameList();
		int occurences = 0;

		while (true) {
			if (!nameVector.contains(internalFrameName.toString())) {
				break;
			}
			
			occurences++;
			internalFrameName.setLength(0);
			internalFrameName.append(internalFrameNameSave + " [" + occurences + "]");
		}
		
		internalFrame.setName(internalFrameName.toString());
		internalFrame.setTitle(internalFrameName.toString());
		windowListMenuItem.addInternalFrame(internalFrame);
		
		// Show frame
		desktopPane.add(internalFrame);
		internalFrame.show();
		try {
			//internalFrame.setMaximum(true);
			internalFrame.setSelected(true);
		} catch(java.beans.PropertyVetoException pve) {
			System.out.println(pve.getMessage());
		}
	}

	public static void removeInternalFrame(JInternalFrame internalFrame) {
		
		windowListMenuItem.removeInternalFrame(internalFrame);
	}
	
	public static void main(String[] args) {
		new TestListMenuItem().go();
	}
	
}
