/*
 * Created on Dec 13, 2003
 *
 */
package test;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import nz.co.transparent.client.controller.GenericController;
import nz.co.transparent.client.db.ControllerException;

/**
 * @author johnz
 * 
 */
public class TestDbUtils4 {

	/**
	 * 
	 */
	public TestDbUtils4() {
		super();
	}
	
	public void go() {
		
		List titleList = null;
		try {
			GenericController titleController = GenericController.getInstance();
			titleList = titleController.findAll("title", "title_code");
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		}

		Map titleMap = null;
		Iterator iterator = titleList.iterator();
		Iterator mapIterator = null;
		Set columnSet = null;
		String columnName = null;
		while (iterator.hasNext()) {
			titleMap = (Map) iterator.next();
			columnSet = titleMap.keySet();
			mapIterator = columnSet.iterator();
			 while (mapIterator.hasNext()) {
				columnName = (String) mapIterator.next();
			 	System.out.println(columnName + "=" + titleMap.get(columnName));
			 }
		}
		
		System.out.println("==> Ready");
	}

	public static void main(String[] args) {
		new TestDbUtils4().go();
	}
}
