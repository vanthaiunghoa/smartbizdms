/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * TitleSearch.java
 *
 * Created on Januari 2, 2004
 */

package nz.co.transparent.client.gui;

import nz.co.transparent.client.gui.util.DialogLayout;

import java.awt.Dimension;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import javax.swing.*;
import nz.co.transparent.client.gui.util.InternalFrameOpenedAdapter;

/**
 * 
 * @author John Zoetebier
 *
 */
public class TitleSearchForm extends javax.swing.JInternalFrame {
    
	private static final int FIELD_LENGTH =20; 
	
	private Logger log = Logger.getLogger("nz.co.transparent.client.gui");
	private JLabel titleCodeLabel = new JLabel("Title code:");
	private JLabel titleLabel = new JLabel("Title:");
	private JPanel contentPane = new JPanel();
	private JPanel middlePanel = new JPanel();
	private JPanel dialogPanel = new JPanel();
	private JTextField titleCodeField = new JTextField();
	private JTextField titleField = new JTextField();
	private JButton titleSearchButton = new JButton();
	private JToolBar mainToolBar = new JToolBar();
	private TitleTableForm titleTableForm;
	private Map searchMap;
	// End of variables declaration
    
	/** Creates new form TitleSearch */
	public TitleSearchForm() {
		setName("Title search");
		setTitle("Title search");
		setClosable(true);
		setMaximizable(true);
		setResizable(true);
		setPreferredSize(new java.awt.Dimension(600, 500));
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		setContentPane(contentPane);
		try {
			setSelected(true);
		} catch (java.beans.PropertyVetoException e1) {
			e1.printStackTrace();
		}
		//setVisible(true);
		addInternalFrameListener(new InternalFrameOpenedAdapter(this, titleCodeField));

		titleSearchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toolbarButtonGraphics/general/Find24.gif")));
		titleSearchButton.setMnemonic(KeyEvent.VK_E);
		titleSearchButton.setToolTipText("Enter one or more of the search fields. Then click me.");
		titleSearchButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent evt) {
				titleSearchButton_actionPerformed();
			 }
		});
		
		mainToolBar.setBorder(BorderFactory.createEtchedBorder());
		mainToolBar.setFloatable(false);
		mainToolBar.add(Box.createRigidArea(new Dimension(5,0)));
		mainToolBar.add(titleSearchButton);

		mainToolBar.add(Box.createHorizontalGlue());	// make buttons left aligned
		contentPane.add(mainToolBar);

		dialogPanel.setLayout(new DialogLayout());
		dialogPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));

		dialogPanel.add(titleCodeLabel);
		titleCodeField.setColumns(FIELD_LENGTH);
		titleCodeField.setText("");
		titleCodeField.setToolTipText("Title code or part of it.");
		titleCodeField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					titleSearchButton.doClick();
				}
			}
		});
		dialogPanel.add(titleCodeField);

		dialogPanel.add(titleLabel);
		titleField.setText("");
		titleField.setColumns(FIELD_LENGTH);
		titleField.setToolTipText("title or part of it.");
		titleField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					titleSearchButton.doClick();
				}
			}
		});
		dialogPanel.add(titleField);

		middlePanel.setLayout(new BoxLayout(middlePanel, BoxLayout.X_AXIS));
		middlePanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(20, 5, 20, 5)));
		middlePanel.add(dialogPanel);
		middlePanel.add(Box.createHorizontalStrut(700));

		contentPane.add(middlePanel);

		//===========================================
		// Create title table form
		//===========================================
		titleTableForm = new TitleTableForm();
		contentPane.add(titleTableForm);
		
		//===========================================
		// Pack
		//===========================================
		pack();
	}

	private void formInternalFrameOpened(javax.swing.event.InternalFrameEvent evt) {

		try {
			this.setMaximum(true);
		} catch (java.beans.PropertyVetoException pve) {
			log.warning(pve.getMessage());
		}
	}
	
	private void titleSearchButton_actionPerformed() {
		searchMap = new HashMap();
		searchMap.put("title_code", titleCodeField.getText());
		searchMap.put("title", titleField.getText());
		titleTableForm.updateTable(searchMap);
	}
}