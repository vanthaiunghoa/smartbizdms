/*
 * Created on Jan 26, 2004
 *  
 */
package test;

import nz.co.transparent.client.gui.util.ChangePasswordDialog;

/**
 * @author John Zoetebier
 *  
 */
public class TestChangePasswordDialog {

	/**
	 *  
	 */
	public TestChangePasswordDialog() {
		super();
	}

	public static void main(String[] args) {

		ChangePasswordDialog p = new ChangePasswordDialog(null, "Test");
		System.out.println("Return: " + p.showDialog());
		p = null;
		System.exit(0);
	}
}
