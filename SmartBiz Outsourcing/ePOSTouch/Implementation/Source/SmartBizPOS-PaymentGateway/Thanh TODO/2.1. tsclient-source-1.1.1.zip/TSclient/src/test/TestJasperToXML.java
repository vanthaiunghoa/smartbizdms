/*
 * Created on Jan 20, 2004
 *  
 */
package test;

import nz.co.transparent.client.util.Configuration;

/**
 * @author John Zoetebier
 *  
 */
public class TestJasperToXML {
	public static void main(java.lang.String[] args) {
		
		String jasperFileName = Configuration.getProperty("client.dir", "") + "/resource/EnvelopReport.jasper";
		String xmlFileName = Configuration.getProperty("client.dir", "") + "/resource/EnvelopReport.xml";
		
		try {
			dori.jasper.engine.JasperCompileManager.writeReportToXmlFile(
				jasperFileName,
				xmlFileName);
			System.out.println("Ready");
		} catch (Exception e) {
			System.out.println("Exception" + e);
		} //end catch
	} //end main
}