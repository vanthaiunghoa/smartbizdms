/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 /*
 * MainFrame.java
 * 
 * Created on November 5, 2003, 4:54 PM
 */

package nz.co.transparent.client.gui;

import nz.co.transparent.client.gui.util.ChangePasswordDialog;
import nz.co.transparent.client.gui.util.PasswordOnlyDialog;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.UIManager;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import nz.co.transparent.client.util.Configuration;
import nz.co.transparent.client.util.Constants;
import nz.co.transparent.client.util.Messager;

import nz.co.transparent.client.controller.LoginController;
import nz.co.transparent.client.controller.SystemDBController;

import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.DataSourceHandler;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.*;

/**
 * @author johnz
 */
public final class MainFrame extends JFrame{

	// Static fields
	static MainFrame instance;
	static JDesktopPane desktopPane = new JDesktopPane();
	static Map internalFrameMap = new LinkedHashMap(3);
	static JMenuBar menuBar = new JMenuBar();
	static JMenu fileMenu = new JMenu();
	static JMenuItem exitFileMenuItem = new JMenuItem();
	static JMenuItem closeFileMenuItem = new JMenuItem();

	static JMenu actionMenu = new JMenu();
	static JMenuItem clientActionMenuItem = new JMenuItem();
	static JMenuItem personActionMenuItem = new JMenuItem();
	static JMenuItem contactTypeActionMenuItem = new JMenuItem();
	static JMenuItem countryActionMenuItem = new JMenuItem();
	static JMenuItem insuranceCompanyActionMenuItem = new JMenuItem();
	static JMenuItem occupationActionMenuItem = new JMenuItem();
	static JMenuItem parameterActionMenuItem = new JMenuItem();
	static JMenuItem roleActionMenuItem = new JMenuItem();
	static JMenuItem tenderActionMenuItem = new JMenuItem();
	static JMenuItem titleActionMenuItem = new JMenuItem();
	static JMenuItem changePasswordActionMenuItem = new JMenuItem();
	static JMenuItem preferencesActionMenuItem = new JMenuItem();
	
	static JMenu windowMenu = new JMenu();
	static GridMenu windowGridMenu = new GridMenu(desktopPane, windowMenu);

	static JMenu helpMenu = new JMenu();
	static JMenuItem aboutHelpMenuItem = new JMenuItem();
//	static JMenuItem contentsHelpMenuItem = new JMenuItem();
	static Logger log = Logger.getLogger("nz.co.transparent.client.gui");

	/** Creates new form MainFrame */
	private MainFrame() {
	}

	/**
	 * Singleton constructor
	 * 
	 * @return Single instance of MainFrame
	 */
	public static MainFrame getInstance() {
		if (instance == null) {
			instance = new MainFrame();
			return instance;
		} else {
			return instance;
		}
	}

	/**
	 * This method is called from within the constructor to initialize the
	 * form.
	 */
	private void initComponents() {

		setTitle("TS Client " + Constants.TS_CLIENT_VERSION + ": mode " + Configuration.getProperty("server.mode", "<unknown>"));
		setName("mainFrame");
		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent evt) {
				exitForm(evt);
			}
			public void windowOpened(java.awt.event.WindowEvent evt) {
				formWindowOpened(evt);
			}
		});

		getContentPane().add(
			desktopPane,
			java.awt.BorderLayout.CENTER);

		fileMenu.setMnemonic('F');
		fileMenu.setText("File");
		closeFileMenuItem.setText("Close all windows");
		closeFileMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				JInternalFrame [] internalFrames = desktopPane.getAllFrames();
				for (int i=0; i<internalFrames.length; i++) {
					internalFrames[i].dispose();
				}
			}
		});
		fileMenu.add(closeFileMenuItem);

		exitFileMenuItem.setText("Exit");
		exitFileMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				exitFileMenuItemActionPerformed(evt);
			}
		});

		fileMenu.add(exitFileMenuItem);

		menuBar.add(fileMenu);

		actionMenu.setMnemonic('A');
		actionMenu.setText("Action");

		clientActionMenuItem.setMnemonic('C');
		clientActionMenuItem.setText("Client");
		clientActionMenuItem.setToolTipText("Open form client");
		clientActionMenuItem
			.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				openFrame(new ClientSearchForm());
			}
		});

		actionMenu.add(clientActionMenuItem);

		personActionMenuItem.setMnemonic('P');
		personActionMenuItem.setText("Person");
		personActionMenuItem.setToolTipText("Open form person");
		personActionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				openFrame(new PersonSearchForm());
			}
		});

		if (!LoginController.hasRole("admin")) {
			personActionMenuItem.setEnabled(false);
		}
				
		actionMenu.add(personActionMenuItem);
		actionMenu.addSeparator();

		contactTypeActionMenuItem.setMnemonic('N');
		contactTypeActionMenuItem.setText("Contact type");
		contactTypeActionMenuItem.setToolTipText("Open form contact type");
		contactTypeActionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				openFrame(new ContactTypeSearchForm());
			}
		});

//		if (!LoginController.hasRole("operator")) {
//			contactTypeActionMenuItem.setEnabled(false);
//		}
				
		actionMenu.add(contactTypeActionMenuItem);

		countryActionMenuItem.setMnemonic('C');
		countryActionMenuItem.setText("Country");
		countryActionMenuItem.setToolTipText("Open form country");
		countryActionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				openFrame(new CountrySearchForm());
			}
		});

//		if (!LoginController.hasRole("operator")) {
//			countryActionMenuItem.setEnabled(false);
//		}
				
		actionMenu.add(countryActionMenuItem);

		insuranceCompanyActionMenuItem.setMnemonic('I');
		insuranceCompanyActionMenuItem.setText("Insurance Company");
		insuranceCompanyActionMenuItem.setToolTipText("Open form Insurance Company");
		insuranceCompanyActionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				openFrame(new InsuranceCompanySearchForm());
			}
		});

//		if (!LoginController.hasRole("operator")) {
//			insuranceCompanyActionMenuItem.setEnabled(false);
//		}
				
		actionMenu.add(insuranceCompanyActionMenuItem);

		occupationActionMenuItem.setMnemonic('O');
		occupationActionMenuItem.setText("Occupation");
		occupationActionMenuItem.setToolTipText("Open form occupation");
		occupationActionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				openFrame(new OccupationSearchForm());
			}
		});

//		if (!LoginController.hasRole("operator")) {
//			occupationActionMenuItem.setEnabled(false);
//		}
				
		actionMenu.add(occupationActionMenuItem);

		parameterActionMenuItem.setMnemonic('P');
		parameterActionMenuItem.setText("Parameter");
		parameterActionMenuItem.setToolTipText("Open form parameter");
		parameterActionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				openFrame(new ParameterSearchForm());
			}
		});

//		if (!LoginController.hasRole("operator")) {
//			parameterActionMenuItem.setEnabled(false);
//		}
				
		actionMenu.add(parameterActionMenuItem);

		roleActionMenuItem.setMnemonic('R');
		roleActionMenuItem.setText("Role");
		roleActionMenuItem.setToolTipText("Open form role");
		roleActionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				openFrame(new RoleSearchForm());
			}
		});

//		if (!LoginController.hasRole("operator")) {
//			roleActionMenuItem.setEnabled(false);
//		}
				
		actionMenu.add(roleActionMenuItem);

		tenderActionMenuItem.setMnemonic('T');
		tenderActionMenuItem.setText("Tender");
		tenderActionMenuItem.setToolTipText("Open form tender");
		tenderActionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				openFrame(new TenderSearchForm());
			}
		});

//		if (!LoginController.hasRole("operator")) {
//			tenderActionMenuItem.setEnabled(false);
//		}
		
		actionMenu.add(tenderActionMenuItem);

		titleActionMenuItem.setMnemonic('I');
		titleActionMenuItem.setText("Title");
		titleActionMenuItem.setToolTipText("Open form title");
		titleActionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				openFrame(new TitleSearchForm());
			}
		});

//		if (!LoginController.hasRole("operator")) {
//			titleActionMenuItem.setEnabled(false);
//		}
		
		actionMenu.add(titleActionMenuItem);

		actionMenu.addSeparator();

		changePasswordActionMenuItem.setMnemonic('C');
		changePasswordActionMenuItem.setText("Change password");
		changePasswordActionMenuItem.setToolTipText("Open form change password");
		changePasswordActionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				changePasswordActionMenuItem_actionPerformed(evt);
			}
		});

//		if (!LoginController.hasRole("operator")) {
//			changePasswordActionMenuItem.setEnabled(false);
//		}
		
		actionMenu.add(changePasswordActionMenuItem);

		preferencesActionMenuItem.setMnemonic('P');
		preferencesActionMenuItem.setText("Preferences");
		preferencesActionMenuItem.setToolTipText("Open form preferences");
		preferencesActionMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				PreferencesForm preferencesForm = new PreferencesForm(); 
				preferencesForm.populateForm();
				openFrame(preferencesForm);
			}
		});

//		if (!LoginController.hasRole("operator")) {
//			preferencesActionMenuItem.setEnabled(false);
//		}
		
		actionMenu.add(preferencesActionMenuItem);

		menuBar.add(actionMenu);

		windowMenu.setMnemonic('W');
		windowMenu.setText("Window");
		windowMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
				// ignore
			}

			public void menuDeselected(MenuEvent e) {
				// ignore
			}

			public void menuSelected(MenuEvent e) {
				windowGridMenu.refreshMenuItems();
			}
		});
		
		menuBar.add(windowMenu);

		helpMenu.setMnemonic('H');
		helpMenu.setText("Help");
//		contentsHelpMenuItem.setText("Contents");
//		helpMenu.add(contentsHelpMenuItem);

		aboutHelpMenuItem.setText("About");
		aboutHelpMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				aboutHelpMenuItem_actionPerformed();
			}
		});
		helpMenu.add(aboutHelpMenuItem);

		menuBar.add(helpMenu);
		setJMenuBar(menuBar);
		pack();
		// Threadsafe startup of main frame
		Runnable runner = new FrameShower(this);
		EventQueue.invokeLater(runner);
	}

	private void aboutHelpMenuItem_actionPerformed() {
		AboutForm aboutForm = new AboutForm(this, "About TS Client ");
		aboutForm.showDialog();
	}

	private void changePasswordActionMenuItem_actionPerformed(
			java.awt.event.ActionEvent evt) {

		SystemDBController systemController = SystemDBController.getInstance(); 
		ChangePasswordDialog passwordDialog = new ChangePasswordDialog(this, "Change password");
		Map passwordMap = null;
		Map userMap = null;
		int tries = 0;
		
		try {
			while (true) {
				passwordMap = passwordDialog.showDialog();
				if (((Boolean) passwordMap.get("isOkPressed")).equals(Boolean.FALSE)) {
					return;
				}
	
				if (!passwordMap.get("password1").equals(passwordMap.get("password2"))) {
					Messager.information(this, "Passwords are not equal");
					continue;
				}
				
				if (passwordMap.get("password1").toString().length() < 6) {
					Messager.information(this, "Passwords must have 6 or more characters");
					continue;
				}
				
				if (tries++ >3) {
					continue;	// Do not check anymore
				}

				userMap = systemController.getUser(LoginController.getPerson().get("user_name").toString());
				
				if (!userMap.get("Password").equals(passwordMap.get("passwordOld"))) {
					continue;
				}
				
				systemController.alterUser(LoginController.getPerson().get("user_name").toString(), passwordMap.get("password1").toString());
				return;
			}
		} catch (ControllerException ce) {
			Messager.exception(this, ce.getMessage());
			return;
		}
	}

	private void formWindowOpened(
		java.awt.event.WindowEvent evt) {
		// Add your handling code here:
		// Get icon
		// getResource scans the classpath for the resource.
		// This way we do not have to use a platform dependent system path
		//ImageIcon imageIcon = new
		// ImageIcon(getClass().getResource("/images/toolbarButtonGraphics/general/Zoom16.gif"));
		ImageIcon imageIcon =
			new ImageIcon(
				getClass().getResource(
					"/toolbarButtonGraphics/general/Zoom16.gif"));
		if (imageIcon != null) {
			Image frameImage = imageIcon.getImage();
			setIconImage(frameImage);
		}

		setExtendedState(Frame.MAXIMIZED_BOTH);

	}

	private void exitFileMenuItemActionPerformed(
		java.awt.event.ActionEvent evt) {
		shutDown();
	}

	/** Exit the Application */
	private void exitForm(java.awt.event.WindowEvent evt) {
		shutDown();
	}

	private void shutDown() {
		LoginController.logoffPerson();

		try {
			DataSourceHandler.closeDataSource();
		} catch (ControllerException ce) {
			System.out.println("Error closing data source: " + ce.getMessage());
		}
		
		System.exit(0);
	}

	public void go() throws Exception {

		String userName = LoginController.getPerson().get("user_name").toString();
		
		if (userName.equals("_TEST_")) {
			// Test environment: we have bypassed login
			try {
				// get DataSource from configuration file
				DataSourceHandler.loadCredentialsFromConfig();
				//UIManager.setLookAndFeel("com.jgoodies.plaf.plastic.PlasticLookAndFeel");
				//UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
				UIManager.setLookAndFeel(
					UIManager.getSystemLookAndFeelClassName());
			} catch (Exception e) {
				System.out.println(e.getMessage());
				log.warning(e.getMessage());
			}
		}

		initComponents();
		// Open internal frame via static method openFrame
		ClientSearchForm clientSearchForm = new ClientSearchForm();
		openFrame(clientSearchForm);
	}

	/**
	 * Each internal frame is opened by calling this static method
	 * 
	 * @param internalFrame
	 */
	public static void openFrame(JInternalFrame internalFrame) {

		try {
			windowGridMenu.addInternalFrame(internalFrame);
		} catch (GUIException ge) {
			Messager.information((JFrame) MainFrame.getInstance(), "Maximum number of windows exceeded.\nPlease close one or more windows");
			return;
		}
	}

	/**
	 * @param args
	 *                the command line arguments
	 */
	public static void main(String args[]) throws Exception {

		new MainFrame().go();
		//		// TEST: begin
		//		JInternalFrame internalFrame1 = new JInternalFrame("Test frame 1");
		//		internalFrame1.setName("Frame 1");
		//		registerFrame(internalFrame1);
		//		JInternalFrame internalFrame2 = new JInternalFrame("Test frame 2");
		//		internalFrame2.setName("Frame 2");
		//		registerFrame(internalFrame2);
		//		// TEST: begin
	}

	private static class FrameShower implements Runnable {
		final JFrame frame;
		public FrameShower(JFrame frame) {
			this.frame = frame;
		}
		public void run() {
			frame.setVisible(true);
		}
	}
	
	private boolean processPassword() {
		
		String password = null;
		Map personMap = null;
		SystemDBController systemController = SystemDBController.getInstance();
		PasswordOnlyDialog dialog = new PasswordOnlyDialog(this, "Password"); 
		int i =0;
		
		while (true) {
			password = dialog.showDialog();
			
			if (password == null) {
				return false;
			}
			
			// Check only 3 times
			try {
				if (i++ < 2) {
					personMap = systemController.getUser(LoginController.getPerson().get("user_name").toString());
					
					if (personMap != null) {
						if (password.equals(personMap.get("Password"))) {
							return true;
						}
					}
				}
			} catch (ControllerException ce) {
				String msg = "PersonSearch: error getting password.\n" + ce.getMessage();
				Messager.exception(this, msg);
				this.dispose();
				return false;
			}
		}
	}
}