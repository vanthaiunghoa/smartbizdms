/**
 * TS Client (http://www.transparent.co.nz)
 * Copyright (c) 2004 Transparent Systems Limited
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the /doc/LICENSE.txt
 * This is the GNU General Public License Version 2 as published by the Free Software Foundation.
 * You can download this program from <a href="http://sourceforge.com/projects/ts-client">http://sourceforge.com/projects/ts-client</a>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License Version 2 for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * Version 2 along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 */
 
 package nz.co.transparent.client.db;

/**
 * Application exception thrown if update fails
 * An UpdaterException is thrown if an other process has updated the record between first read and update. 
 *
 * @author John Zoetebier
 * @version 1.0
 */
public class UpdaterException extends Exception {

	/**
	 * Creates a default <code>UpdaterException</code> instance.
	 */
	public UpdaterException() {
		this("Record has already been changed");
	}

	/**
	 * Creates a <code>UpdaterException</code> instance with message
	 */
	public UpdaterException(String message) {
		super(message);
	}

    /**
     * Creates a <code>UpdaterException</code> instance and chains an
     * exception.
     *
     * @param e The exception to wrap and chain.
     */
    public UpdaterException(Throwable e) {
        super(e);
    }
}