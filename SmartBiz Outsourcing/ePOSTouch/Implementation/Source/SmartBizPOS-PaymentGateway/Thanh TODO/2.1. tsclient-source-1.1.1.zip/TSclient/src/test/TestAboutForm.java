/*
 * Created on Jan 29, 2004
 *
 */
package test;

import nz.co.transparent.client.gui.AboutForm;

/**
 * @author John Zoetebier
 * 
 */
public class TestAboutForm {

	/**
	 * 
	 */
	public TestAboutForm() {
		super();
	}

	public static void main(String[] args) {
		
		new AboutForm(null, "About TS Client").showDialog();
	}
}
