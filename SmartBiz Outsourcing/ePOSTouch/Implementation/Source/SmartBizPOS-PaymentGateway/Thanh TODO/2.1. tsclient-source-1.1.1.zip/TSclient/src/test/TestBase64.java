/*
 * Created on Jan 22, 2004
 *
 */
package test;

import org.apache.xerces.impl.dv.util.Base64;

/**
 * @author John Zoetebier
 * 
 */
public class TestBase64 {

	/**
	 * 
	 */
	public TestBase64() {
		super();
	}

	public static void main(String[] args) {
		
		String sender = new String("Sender name\nSender Address");
		byte[] senderArray = new byte[sender.length()];
		
		for (int i = 0; i < senderArray.length; i++) {
			senderArray[i] = (byte) sender.charAt(i);
		}
		
		String encoded = Base64.encode(senderArray);
		byte[] decoded = Base64.decode(encoded);
		System.out.println(new String(encoded));
		System.out.println(new String(decoded));
	}
}
