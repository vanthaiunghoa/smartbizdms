/*
 * Created on Dec 5, 2003
 */
package test;

import nz.co.transparent.client.gui.GridMenu;
import nz.co.transparent.client.gui.GUIException;
import nz.co.transparent.client.gui.MainFrame;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyVetoException;

import javax.swing.*;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import nz.co.transparent.client.util.Messager;

/**
 * @author johnz
 *
 */
public class TestGridMenu extends JFrame {

	static JMenuBar menuBar  = new JMenuBar();
	static JMenu fileMenu = new JMenu();
	static JMenuItem fileCloseAllWindowsMenuItem = new JMenuItem("Close all windows");
	static JMenuItem fileMenuItem2 = new JMenuItem("File item 2");
	static JMenu actionMenu = new JMenu();
	static JMenuItem actionMenuItem1 = new JMenuItem("Open frame 1");
	static JMenuItem actionMenuItem2 = new JMenuItem("Action item 2");
	static JMenuItem actionMenuItem3 = new JMenuItem("Action item 3");
	static JDesktopPane desktopPane = new JDesktopPane();
	static JMenu windowMenu = new JMenu();
	static GridMenu windowGridMenu = new GridMenu(desktopPane, windowMenu);
	static JLabel messageLabel = new JLabel("Message");

	static JMenu helpMenu = new JMenu("Help");
	static JMenuItem helpContentMenuItem = new JMenuItem("Content");
	static JMenuItem helpAboutMenuItem = new JMenuItem("About");
	
	static JInternalFrame internalFrame1 = new JInternalFrame();
	static JInternalFrame internalFrame2 = new JInternalFrame();
	
	/**
	 * 
	 */
	public TestGridMenu() {
		super();
	}
	
	public void go() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		addWindowListener(new WindowAdapter() {
			public void windowOpened(WindowEvent e) {
				setExtendedState(Frame.MAXIMIZED_BOTH);
			}
		});
		
		Container content = getContentPane();
		content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
		getContentPane().add(desktopPane, java.awt.BorderLayout.CENTER);

		fileMenu.setText("File");
		fileMenu.setMnemonic('F');
		fileCloseAllWindowsMenuItem.setText("Close all windows");
		fileCloseAllWindowsMenuItem.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				JInternalFrame [] internalFrames = desktopPane.getAllFrames();
				for (int i=0; i<internalFrames.length; i++) {
					internalFrames[i].dispose();
				}
			}
		});
		fileMenu.add(fileCloseAllWindowsMenuItem);
		fileMenu.add(fileMenuItem2);
		menuBar.add(fileMenu);

		actionMenu.setText("Action");
		actionMenu.setMnemonic('A');
		actionMenuItem1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openInternalFrame(internalFrame1);
			}
		});
		actionMenu.add(actionMenuItem1);
		actionMenu.add(actionMenuItem2);
		actionMenu.add(actionMenuItem3);
		menuBar.add(actionMenu);

		windowGridMenu.setMaxColumns(4);
		windowGridMenu.setMaxRows(6);

		windowMenu.setText("Window");
		windowMenu.setMnemonic('W');
		windowMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
			}

			public void menuDeselected(MenuEvent e) {
			}

			public void menuSelected(MenuEvent e) {
				windowGridMenu.refreshMenuItems();
			}
		});
		
		menuBar.add(windowMenu);

		helpMenu.setMnemonic('H');
		helpAboutMenuItem.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				String msg = "About help not implemented yet !";
				Messager.information((JFrame) MainFrame.getInstance(), msg);
			}
		});
		
		helpAboutMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String msg = "actionPerformed: About help not implemented yet !";
				Messager.information((JFrame) MainFrame.getInstance(), msg);
			}
		});

		helpMenu.add(helpContentMenuItem);
		helpMenu.add(helpAboutMenuItem);
		menuBar.add(helpMenu);
		setJMenuBar(menuBar);

		internalFrame1.setName("InternalFrame 1");
		internalFrame1.setTitle("InternalFrame 1");
		internalFrame1.setClosable(true);
		internalFrame1.setResizable(true);
		
		internalFrame2.setName("InternalFrame 2");
		internalFrame2.setTitle("InternalFrame 2");
		internalFrame2.setClosable(true);
		internalFrame2.setResizable(true);
		internalFrame2.setLocation(internalFrame1.getWidth(), 0);

		JButton testButton1 = new JButton("Test 1");
		testButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final JInternalFrame internalFrame2 = new JInternalFrame("InternalFrame 2");
				internalFrame2.setName("InternalFrame 2");
				internalFrame2.setClosable(true);
				internalFrame2.setSize(300,200);
				Dimension screenDimension = Toolkit.getDefaultToolkit().getScreenSize();
				int x = (int) (Math.random() * screenDimension.width) - internalFrame2.getWidth();
				x = Math.max(x,internalFrame1.getWidth());
				int y = (int) (Math.random() * screenDimension.height)  - internalFrame2.getHeight();
				y = Math.max(y,internalFrame1.getHeight());
				internalFrame2.setLocation(x,y);
				openInternalFrame(internalFrame2);
			}
		});
		
		JButton testButton2 = new JButton("Test InternalFrames");
		testButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JInternalFrame[] internalFrames = desktopPane.getAllFrames();
//				System.out.println("==> internalFrameNames");
//				for (int i=0; i< internalFrames.length; i++) {
//					System.out.println("   " + internalFrames[i].getName());
//				}
				// Set focus on internal frame 3
				messageLabel.setText(internalFrames[3].getName());
				//internalFrames[3].toFront();
				try {
					internalFrames[3].setSelected(true);
				} catch (PropertyVetoException pve) {
					System.out.println(pve.getMessage());
				}
				
			}
		});
		
		internalFrame1.getContentPane().setLayout(new GridLayout(5,0));
		internalFrame1.getContentPane().add(testButton1);
		internalFrame1.getContentPane().add(testButton2);
		internalFrame1.getContentPane().add(messageLabel);
		internalFrame1.setSize(400,200);
		openInternalFrame(internalFrame1);

		// Open some test frames
		for (int i=0; i<5; i++) {
			final JInternalFrame internalFrame2 = new JInternalFrame("InternalFrame 2");
			internalFrame2.setName("InternalFrame 2");
			internalFrame2.setClosable(true);
			internalFrame2.setSize(300,200);
			Dimension screenDimension = Toolkit.getDefaultToolkit().getScreenSize();
			int x = (int) (Math.random() * screenDimension.width) - internalFrame2.getWidth();
			x = Math.max(x,internalFrame1.getWidth());
			int y = (int) (Math.random() * screenDimension.height)  - internalFrame2.getHeight();
			y = Math.max(y,internalFrame1.getHeight());
			internalFrame2.setLocation(x,y);
			openInternalFrame(internalFrame2);
		}

		setSize(new Dimension(500,400));
		pack();
		show();
	}
	    
	/**
	 * Each internal frame is opened by calling this static method 
	 * @param internalFrame
	 */
	public static void openInternalFrame(JInternalFrame internalFrame) {
		
		try {
			windowGridMenu.addInternalFrame(internalFrame);
		} catch (GUIException ge) {
			Messager.information(internalFrame, "Maximum number of windows exceeded.\nPlease close one or more windows");
			return;
		}
	}

	public static void main(String[] args) {
		new TestGridMenu().go();
	}
	
}
