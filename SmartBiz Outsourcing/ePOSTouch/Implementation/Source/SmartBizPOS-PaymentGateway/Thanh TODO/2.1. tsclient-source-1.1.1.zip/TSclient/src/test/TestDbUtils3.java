/*
 * Created on Dec 13, 2003
 *
 */
package test;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.MapHandler;

import nz.co.transparent.client.db.ControllerException;
import nz.co.transparent.client.db.DataSourceHandler;

/**
 * @author johnz
 * 
 */
public class TestDbUtils3 {

	/**
	 * 
	 */
	public TestDbUtils3() {
		super();
	}
	
	public void go() {
		
		DataSource dataSource= DataSourceHandler.getDataSource();
		QueryRunner runner = new QueryRunner(dataSource);
		ResultSetHandler rsh = new MapHandler();
		String sql = "select * from Client where (ClientID=1)";
		Map clientMap = null;
		try {
			clientMap = (Map) runner.query(sql, null, rsh);
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}
		
		Set fieldSet = clientMap.keySet();
		Iterator iterator = fieldSet.iterator();
		String fieldName = null;
		
		while (iterator.hasNext()) {
			fieldName = (String) iterator.next();
			System.out.println("Field name = " + fieldName);
			System.out.println("Field value = " + clientMap.get(fieldName));
		}
		
		clientMap = null;
		try {
			clientMap = (Map) runner.query(sql, null, rsh);
			DataSourceHandler.closeDataSource();
		} catch (ControllerException ce) {
			System.out.println(ce.getMessage());
			return;
		} catch (SQLException se) {
			System.out.println(se.getMessage());
			return;
		}

		System.out.println("LastName = " + clientMap.get("lastname"));
	}
	

	public static void main(String[] args) {
		new TestDbUtils3().go();
	}
}
