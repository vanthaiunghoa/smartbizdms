package atTools;


import java.text.*;

import javax.swing.table.*;
 
public class FormatRenderer extends DefaultTableCellRenderer 	 {
    /**
	 * 
	 */
	private static final long serialVersionUID = 7531981586779859504L;
		private Format formatter;
 
    public FormatRenderer(Format formatter) {
        if (formatter==null)
            throw new NullPointerException();
        this.formatter = formatter;
    }
 
    protected void setValue(Object obj) {
        setText(obj==null? "" : formatter.format(obj));
    }
}