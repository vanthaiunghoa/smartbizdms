package WDInterface;

import javax.swing.JButton;



class TheBatch extends Thread
{
	String url;
	JButton buttonStart;
	JButton buttonStop;
	
	public void run()
	{
		runBatch();
	}
	public void setURL(String URL)
	{
		url=URL;
	}
	
	public void setButton(JButton btnStart,JButton btnStop)
	{
		buttonStart=btnStart;
		buttonStop=btnStop;
	}
 
	
	private void runBatch()
  {
  	BatchRun batch;
  	// Prüfen ob alles für batch vorbereitet
  	try
  	{
    	buttonStart.setVisible(false);
	  	if ((PV.BatchFile.length()>0 && PV.ReqVarNo>0 && PV.ResVarNo>0)==true)
	  	{
	    	batch=new BatchRun(PV.BatchFile);
	    	batch.run(url,buttonStart,buttonStop);
	  	}
	  	else
	  	{
	  		//"Please select all Parameters"
	  		PV.ml.writeLog('m', 1, PV.LMeldungen[34]);
	  	}
  	}
  	catch(Exception e)
  	{
  		//Fehler beim %1-run. Exception : %2 
  		PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[27],new String[]{"Batch",e.toString()});
  	}
  	
  }
 
    
}