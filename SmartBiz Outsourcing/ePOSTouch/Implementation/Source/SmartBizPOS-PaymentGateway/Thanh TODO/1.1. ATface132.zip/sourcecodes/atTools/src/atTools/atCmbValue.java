package atTools;

public class atCmbValue
{
/**
 * Column Text for Combobox
 */
public String text; 

public String text2;

public String trenner;


/**
 * Column No in Table, starting with 0
 */
public int position;



/**
 * @param Position - Column No in Table, starting with 0
 * @param Field - Name of field from resultset, containing data to be displayed in this Column
 * @version 1.0
 * @author Andreas Tritt
 */
public void InfoAboutClass()
{
	
}

public atCmbValue(int Position, String Text1){;//,String Text2,String Trenner){
	this.text=Text1;
//	this.text2=Text2;
	this.position=Position;
//	this.trenner;
	}


}
