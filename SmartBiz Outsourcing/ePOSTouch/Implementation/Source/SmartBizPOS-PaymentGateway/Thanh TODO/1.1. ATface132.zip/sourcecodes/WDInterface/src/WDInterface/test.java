package WDInterface;


import java.io.*;
import java.net.*;

import javax.swing.JTextArea;

public class test
{
	private JTextArea out;
	
	public boolean send()
	{

		String login;
		String pass;
		String poststring;
		String contentype;
		
		
		try 
		{

			login =  "56501";
			pass = "TestXAPTER";
			contentype="text/xml; charset=\"utf-8\"";

			poststring = "<?xml version='1.0' encoding='UTF-8'?>\r\n"+
			"<WIRECARD_BXML xmlns:xsi='http://www.w3.org/1999/XMLSchema-instance'\r\n"+
			               "xsi:noNamespaceSchemaLocation='wirecard.xsd'>\r\n"+
			    "<W_REQUEST>\r\n"+
			        "<W_JOB>\r\n"+
			            "<JobID>job 2</JobID>\r\n"+
			            "<BusinessCaseSignature>56501</BusinessCaseSignature>\r\n"+
			            "<FNC_CC_TRANSACTION>\r\n"+
			                "<FunctionID>WireCard Test</FunctionID>\r\n"+
			                "<CC_TRANSACTION>\r\n"+
			                    "<TransactionID>2</TransactionID>\r\n"+
			                    "<Amount>100</Amount>\r\n"+
			                    "<Currency>EUR</Currency>\r\n"+
			                    "<CountryCode>DE</CountryCode>\r\n"+
			                    "<RECURRING_TRANSACTION>\r\n"+
			                        "<Type>Single</Type>\r\n"+
			                    "</RECURRING_TRANSACTION>\r\n"+
			                    "<CREDIT_CARD_DATA>\r\n"+
			                        "<CreditCardNumber>4200000000000000</CreditCardNumber>\r\n"+
			                        "<CVC2>000</CVC2>\r\n"+
			                        "<ExpirationYear>2014</ExpirationYear>\r\n"+
			                        "<ExpirationMonth>01</ExpirationMonth>\r\n"+
			                        "<CardHolderName>Chröstian Straß</CardHolderName>\r\n"+
			                    "</CREDIT_CARD_DATA>\r\n"+
			                    "<CONTACT_DATA>\r\n"+
			                        "<IPAddress>127.0.0.1</IPAddress>\r\n"+
			                    "</CONTACT_DATA>\r\n"+
			                    "<CORPTRUSTCENTER_DATA>\r\n"+
			                        "<ADDRESS>\r\n"+
			                            "<Address1></Address1>\r\n"+
			                            "<City></City>\r\n"+
			                            "<ZipCode></ZipCode>\r\n"+
			                            "<State></State>\r\n"+
			                            "<Country></Country>\r\n"+
			                            "<Phone></Phone>\r\n"+
			                            "<Email>support@wirecard.com</Email>\r\n"+
			                        "</ADDRESS>\r\n"+
			                    "</CORPTRUSTCENTER_DATA>\r\n"+
			                "</CC_TRANSACTION>\r\n"+
			             "</FNC_CC_TRANSACTION>\r\n"+
			        "</W_JOB>\r\n"+
			    "</W_REQUEST>\r\n"+
			"</WIRECARD_BXML>\r\n";
			
			
			
			
	    // Construct data
			System.out.println("Start Test");
			out.append("Start Test");
		
	    // Send data
	    URL url = new URL("https://c3-test.wirecard.com/secure/ssl-gateway");
	    System.out.println(url.toString());
	    
	    
	    //URLConnection conn = url.openConnection();
	    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	    conn.setDoOutput(true);
      conn.setRequestProperty("Content-Type",contentype );
      int len=poststring.length();
      System.out.println(len);
      
 	    
	    System.out.println("Connection");
	    out.append("Connection");

	
	    
      System.out.println("CONN: "+conn.toString()+"\r\n");
      System.out.println("POST: "+poststring+"\r\n");
      System.out.println("CTYP: "+contentype+"\r\n");
      out.append("CONN: "+conn.toString()+"\r\n");
      out.append("POST: "+poststring+"\r\n");
      out.append("CTYP: "+contentype+"\r\n");

      if(!conn.getDoOutput())
      {
      	 conn.setDoOutput(true);
      }
       
      conn.setRequestProperty("Content-Length", String.valueOf(poststring.length() ));
      conn.setRequestProperty("Authorization", "Basic "+ encrypt(login+":"+pass));
      conn.setRequestMethod("POST");

      OutputStream wr = conn.getOutputStream();
      wr.write(poststring.getBytes());
	    
	    wr.flush();
	    System.out.println("Request is send\n");

	    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	    System.out.println("rd");
	    
	    String line;
	    System.out.println("This is the response from Wirecard Server\n#############################\n");
	    while ((line = rd.readLine()) != null) 
	    {
	        // Process line...
	    	System.out.println(line);
			out.append(line);

	    }
	    wr.close();
	    rd.close();
		} 
		catch (Exception e) 
		{
			System.out.println("Fehler:\r\n "+e.toString());
		}
		return false;
	}
	
	public String encrypt(String str)
	{
    try 
    {
        // Encode the string into bytes using utf-8
        byte[] utf8 = str.getBytes("UTF8");
        // Encode bytes to base64 to get a string
        return new sun.misc.BASE64Encoder().encode(utf8);
    } 
    catch (UnsupportedEncodingException e) 
    {
    		// insert some code
    }
    return null;
}
}

