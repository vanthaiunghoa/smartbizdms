package atTools;

import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class atErrorDialog
{
	/**
	 * Erstellt JOptionPane.showMessageDialog mit Umbruch nach 40 Zeichen
	 * @param frame
	 * @param text
	 */
	public atErrorDialog(JFrame frame,String text) 
	{
    JOptionPane.showMessageDialog(frame, Strings.cutToLen(text,40),"",JOptionPane.ERROR_MESSAGE);
	}
	
/*	private String cutToLen(String text, int len)
	{
		String ergebnis;
		ergebnis="";
		String hstring="";
		String hstring2="";
		int anzahl=0;
		int found=0;
		text+=" ";
		while (text.length()>0 && anzahl <10)
		{
			found=text.indexOf(" ");

			hstring=atTools.Strings.leftstring(text,found+1);
			text=atTools.Strings.rightstring(text, text.length()-found-1);
			if ((hstring2.length() +hstring.length()>40) && hstring2.length()>0 )
			{
				anzahl++;
				hstring2+="\n";
				ergebnis+=hstring2;
				hstring2="";
			}
			hstring2+=hstring;
		}
		ergebnis+=hstring2;
		return ergebnis;
	}*/
}
