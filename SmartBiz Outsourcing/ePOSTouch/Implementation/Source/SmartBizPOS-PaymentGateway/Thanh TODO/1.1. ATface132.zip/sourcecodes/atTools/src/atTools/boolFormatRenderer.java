package atTools;


import java.text.*;
import java.awt.*;

import javax.swing.table.*;
 
public class boolFormatRenderer extends DefaultTableCellRenderer 	 {
    /**
	 * 
	 */
	private static final long serialVersionUID = 7531981586779859504L;
		private Format formatter;
 
    public boolFormatRenderer(Format formatter) {
        if (formatter==null)
            throw new NullPointerException();
        this.formatter = formatter;
    }
 
    protected void setValue(Object obj) {
        setText(obj==null? "" : formatter.format(obj));
        if ( Integer.valueOf(this.getText().toString())==1)
        {
        	setBackground(Color.RED);
        }
        else
        {
        	setBackground(Color.GREEN);
        }
        
    }
}