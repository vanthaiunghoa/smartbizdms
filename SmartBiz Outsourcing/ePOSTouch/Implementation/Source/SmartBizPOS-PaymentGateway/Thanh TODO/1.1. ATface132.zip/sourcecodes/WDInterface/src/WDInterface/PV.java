package WDInterface; 


import javax.swing.*;

 
//import java.awt.Toolkit;

public class PV extends Object
{
//Update comments
/*################ 
 * 1.2.1 - max number of request raised from 20 to 50
 * 1.2.2 - it is possible to define request Directory in config.ini 
 * 1.2.3 - Correction for Config.ini-Writer
 * 1.2.4 - Set Batch Response to scoll to end
 * 1.2.5 - Counter for Batch
 * 1.2.6 - Stop Button for Batch
 *         Icon for Programm
 * 1.2.7 - Layout changed
 * 1.2.8 - Lang dir can be configured
 * 1.2.9 - batch dir can be configured
 *         batch dir is saved during programm run.
 *         proceessed batch file is renamed to * .done
 * 1.3.0 - Tabs can be hidden
 * 1.3.1 - It is possible to restrict to use of one https-Uesr
 * */	
	
	
// fuer tests
	public static   String            Version="1.3.1";
  public static   String            Ausgabe[] = new String[3];
  public static   int               StrNr;
  public static   int               destNr;// Anzahl der Destinations
  public static   String[]          destName;// Array mit 
  public static   String[]          destHost;// Array mit 
  public static   String[]          destPort;// Array mit 
  public static   String[]          destPath;// Array mit 
  public static   String[]          destUser;// Array mit 
  public static   String[]          destPass;// Array mit 
  public static   String[]          destBC_SIG;// Array mit 
  public static   String[]          destDir;//Arry mit Verzeichnissen fuer Requests.
  public static   int               destSelected;
  public static   String[]          ReqTypName;
  public static   String[]          ReqTypFile;
  public static   int               ReqTypMax;
  public static   int               ReqSelected;
  public static   String[]          ReqVar; //Array mit Variablennamen für Request
  public static   int               ReqVarNo; // Anzahl der gelesenen Variablennamen für Request
  public static   String[]          ResVar;  //Array mit Variablennamen für Response
  public static   int               ResVarNo; // Anzahl der gelesenen Variablennamen für Response
  public static   String            BatchFile;
  public static   String            BatchReqStringVar; // String mit Request , enthält Variablennamen
  public static   String            BatchReqStringcomplete; // String mit Request , Variablennamen wurden bereits durch Werte ersetzt
  public static   String            BatchUser="";
  public static   String            BatchPass="";
	public static   JTextArea         tRcRRRes;
	public static   JTextArea         textVT;
	public static   JTextField        tCounter;
  public static   int               Counter;
  
  public static   JLabel[]          VtLabel;
  public static   JTextField[]      VtText;
  public static   JLabel[]          VtResLabel;
  public static   JTextField[]      VtResText;
  
  public static   int               VtNo=0;
  
	public static   JTextField        tVtStatus;
  
  public static   int								maxLenTexDisp=120;      
  
// fuer livebetrieb
  public static		atTools.Logfile 	ml; //controller.Logs ml;
	public static		int 							PrgMode=1; //0 = Entwicklung 1= Live
	public static		String 						aUser;// angemeldeter User
  public static		IniReader 				IR ;// Ini Reader
	public static		int               resx;//Bildschirmauflösung
	public static		int 							resy;//Bildschirmauflösung
	public static		String						PrgName="ATface";//Progamm Name
	public static		double 						GFact=.97;// Verhältniss Grösse Schirm zu Programmfenster
  public static    String						separator; // Zeichen zwischen Verzweichnissen
 // public static   boolean           stop; // Programm wird beendet
  public static   int               stopcounter;
  public static   String []         langText; //Hilfsstring zum Einlesen der Sprachtexte
  public static   String						homedir; // Verzeichnis für home des users
  public static   String            langdir; // Verzeichnis für Sprachfiles
  public static   String            prgdir; // Verzeichnis für config u. logfiles
  public static   String            reqdir; // Verzeichnis für Requests
  public static   String            batchdir;
  public static   String []					LMeldungen; // Array mit Sprachtexten
  public static   String []         LBeschriftungen;// Array mit Sprachtexten
  public static   String []         LFehlerMeldungen;// Array mit Sprachtexten
  public static   String 						LMenue[]; // Array mitt Sprachtexten
  public static 	String						lang; //Sprache
  public static   int               updateVer;
  
  public static   boolean           stop=false;
//  public static   boolean           viewRequest;
//  public static   boolean           viewBatch;
//  public static   boolean           viewVT;

  //  public static   String []         DirToSave; // Array für Konfiguration
//  public static   String []         DirNotToSave;// Array für Konfiguration
//  public static   String []         FileToSave;// Array für Konfiguration
//  public static   String []         FileNotToSave;// Array für Konfiguration
  
//  public static   configuration     Conf;//Instanz der Klasse zum Bearbeiten der Konfigurations
//  public static   String						ConfFile=""; // Name des Config Files 
//  public static   String[]          ConfText;
//  public static   Dir               backupDir;
//  public static   boolean           ConfIsLoaded;
  
/*  public static   String[] 					ADirToSave ;
  public static   String[] 					ADirNotToSave ;
  public static   String[]					AFileToSave ;
  public static   String[]					AFileNotToSave;
  public static   int 							lDirToSave;
  public static   int 							lDirToNotSave;
  public static   int 							lFileToSave;
  public static   int 							lFileNotToSave;
  
  public static   Date 							ldate;// Alle zu sichernden Files müssen neuer als dieses Datum sein 
  public static   boolean 					checkDate;*/
  
//  public static   long 							beginn;
//  public static   BufferedWriter 		lfile;
//  public static   String            Anfang;
  
public PV()
{


}

}
