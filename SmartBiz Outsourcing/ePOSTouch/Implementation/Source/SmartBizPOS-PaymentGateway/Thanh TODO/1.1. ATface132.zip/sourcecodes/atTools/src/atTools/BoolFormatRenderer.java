package atTools;


import java.text.*;
import java.awt.*;

import javax.swing.table.*;
 
public class BoolFormatRenderer extends DefaultTableCellRenderer 	 {
    /**
	 * 
	 */
	private static final long serialVersionUID = 7531981586779859504L;
		private Format formatter;
 
    public BoolFormatRenderer(Format formatter) {
        if (formatter==null)
            throw new NullPointerException();
        this.formatter = formatter;
    }
 
    protected void setValue(Object obj) {
        setText(obj==null? "" : formatter.format(obj));
        if ( Integer.valueOf(this.getText().toString())==1)
        {
        	setBackground(Color.GREEN);
        }
        else
        {
        	setBackground(Color.RED);
        }
        
    }
}