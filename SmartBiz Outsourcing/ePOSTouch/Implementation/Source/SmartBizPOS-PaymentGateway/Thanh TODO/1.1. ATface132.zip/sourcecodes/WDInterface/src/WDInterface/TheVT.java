package WDInterface;

import javax.swing.JButton;



class TheVT extends Thread
{
	String url;
	String user;
	String pass;
	JButton button;
	
	public void run()
	{
		runVT();

	}
	public void setURL(String URL)
	{
		url=URL;
	}
	public void setUser(String USER)
	{
		user=USER;
	}
	public void setPass(String PASS)
	{
		pass=PASS;
	}
		
	public void setButton(JButton btn)
	{
		button=btn;
	}

	private void runVT()
  {
  	try
  	{
  		button.setVisible(false);
    	VTRun vt;
    	vt=new VTRun();
    	vt.setLogin(user);
    	vt.setPass(pass);
    	vt.run(url,button);
  	}
  	catch(Exception e)
  	{
  		//Fehler beim %1-run. Exception : %2 
  		PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[27],new String[]{"VT",e.toString()});
  	}
  }

    
}