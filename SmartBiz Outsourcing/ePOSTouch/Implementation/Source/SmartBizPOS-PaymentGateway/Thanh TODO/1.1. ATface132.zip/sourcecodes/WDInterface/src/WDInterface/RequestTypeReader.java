package WDInterface;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import WDInterface.PV;
import atTools.Strings;


/**
 * 
 * @author Andreas Tritt
 *
 */


public class RequestTypeReader
{

	String cfile; // file das Konfiguration enthält
//	private atTools.Logfile localml ;

	public RequestTypeReader()
	{
	
	}
	
	public boolean readReqTypes(String sdir)
	{
		int max=0;
		cfile=sdir+PV.separator+"Requests.ini";
		String help1;
		String help2;
		//		//Start Request Type Reader %1
		PV.ml.writeLog('n', 1, PV.LMeldungen[11]);
	
		
		try 
		{
			//Read RequestType Ini: %1 
			PV.ml.writeLog('n', 1, PV.LMeldungen[12],cfile);
			BufferedReader in = new BufferedReader(new FileReader(cfile));
			String str;
			str = in.readLine();
			str=Strings.rightstring(str, str.length()-str.indexOf('=')-1);
			max=Integer.parseInt(str);
		  for (int p=1;p<=max;p++)
			{
				str = in.readLine();
				str=Strings.rightstring(str, str.length()-str.indexOf(' ')-1);
				help1=Strings.leftstring(str, str.indexOf(' '));
				help2=Strings.rightstring(str, str.length()-str.indexOf(' ')-1);
				PV.ReqTypName[p]=help1;
				PV.ReqTypFile[p]=help2;
			}
			
			in.close();
		} 
		catch (IOException e) 
		{
			//error in RequestTypeReader from file %1 for area %2 Exception: %3
			PV.ml.writeLog('m', 1,  PV.LFehlerMeldungen[6],new String[]{cfile,"readArea",e.toString()});
			return false;
		}
		PV.ReqTypMax=max;
		//Request Types gefunden
		PV.ml.writeLog('n', 0, PV.LMeldungen[13],String.valueOf(PV.ReqTypMax));
		return true;
	}
	
	
	

}

	