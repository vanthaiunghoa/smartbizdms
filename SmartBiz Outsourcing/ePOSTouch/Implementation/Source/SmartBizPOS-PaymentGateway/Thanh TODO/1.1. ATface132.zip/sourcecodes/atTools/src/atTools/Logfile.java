package atTools;

import java.text.*;
import java.util.*;
//import java.io.FileOutputStream;
//import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;
//import java.lang.*;

import javax.swing.JFrame;
import javax.swing.JOptionPane;



public class Logfile
{
	
	private String filenameError;
	private String filenameNormal;
	private String filenameControl;
	private String separator;
	private java.io.FileWriter fwError;
	private java.io.FileWriter fwNormal;
	private java.io.FileWriter fwControl;
	private java.io.BufferedWriter bwError;
	private java.io.BufferedWriter bwNormal;
	private java.io.BufferedWriter bwControl;
	private String hstring;
	private String lstring;
	
	/**
	 * void writeLog(char LogMode, int PrgModeSoll, String text,String[] Var)
	 * @param text string.............- MainText to be filled up with Var at Position %n
	 * @param Var string []{"","",""}.- text to be filled in MainText   Sample : Strings.mix(PV.LFehlerMeldungen[1],new String[]{cfile,Bereich,e.toString()})
	 * @param LogModes char...........- e=error-log   c=control-log (Alle Ab-/ An- und Ummeldungen   n=normal-log e+c+alle anderen Einträge
	 * @param PrgModeSoll int.........- 0=Entwicklung   1=Livemode  If PrgModeSoll >= value in config logfile will be written.
	 */	
	public void writeLog(char LogMode, int PrgModeSoll, String text,String[] Var)
	{
		writeLog(LogMode,PrgModeSoll,Strings.mix(text, Var));
	}

	/**
   * void writeLog(char LogMode, int PrgModeSoll, String text,String Var)
	 * @param text string             - MainText to be filled up with Var at Position %n
	 * @param Var string - text to be filled in MainText
	 * @param LogModes char  e=error-log   c=control-log (Alle Ab-/ An- und Ummeldungen   n=normal-log e+c+alle anderen Einträge
	 * @param PrgModeSoll int  0=Entwicklung   1=Livemode  Wenn PrgModeSoll >= dem Wert in der config ist wird logfile geschrieben.
	 */		
	 public void writeLog(char LogMode, int PrgModeSoll, String text,String Var)
	{
		writeLog(LogMode,PrgModeSoll,Strings.mix(text, Var));
	}
	

	 /**
   * void writeLog(char LogMode, int PrgModeSoll, boolean DosBox, boolean MessageBox, String textLog, String textLang,String[] Var)
	 * @param textLang string             - MainText to be filled up with Var at Position %n in selected Language
	 * @param textLog string              - MainText to be filled up with Var at Position %n in Log-language (englisch)
	 * @param Var string - text to be filled in MainText
	 * @param DosBox boolean - Anzeige auch in DosBox
	 * @param MessageBox boolean - Anzeige auch in MessageBox
	 * @param LogModes  char  e=error-log   c=control-log (Alle Ab-/ An- und Ummeldungen   n=normal-log e+c+alle anderen Einträge
	 * @param PrgModeSoll int  0=Entwicklung   1=Livemode  Wenn PrgModeSoll >= dem Wert in der config ist wird logfile geschrieben.
	 */		
	 public void writeLog(char LogMode, int PrgModeSoll, boolean DosBox, boolean MessageBox, String textLog, String textLang,String[] Var)
	 {
		 String AusgabeLog=Strings.mix(textLog, Var);
		 String AusgabeLang=Strings.mix(textLang, Var);
		 writeLog(LogMode,PrgModeSoll,DosBox,MessageBox,AusgabeLog,AusgabeLang);
	 }

	 /**
	   * void writeLog(char LogMode, int PrgModeSoll, boolean DosBox, boolean MessageBox, String textLog, String textLang,String Var)
		 * @param textLang string             - MainText to be filled up with Var at Position %n in selected Language
		 * @param textLog string              - MainText to be filled up with Var at Position %n in Log-language (englisch)
		 * @param Var string - text to be filled in MainText
		 * @param DosBox boolean - Anzeige auch in DosBox
		 * @param MessageBox boolean - Anzeige auch in MessageBox
		 * @param LogModes  char  e=error-log   c=control-log (Alle Ab-/ An- und Ummeldungen   n=normal-log e+c+alle anderen Einträge
		 * @param PrgModeSoll int  0=Entwicklung   1=Livemode  Wenn PrgModeSoll >= dem Wert in der config ist wird logfile geschrieben.
		 */		
		 public void writeLog(char LogMode, int PrgModeSoll, boolean DosBox, boolean MessageBox, String textLog, String textLang,String Var)
		 {
			 String AusgabeLog=Strings.mix(textLog, Var);
			 String AusgabeLang=Strings.mix(textLang, Var);
			 writeLog(LogMode,PrgModeSoll,DosBox,MessageBox,AusgabeLog,AusgabeLang);
		 }
	 
	 /**
   * void writeLog(char LogMode, int PrgModeSoll, boolean DosBox, boolean MessageBox, String AusgabeLog, String AusgabeLang)
	 * @param textLang string             - MainText to be filled up with Var at Position %n in selected Language
	 * @param textLog string              - MainText to be filled up with Var at Position %n in Log-language (englisch)
	 * @param DosBox boolean - Anzeige auch in DosBox
	 * @param MessageBox boolean- Anzeige auch in MessageBox
	 * @param LogModes char  e=error-log   c=control-log (Alle Ab-/ An- und Ummeldungen   n=normal-log e+c+alle anderen Einträge
	 * @param PrgModeSoll  int  0=Entwicklung   1=Livemode  Wenn PrgModeSoll >= dem Wert in der config ist wird logfile geschrieben.
	 */		
	 public void writeLog(char LogMode, int PrgModeSoll, boolean DosBox, boolean MessageBox, String AusgabeLog, String AusgabeLang)
	 {
		 if (DosBox) System.out.println(AusgabeLang); 
		 if (MessageBox)
		 {
			 switch (LogMode)
			 {
			 case 'n':
				 JOptionPane.showMessageDialog(new JFrame(),Strings.cutToLen(AusgabeLang,40) ,"information",JOptionPane.INFORMATION_MESSAGE);
				 break;
			 case 'e':
				 JOptionPane.showMessageDialog(new JFrame(),Strings.cutToLen(AusgabeLang,40) ,"error",JOptionPane.ERROR_MESSAGE);
				 break;
			 default:
				 LogMode='n';
			 }
		 }
		 writeLog(LogMode,PrgModeSoll,AusgabeLog);
	 }
	
	 /**
   * void writeLog(char LogMode,int PrgModeSoll, String text)
	 * @param Ausgabe  string             - Text to be displayed
	 * @param LogModes char  e=error-log   c=control-log (Alle Ab-/ An- und Ummeldungen   n=normal-log e+c+alle anderen Einträge
	 * @param PrgModeSoll  int  0=Entwicklung   1=Livemode  Wenn PrgModeSoll >= dem Wert in der config ist wird logfile geschrieben.
	 */		
	public void writeLog(char LogMode,int PrgModeSoll, String text)
  {
	boolean Leerzeile;
  if (LogMode=='m')
  {
  	JOptionPane.showMessageDialog(new JFrame(),Strings.cutToLen(text,40) ,"error",JOptionPane.ERROR_MESSAGE);
  	LogMode='e';//Weiterbehandlung wie error
  }

	if (text.length()==0)
	{
		text="  ";// wegen while Schleife
		Leerzeile=true;
	}
	else
	{
		Leerzeile=false;
	}
	
	Date dt = new Date();
	SimpleDateFormat df = new SimpleDateFormat( "dd-MM-yyyy HH:mm:ss.SSS" );

	lstring=df.format( dt ) +" "; // Datum

	hstring="      "+Thread.currentThread().getStackTrace()[3].getLineNumber();//Zeilennummer
	hstring=Strings.rightstring(hstring,6);
	lstring+=hstring+" ";
	
	hstring=Thread.currentThread().getStackTrace()[3].getClassName()+".";//Aufrufende Klasse
	hstring+=Thread.currentThread().getStackTrace()[3].getMethodName();//Aufrufende Funktion	
	hstring+="                                                                                ";
  hstring=Strings.leftstring(hstring, 59)+" ";
  lstring+=hstring+" ";

  hstring=Strings.leftstring(text, 60);
  lstring+=hstring;
  
  while (text.length()>1) // Zeilen länger als 60 Zeichen auf mehrere Zeilen umbrechen
  {
		if  (PrgMode <= PrgModeSoll)
		{
			try
			{
				switch (LogMode)
				{
				case 'n':
					bwNormal.write(lstring);
					bwNormal.newLine();
					bwNormal.flush();
					break;
				case 'e':
					bwNormal.write(lstring);
					bwNormal.newLine();
					bwNormal.flush();
					bwError.write(lstring);
					bwError.newLine();
					bwError.flush();
					break;
				case 'c':
					if (Leerzeile)
					{
						bwControl.newLine();
						bwControl.flush();
						break;
					}
					bwControl.write(lstring);
					bwControl.newLine();
					bwControl.flush();
					bwNormal.write(lstring);
					bwNormal.newLine();
					bwNormal.flush();
					break;
				}
			} 
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		lstring="                                                                                            ";
		text=Strings.rightstring(text, text.length()-60);
	  hstring=Strings.leftstring(text, 60);
	  lstring+=hstring;
  }
}

 
/* 
 * ----------------------------
 *  angemeldeter User
 * ----------------------------
 */
private String User;
/**
 * 
 * @return Username
 */
public String getUser()
{
	return User;
}
/**
 * 
 * @param User
 * sets Username displayed in Logfile
 */
public void setUser(String User ){
	this.User = User;
}

/* 
 * ----------------------------
 * Programmmode Live 
 * ----------------------------
 */
/**
 * 
 * @return actuall Programm mode
 * 0= Developent
 * 1= Live
 * @version 1.0
 * @author Andreas Tritt
 */
private int PrgMode;
/**
 * @param PrgMode
 * @info gets Programm mode
 * 0= Developent
 * 1= Live
 * @version 1.0
 * @author Andreas Tritt
 */
public int getPrgMode()
{
	return PrgMode;
}
/**
 * @param PrgMode
 * @info sets Programm mode
 * 0= Developent
 * 1= Live
 * @version 1.0
 * @author Andreas Tritt
 */
public void setPrgMode(int PrgMode){
	this.PrgMode = PrgMode;
}

/* 
 * ----------------------------
 * Constructor für Logfile 
 * ----------------------------
 */
/**
 * @param user - logged on user
 * @param sdir - dircetory for logfiles 
 * @info
 * creates logfiles (normal, error, control)
 * @version 1.0
 * @author Andreas Tritt
 */
 public  Logfile(String user,String sdir){
	this.User=user;
	this.separator = System.getProperties().getProperty("file.separator"); // wg Unterschied Linux Windows
	File dir = new File(System.getProperties().getProperty("user.home")+ this.separator + sdir );
	if (!(dir.exists() && dir.isDirectory()))
	{
		dir.mkdir();
	}
// --------- Logfiles generieren oder öffnen -------
	this.filenameError=System.getProperties().getProperty("user.home")+ this.separator + sdir + 
		this.separator  +"error.log";
	this.filenameNormal=System.getProperties().getProperty("user.home")+ this.separator + sdir + 
		this.separator  +"normal.log";
	this.filenameControl=System.getProperties().getProperty("user.home")+ this.separator + sdir + 
		this.separator  +"control.log";

	try
	{
		fwNormal = new java.io.FileWriter(filenameNormal,false);
		bwNormal = new java.io.BufferedWriter(fwNormal);

		fwControl = new java.io.FileWriter(filenameControl,true);
		bwControl = new java.io.BufferedWriter(fwControl);

		fwError = new java.io.FileWriter(filenameError,false);
		bwError = new java.io.BufferedWriter(fwError);

	} catch (IOException e)
	{
		e.printStackTrace();
	}
		
	this.writeLog('n',0, "Logfile initialisiert");
	this.writeLog('c',1, "");
	this.writeLog('c',1, "==============================");
	this.writeLog('c',1, "Start durch: "+ this.User);
}


 
}
