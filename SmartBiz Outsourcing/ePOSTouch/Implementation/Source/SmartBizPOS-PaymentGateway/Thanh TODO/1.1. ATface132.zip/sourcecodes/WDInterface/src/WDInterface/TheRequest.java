package WDInterface;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import atTools.*;


class TheRequest extends Thread
{
	String urlZw;
	String user;
	String pass;
	JTextArea ReqText;
	JTextArea ResText;
	JTextField Status;
	JButton button;
	
	public void run()
	{
		button.setVisible(false);
		runRequest();

	}
	public void setURL(String URL)
	{
		urlZw=URL;
	}
	public void setUser(String USER)
	{
		user=USER;
	}
	public void setPass(String PASS)
	{
		pass=PASS;
	}
	public void setReqText(JTextArea qText)
	{
		ReqText=qText;
	}
	public void setResText(JTextArea sText)
	{
		ResText=sText;
	}
	public void setStatus(JTextField stat)
	{
		Status=stat;
	}
				
	private boolean runRequest()
	{
		String poststring="";
		String contentype;
		long start = System.currentTimeMillis();
		
		try 
		{
			contentype="text/xml; charset=\"UTF-8\"";//"text/xml";
			ResText.setText(PV.LMeldungen[35]+"\n");
			
			poststring = ReqText.getText();
	    URL url = new URL(urlZw);
	    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	    conn.setDoOutput(true);
      conn.setRequestProperty("Content-Type",contentype );
      if(!conn.getDoOutput())
      {
      	 conn.setDoOutput(true);
      }
       
      conn.setRequestProperty("Content-Length", String.valueOf(poststring.length() ));
      if ((pass.length()==0)==true)
      {
      	conn.setRequestProperty("SOAPAction", "");
      }
      else
      {
        conn.setRequestProperty("Authorization", "Basic "+ encrypt(user+":"+pass));
      }
      conn.setRequestMethod("POST");
	    conn.setReadTimeout(30000);

      OutputStream wr = conn.getOutputStream();
      wr.write(poststring.getBytes("UTF8"));
	    wr.flush();
	    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	    String line;
	    while ((line = rd.readLine()) != null) 
	    {
	        // Process line...
	    	line=replace(line,"><",">\n\r<");
	    	line=replace(line,"> <",">\n\r<");
	    	line=replace(line,"\t","    ");
	    	ResText.append(line+"\n");
        if ((ResText.getText().contains("PENDING")==true)||
        		(ResText.getText().contains("ACK")==true)||
        		(ResText.getText().contains("Transaction is Acknowledged")==true)||
        		(ResText.getText().contains("Successful")==true))
        {
        	Status.setBackground(Color.green);
        }
        else
        {
        	Status.setBackground(Color.red);
        }
	    }
	    wr.close();
	    rd.close();
	    long elapsedTimeMillis = System.currentTimeMillis()-start;
	    //benötigte Zeit
	    ResText.append(PV.LMeldungen[10]+ String.valueOf(elapsedTimeMillis)+ "ms");
	    ResText.setCaretPosition(ResText.getDocument().getLength());
		} 
		catch(Exception e)
		{
			//Fehler beim Senden des Requests: %1 an %2 Exception %3 
			PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[23],new String[]{poststring,urlZw,e.toString()});
			ResText.append(Strings.mix("\n"+PV.LFehlerMeldungen[23],new String[]{"\n"+poststring,"\n"+urlZw,"\n"+e.toString()}));
			Status.setBackground(Color.red);
			button.setVisible(true);
			return false;
		}
		button.setVisible(true);
		return true;
	}
	
	private String encrypt(String str)
	{
    try 
    {
        // Encode the string into bytes using utf-8
        byte[] utf8 = str.getBytes("UTF8");

        // Encode bytes to base64 to get a string
        return new sun.misc.BASE64Encoder().encode(utf8);
    } 
    catch (UnsupportedEncodingException e) 
    {
    }
    return null;
	}
	
  private String replace(String str, String pattern, String replace) 
  {
    int s = 0;
    int e = 0;
    try
    {
	    StringBuffer result = new StringBuffer();
	
	    while ((e = str.indexOf(pattern, s)) >= 0) {
	        result.append(str.substring(s, e));
	        result.append(replace);
	        s = e+pattern.length();
	    }
	    result.append(str.substring(s));
	    return result.toString();
    }
  	catch(Exception es)
  	{
  		//Fehler bei replace von %1 durch %2 in %3 Exception %4 
  		PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[25],new String[]{pattern,replace,str,es.toString()});
  		return "";
  	}

  }

	public void setButton(JButton btn)
	{
		button=btn;
	}
    
}