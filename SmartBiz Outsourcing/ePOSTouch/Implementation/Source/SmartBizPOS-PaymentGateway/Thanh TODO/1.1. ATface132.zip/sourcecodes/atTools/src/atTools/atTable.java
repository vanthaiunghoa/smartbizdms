package atTools;
//import java.awt.GridBagConstraints;
//import java.awt.Insets;
//import java.awt.event.MouseAdapter;
//import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;

import javax.swing.*;
//import javax.swing.table.*;
import java.text.ParseException;



public class atTable extends JTable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2047386314380629760L;
	public atTableModel tableModel ;
	public ListSelectionModel selectionModel;
	private atTableModel filterTableModel ;
	public atTableModel aktModel;

	
	private java.sql.ResultSet rst;
	private atColumnF[] Columns;
	private String[] Source;
	private javax.swing.table.TableColumn col; 
	int [] width;
	private boolean filterd=false;
	
	
	/**
	 * 
	 * @param Columns - array of atColumnF, containing description of Columns
	 * @param Ziel - where tabele should be displaned, normaly a JPane

	 * @info
	 * extends JTable <br>
	 * creates Table without data comming from rs<br>
	 * sets width and header of each column 
	 * @version 1.0
	 * @author Andreas Tritt
	 */
	public atTable(atColumn[] Columns,JScrollPane Ziel)
	{
		generateTable(Columns,Ziel);
	}
//siehe auch Status 31.12.2007 19:00
	
	/**
	 * 
	 * @param Columns - array of atColumnF, containing description of Columns
	 * @param Ziel - where tabele should be displaned, normaly a JPane
	 * @param rs - source of data
	 * @info
	 * extends JTable <br>
	 * creates Table with data comming from rs<br>
	 * sets width and header of each column 
	 * @version 1.0
	 * @author Andreas Tritt
	 */
	
	public atTable(atColumnF[] Columns,JScrollPane Ziel,java.sql.ResultSet rs)
	{
		generateTableF(Columns,Ziel,rs);
	}

	
	/**
	 * 
	 * @param Columns - array of atColumnF, containing description of Columns and input Fields
	 * @param Ziel - where tabele should be displaned, normaly a JPane
	 * @param rs - source of data
	 * @info
	 * extends JTable <br>
	 * creates Table with data comming from rs<br>
	 * sets width and header of each column 
	 * @version 1.0
	 * @author Andreas Tritt
	 */
	public atTable(atColumnG[] Columns,JScrollPane Ziel,java.sql.ResultSet rs)
	{
		int len = Columns.length;
		atColumnF[] TColumn;
		atColumnF T2Column;
		
	//	TColumn= new atColumnF[len];
//		String[] test = new String[] {"",""};
		
	  T2Column=new atColumnF (1,"a",20,"b"); 
	  //atColumnF[] TColumn  =new atColumnF[] {T2Column,T2Column};
	TColumn = new atColumnF[len];
//	TColumn[0]=T2Column;	
//	TColumn[1]=T2Column;	
		
          
    for (int a=0;a<len;a++)
    {
    	TColumn[a]=new atColumnF(1,"a",2,"b")    ;//T2Column;	
    	TColumn[a].field=Columns[a].field;
    	TColumn[a].header=Columns[a].header;
    	TColumn[a].position=Columns[a].position;
    	TColumn[a].width=Columns[a].width;
    }
		
		generateTableF(TColumn,Ziel,rs);
		

	}

	
	
	/**
	 * @param Columns
	 * @param Ziel
	 * @param resultset
	 * @info Interne Methode die das eigentliche Erstellen der Tabelle und Füllen mit Daten 
	 * übernimmt, benötigt generateTable
	 */
	private void generateTableF(atColumnF[] Columns,JScrollPane Ziel,java.sql.ResultSet rs)
	{
		// Werte in Class-local Variablen wegspeichern
		this.rst=rs;
		this.Columns=Columns;
		int length=this.Columns.length;
		int pos;
		Source=new String[length];
		atColumn[] Col=new atColumn[length];
		
		// Aufbau der Tabellenstruktur
		for (int a=0;a< length;a++)
		{
			pos=Columns[a].position;
			Col[a]=new atColumn(0,"",0);
	  	Col[a].header=Columns[a].header;
			Col[a].position=Columns[a].position;
			Col[a].width=Columns[a].width;

			// Anpassung der anderen Felder an Position erfolgt in Methode generateTable
			Source[pos]=Columns[a].field;
		}
		
		generateTable(Col,Ziel);



		
		try
		{
			int colNo = Source.length;
			rs.beforeFirst();
			while(rs.next())
			{
				 Object[] objects = new Object[colNo];
				 for(int i=0;i<colNo;i++)
				 {
				   if (rs.getObject(Source[i]).toString().compareTo(", ")==0)
				   {
						 objects[i]="";//rs.getObject(Source[i]);// i+1);
				   }
				   else
				   {
					 objects[i]=rs.getObject(Source[i]);// i+1);
				   }
				 }
				 this.tableModel.addRow(objects);
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}

	}
	
	/**
	 * @param Columns
	 * @param Ziel
	 * @info Interne Methode die das eigentliche Erstellen der Tabelle übernimmt
	 */
	private void generateTable(atColumn[] Columns,JScrollPane Ziel)
	{
		int pos;
		int length=Columns.length;
		width= new int [length];
		String[] header = new String[length];
		
		for (int a=0;a<length;a++)
		{
			pos=Columns[a].position;
			width[pos]=Columns[a].width;
			header[pos]=Columns[a].header;
		}
		
		
		new JTable();

			tableModel=	new atTableModel(
					new String[][] {},
					header);
			aktModel=	new atTableModel(
					new String[][] {},
					header);
			aktModel=tableModel;
			setModel(aktModel);


			
			this.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			Ziel.setViewportView(this);
			setwidth();
			filterTableModel= new atTableModel(
  				new String[][] {},
					header);

			this.setColumnSelectionAllowed(false);
			this.setRowSelectionAllowed(true);
			
			selectionModel =  this.getSelectionModel();


	/*JTextArea		textarea1 = (JTextArea)this.getEditorComponent();
		   textarea1.setEditable(false);
*/
	}

	/**
	 * 
	 * @param searchParam
	 * @info
	 * filters Table according to searchParam: <br> 
	 * @version 1.0
	 * @author Andreas Tritt
	 */
	public void filterTable(atSearchParam[] searchParam,java.sql.ResultSet rst)
	{
		int newcount=0;
  	filterTableModel.setRowCount(0);
		int colNo = Source.length;
		try
		{
			rst.beforeFirst();
			while(rst.next())
			{  
	      if (isOK(searchParam))
//	Wenn Wert Bedingung entspricht zu neuem Model (filterTableModel) hinzufügen			
				{
				  newcount++;
					Object[] objects = new Object[colNo];
					for(int i=0;i<colNo;i++)
				  {
				    objects[i]=rst.getObject(Source[i]);// i+1);
				  }
					this.filterTableModel.addRow(objects);
				}
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		aktModel=filterTableModel; // aktModel (aktuelles) Model immer nach aussen hin aktiv,um Zugriffe einfacher zu gestatten.
		this.setModel(aktModel); 
		filterd=true;
		setwidth();
		this.updateUI();
	}
	
/**
 * @param searchParam
 * @return
 * @info prüft ob aktueller Datensatz aus Hilfs-Recordset rst den Bedingungnen entspricht
 */
	private boolean isOK(atSearchParam[] searchParam)
	{
	  boolean result=true;
	  String rsString="";
	  String searchString="";
	  
	  for (int a=0;a<searchParam.length;a++)
	  {
	  	try
			{
	  		rsString=rst.getObject(searchParam[a].field.toString()).toString();
				searchString=searchParam[a].value.toString();

				try
				{ // Ist Zeit
					SimpleDateFormat tdf=new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss.S");//("dd.mm.yyyy HH.MM");
					Long dd=tdf.parse(searchString).getTime();
					Long dd2=tdf.parse(rsString).getTime();
					if (searchParam[a].getcomparetype()==-1)
					{
						if (dd<=dd2) 
						{
							//stimmt
						}
						else
						{
			  			result=false;
			  			return false;
						}
					}
					if (searchParam[a].getcomparetype()==0)
					{
						if (dd==dd2)
						{
							//stimmt
						}
						else
						{
			  			result=false;
			  			return false;
						}
					}
					if (searchParam[a].getcomparetype()==1)
					{
						if (dd>=dd2)
						{
							//stimmt
						}
						else
						{
			  			result=false;
			  			return false;
						}
					}
				}
				catch (ParseException e) //Ist keine Zeit
				{
					try
					{  // Ist double
		 		    NumberFormat formatter = new DecimalFormat("0.00");
				    formatter = new DecimalFormat("0.00");
				    double zahl = Double.valueOf(formatter.parseObject(searchString.replace(".", ",")).toString());
				    double zahl2 = Double.valueOf(formatter.parseObject(rsString.replace(".", ",")).toString());
						if (searchParam[a].getcomparetype()==-1)
						{
							if (zahl<=zahl2) 
							{
								//stimmt
							}
							else
							{
				  			result=false;
				  			return false;
							}
						}
						if (searchParam[a].getcomparetype()==0)
						{
							if (zahl==zahl2)
							{
								//stimmt
							}
							else
							{
				  			result=false;
				  			return false;
							}
						}
						if (searchParam[a].getcomparetype()==1)
						{
							if (zahl>=zahl2)
							{
								//stimmt
							}
							else
							{
				  			result=false;
				  			return false;
							}
						}
					}
					catch (ParseException f) // ist auch kein Double
					{
						rsString=rsString.toUpperCase();
						searchString=searchString.toUpperCase();
				  	if (searchParam[a].method)
				  	{
				  		// ist gleich
				  		System.out.println("V2");
							if ((searchString.compareTo(rsString)*searchParam[a].getcomparetype())>=0)//  0)
							{
								// stimmt
							}
							else
							{
								//stimmt nicht
								result=false;
								return false;
							}
				  	}
				  	else
				  	{
				  		// enthält
				  		if (rsString.contains(searchString))
				  		{
				  			//stimmt
				  		}
				  		else
				  		{
				  			//stimmt nicht
				  			result=false;
				  			return false;
				  		}
				  	}
					}
				}	
			} catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


	  }
	  		
	  
		return result;
	}
	
	/**
	 * Hebt Filter wieder auf 
	 */
	public void unfilterTable()
	{
		aktModel=tableModel;
		this.setModel(aktModel);
		filterd=false;
		setwidth();
		this.updateUI();
	}
	


	/**
	 * Setzt Spaltenbreite
	 */
	private void setwidth()
	{
		for (int vColIndex=0;vColIndex<this.getColumnCount();vColIndex++)
		{
			col=this.getColumnModel().getColumn(vColIndex);
			col.setPreferredWidth(width[vColIndex]);
		}
	}

	/**
	 * @param row
	 * @param col(umn) - 
	 * @return always false
	 * @info makes complete table not editable
	 * @version 1.0
	 * @author Andreas Tritt
	 */

	public boolean isCellEditable(int row, int col) 
	{
		return false;
	}

	public void setRst (java.sql.ResultSet rst)
	{
		this.rst=rst;
	}

	public boolean getfilterd()
	{
		return this.filterd;
	}

}

