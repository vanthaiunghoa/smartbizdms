package atTools;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;


import java.awt.Color;
import java.awt.FlowLayout;


public class atErrorDialog_alt extends javax.swing.JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2793884100993480777L;
	private JPanel main;
	private JPanel buttonBar;
	private JPanel center;
	private JButton bOK;



	public atErrorDialog_alt(JFrame frame,boolean modal, int resx, int resy,String text) {
		super(frame,modal);
		initGUI(text, resx,resy);
	}
	
	private void initGUI(String Meldungstext,int resx, int resy) {
		int x;
		int y;
		String[] mtext= new String[20];

		try {
			{
				main = new JPanel();
				BorderLayout mainLayout = new BorderLayout();
				getContentPane().add(main, BorderLayout.CENTER);
				main.setLayout(mainLayout);
				{
					center = new JPanel();
					FlowLayout centerLayout = new FlowLayout();
					main.add(center, BorderLayout.CENTER);
					center.setLayout(centerLayout);
					setSize(401, 301);
					x=(int)(resx-this.getWidth())/2;
					y=(int)(resy-this.getHeight())/2;
					this.setLocation(x,y);
					
					mtext=cutToLen(Meldungstext,40);
					JLabel[] Meld = new JLabel[20];
					
					for (int a=0;a<10;a++)
					{
						Meld[a]=new JLabel();
						center.add(Meld[a]);
						Meld[a].setForeground(Color.RED);
						Meld[a].setText(mtext[a]);
						Meld[a].setFont(new java.awt.Font("Andale Mono",1,14));
					}
	
				}
				{
					buttonBar = new JPanel();
					main.add(buttonBar, BorderLayout.SOUTH);
					buttonBar.setPreferredSize(new java.awt.Dimension(390, 37));
					{
						bOK = new JButton();
						buttonBar.add(bOK);
						bOK.setText("OK");
						bOK.setPreferredSize(new java.awt.Dimension(74, 29));
						bOK.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent evt) {
								System.out.println("bOK.actionPerformed, event="+evt);
								dispose();
							}
						});
					}
				}
			}
			setSize(400, 300);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String[] cutToLen(String text, int len)
	{
		String[] ergebnis;
		ergebnis=new String[] {"","","","","","","","","",""};
		String hstring="";
		int anzahl=0;
		int found=0;
		text+=" ";
		while (text.length()>0 && anzahl <10)
		{
			found=text.indexOf(" ");

			hstring=atTools.Strings.leftstring(text,found+1);
			text=atTools.Strings.rightstring(text, text.length()-found-1);
			if ((ergebnis[anzahl].length() +hstring.length()>40) && ergebnis[anzahl].length()>0 ) anzahl++;
			ergebnis[anzahl]=ergebnis[anzahl]+hstring;
		}
		
		return ergebnis;
	}
}
