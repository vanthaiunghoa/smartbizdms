package WDInterface;

import javax.swing.UIManager;

public class atUIManager extends javax.swing.UIManager
{
	static String w001;
	static String w002;
	static String w003;
	static String w004;
	static String w005;
	static String w006;
	static String w007;
	static String w008;
	static String w009;
	static String w010;
	static String w011;
	static String w012;
	static String w013;
	static String w014;
	static String w015;
	static String w016;
	static String w017;
	static String w018;
	static String w019;
	static String w020;
	static String w021;
	static String w022;
	static String w023;
	static String w024;
	static String w025;
	static String w026;
	static String w027;
	static String w028;
	
	static String w101;
	static String w102;
	static String w103;
	static String w104;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 23988047859722806L;
	
	public static Object put(Object key,Object value)
	{
		UIManager.put(key, value);
		return key;
	}
	
	public static void saveValues()
	{
//Weiter Infos /Y_Computer/Programmierung/Backup/defaultsUiManager		
		
		
		w101=UIManager.getString("OptionPane.okButtonText");
		w102=UIManager.getString("OptionPane.yesButtonText");
		w103=UIManager.getString("OptionPane.noButtonText");
		w104=UIManager.getString("OptionPane.cancelButtonText");

	
		w001=UIManager.getString("FileChooser.cancelButtonText");
		w002=UIManager.getString("FileChooser.cancelButtonToolTipText");
		w003=UIManager.getString("FileChooser.detailsViewButtonToolTipText");
		w004=UIManager.getString("FileChooser.fileNameLabelText");
		w005=UIManager.getString("FileChooser.filesOfTypeLabelText");
		w006=UIManager.getString("FileChooser.listViewButtonToolTipText");
		w007=UIManager.getString("FileChooser.lookInLabelText");
		w008=UIManager.getString("FileChooser.newFolderToolTipText");
		w009=UIManager.getString("FileChooser.openButtonText");
		w010=UIManager.getString("FileChooser.openDialogTitleText");
		w011=UIManager.getString("FileChooser.upFolderToolTipText");
		w012=UIManager.getString("FileChooser.acceptAllFileFilterText");
		w013=UIManager.getString("FileChooser.detailsViewButtonAccessibleName");
		w014=UIManager.getString("FileChooser.directoryDescriptionText");
		w015=UIManager.getString("FileChooser.fileDescriptionText");
		w016=UIManager.getString("FileChooser.helpButtonText");
		w017=UIManager.getString("FileChooser.helpButtonToolTipText");
		w018=UIManager.getString("FileChooser.homeFolderAccessibleName");
		w019=UIManager.getString("FileChooser.homeFolderToolTipText");
		w020=UIManager.getString("FileChooser.listViewButtonAccessibleName");
		w021=UIManager.getString("FileChooser.newFolderAccessibleNam");
		w022=UIManager.getString("FileChooser.newFolderErrorText");
		w023=UIManager.getString("FileChooser.openButtonToolTipText");
		w024=UIManager.getString("FileChooser.saveButtonText");
		w025=UIManager.getString("FileChooser.saveButtonToolTipText");
		w026=UIManager.getString("FileChooser.updateButtonText");
		w027=UIManager.getString("FileChooser.updateButtonToolTipText");
		w028=UIManager.getString("FileChooser.upFolderAccessibleName");
		
		

	}
	
	public static void restoreValues()
	{
		UIManager.put("OptionPane.okButtonText",w101);
		UIManager.put("OptionPane.yesButtonText",w102);
		UIManager.put("OptionPane.noButtonText",w103);
		UIManager.put("OptionPane.cancelButtonText",w104);

		UIManager.put("FileChooser.cancelButtonText",w001);
		UIManager.put("FileChooser.cancelButtonToolTipText",w002);
		UIManager.put("FileChooser.detailsViewButtonToolTipText",w003);
		UIManager.put("FileChooser.fileNameLabelText",w004);
		UIManager.put("FileChooser.filesOfTypeLabelText",w005);
		UIManager.put("FileChooser.listViewButtonToolTipText",w006);
		UIManager.put("FileChooser.lookInLabelText",w007);
		UIManager.put("FileChooser.newFolderToolTipText",w008);
		UIManager.put("FileChooser.openButtonText",w009);
		UIManager.put("FileChooser.openDialogTitleText",w010);
		UIManager.put("FileChooser.upFolderToolTipText",w011);
		UIManager.put("FileChooser.acceptAllFileFilterText",w012);
		UIManager.put("FileChooser.detailsViewButtonAccessibleName",w013);
		UIManager.put("FileChooser.directoryDescriptionText",w014);
		UIManager.put("FileChooser.fileDescriptionText",w015);
		UIManager.put("FileChooser.helpButtonText",w016);
		UIManager.put("FileChooser.helpButtonToolTipText",w017);
		UIManager.put("FileChooser.homeFolderAccessibleName",w018);
		UIManager.put("FileChooser.homeFolderToolTipText",w019);
		UIManager.put("FileChooser.listViewButtonAccessibleName",w020);
		UIManager.put("FileChooser.newFolderAccessibleNam",w021);
		UIManager.put("FileChooser.newFolderErrorText",w022);
		UIManager.put("FileChooser.openButtonToolTipText",w023);
		UIManager.put("FileChooser.saveButtonText",w024);
		UIManager.put("FileChooser.saveButtonToolTipText",w025);
		UIManager.put("FileChooser.updateButtonText",w026);
		UIManager.put("FileChooser.updateButtonToolTipText",w027);
		UIManager.put("FileChooser.upFolderAccessibleName",w028);

	}
}
