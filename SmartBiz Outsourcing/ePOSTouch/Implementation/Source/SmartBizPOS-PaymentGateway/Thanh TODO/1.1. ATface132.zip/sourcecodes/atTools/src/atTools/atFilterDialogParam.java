package atTools;

public class atFilterDialogParam
{

	/*
 * (non-javadoc)
 */
private String Label;
 
/**
 * Getter of the property <tt>Label</tt>
 *
 * @return Returns the Label.
 * 
 */
public String getLabel()
{
	return Label;
}

/**
 * Setter of the property <tt>Label</tt>
 *
 * @param Label The Label to set.
 *
 */
public void setLabel(String Label ){
	this.Label = Label;
}

/*
 * (non-javadoc)
 */
private String Type;
 
/**
 * Getter of the property <tt>Type</tt>
 *
 * @return Returns the Type.
 * 
 */
public String getType()
{
	return Type;
}

/**
 * Setter of the property <tt>Type</tt>
 *
 * @param Type The Type to set.
 *
 */
public void setType(String Type ){
	this.Type = Type;
}

/*
 * (non-javadoc)
 */
private int Nr;
 
/**
 * Getter of the property <tt>Nr</tt>
 *
 * @return Returns the Nr.
 * 
 */
public int getNr()
{
	return Nr;
}

/**
 * Setter of the property <tt>Nr</tt>
 *
 * @param Nr The Nr to set.
 *
 */
public void setNr(int Nr )
{
	this.Nr = Nr;
}

private String Feldname;
public String getFeldname()
{
	return Feldname;
}
public void setFeldname(String Feldname)
{
	this.Feldname=Feldname;
}

/**
 * @param Nr - lfd. Nr, auch zum finden in der Tabelle Vorgaben
 * @param Label - Beschriftung für Reihe
 * @param method - false: field contains value   
 * @param method - true: field is exactly value  
 * @param type - Typ of InputField<br> 
 * Str = String<br>
 * Int = Integer<br>
 * CmB = ComboBox<br>
 * Bol = Boolean<br>
 * Prc = Price<br>
 * Dat = Date<br>
 * @version 1.0
 * @author Andreas Tritt
 */
public atFilterDialogParam(int Nr, String Label,String Type,String Feldname)
{
	this.Nr=Nr;
	this.Label=Label;
	this.Type=Type;
	this.Feldname=Feldname;
}


}
