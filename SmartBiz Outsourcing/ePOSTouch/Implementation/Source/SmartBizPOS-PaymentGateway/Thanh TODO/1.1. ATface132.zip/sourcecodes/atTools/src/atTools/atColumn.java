package atTools;

public class atColumn
{

	public String header;

public int width;
public int position;

/**
 * @param int Position: Column No starting with 0 
 * @param String Header: Column Header
 * @param int Width: Column Width
 * @info
 * Constructor of atColumn
 * creates object to contain information about TableModel
 * array of atColumn or atColumnF is needed for atTable
 * @version 1.0
 * @author Andreas Tritt
 */
public atColumn(int Position, String Header, int Width){

	
	this.header=Header;
	this.width=Width;
	this.position=Position;
}


}
