package WDInterface;

import java.awt.Color;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import atTools.Strings;


public class VTRun
{
BufferedWriter put;
BufferedReader in ;
String cfileWrite;
String cfileRead;
String response;


private String login;
private String pass;

	public VTRun()
	{

	}
	
	public void run(String strURL,JButton btn)
	{
		btn.setVisible(false);
		try
		{
			PV.textVT.setText("");
			PV.ml.writeLog('n', 1, PV.LMeldungen[1]);
			// create Variables
			createRequest();
		  // send Request
			PV.ml.writeLog('n', 1, PV.LMeldungen[9]);
		  send(strURL);
			
			if (response.equals("401"))
			{
				//wrong Password or User
				JOptionPane.showMessageDialog(new JFrame(),Strings.cutToLen(PV.LFehlerMeldungen[1],40) ,"error",JOptionPane.ERROR_MESSAGE);
			}
			else
			{
			}

      if ((response.contains("PENDING")==true)||(response.contains("ACK")==true)||(response.contains("Transaction is Acknowledged")==true)||(response.contains("Successful")==true))
      {
      	PV.tVtStatus.setBackground(Color.green);
      }
      else
      {
      	PV.tVtStatus.setBackground(Color.red);
      }
		}
		catch(Exception e)
		{
			//error %1
			PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[2],new String[]{e.toString()});
		}
		btn.setVisible(true);
	}
	
	
	private void createRequest()
	{
		int found;
	  PV.BatchReqStringcomplete=PV.BatchReqStringVar;
	  try
	  {
			for (int i=1;i<=PV.ReqVarNo;i++)
			{
				found=PV.BatchReqStringcomplete.indexOf(PV.ReqVar[i]);
				if (found>0)
				{
					PV.BatchReqStringcomplete=Strings.leftstring(PV.BatchReqStringcomplete,found)+PV.VtText[i].getText()+Strings.rightstring(PV.BatchReqStringcomplete, PV.BatchReqStringcomplete.length()-found-PV.ReqVar[i].length());
				}
				else
				{
				}
			}
	  }
		catch(Exception e)
		{
			PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[3],new String[]{e.toString()});
		}
	}
	
	private boolean send(String strURL)
	{
		
		String contentype;
		String poststring;
		
		long start = System.currentTimeMillis();
	
		try 
		{
			contentype="text/xml; charset=\"UTF-8\"";//"text/xml";
	
			poststring = PV.BatchReqStringcomplete;
//			System.out.println("POSTSTRING:\n"+poststring+"\n");
	    URL url = new URL(strURL);
	    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	    conn.setDoOutput(true);
      conn.setRequestProperty("Content-Type",contentype );
    	PV.textVT.append("\n##################\nRequest:\n");
    	PV.textVT.append(poststring+"\n");
    	PV.textVT.append("Response:\n");

      if(!conn.getDoOutput())
      {
      	 conn.setDoOutput(true);
      }
      conn.setRequestProperty("Content-Length", String.valueOf(poststring.length() ));
//	    System.out.println("www");

      if ((pass.length()==0)==true)
      {
      	conn.setRequestProperty("SOAPAction", "");
      }
      else
      {
        conn.setRequestProperty("Authorization", "Basic "+ encrypt(login+":"+pass));
      }
      conn.setRequestMethod("POST");
      OutputStream wr = conn.getOutputStream();
      wr.write(poststring.getBytes("UTF8"));
	    wr.flush();
	    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	    String line;
	    response="";
//	    System.out.println("w4");

	    while ((line = rd.readLine()) != null) 
	    {
//	    	System.out.println("Line= "+line);
	    	response+=Strings.trim(line);
	        // Process line...
	    	line=replace(line,"><",">\n\r<");
	    	line=replace(line,"> <",">\n\r<");
	    	line=replace(line,"\t","    ");
	    	PV.textVT.append(line+"\n");
    	}
	    System.out.println(response);
	    wr.close();
	    rd.close();
	    long elapsedTimeMillis = System.currentTimeMillis()-start;
	    PV.textVT.append(PV.LMeldungen[10]+ String.valueOf(elapsedTimeMillis)+ "ms\n"); 
	    buildResponse();
		} 
		catch (Exception e) 
		{
			if (e.toString().contains("401"))
			{
			response="401";
			//Fehler: %1 Username or Password is wrong
			PV.ml.writeLog('m', 1, PV.LFehlerMeldungen[1]);
			}
			else
			{
				//Fehler: %1 
				PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[2],new String[]{e.toString()});
			}
		}
		return false;
	}
	
	
	private String replace(String str, String pattern, String replace) 
  {
    int s = 0;
    int e = 0;
    StringBuffer result = new StringBuffer();

    while ((e = str.indexOf(pattern, s)) >= 0) 
    {
        result.append(str.substring(s, e));
        result.append(replace);
        s = e+pattern.length();
    }
    result.append(str.substring(s));
    return result.toString();
  }
	
	private String encrypt(String str)
	{
    try 
    {
        // Encode the string into bytes using utf-8
        byte[] utf8 = str.getBytes("UTF8");
        // Encode bytes to base64 to get a string
        return new sun.misc.BASE64Encoder().encode(utf8);
    } 
    catch (UnsupportedEncodingException e) 
    {
    }
    return null;
}


	private String buildResponse()
	{
		String result="";
		String zw;
		
		
		int pos1,pos2;
		int len;
		int resLen=response.length();
		try
		{
			for (int i=1;i<=PV.ResVarNo;i++)
			{
				pos1=response.indexOf(PV.ResVar[i]);
				if (pos1>0)
				{
					len=PV.ResVar[i].length();
					zw=Strings.rightstring(response, resLen-pos1-len);
					pos2=zw.indexOf('<');
					PV.VtResText[i].setText(Strings.leftstring(zw, pos2));
					result+=";"+Strings.leftstring(zw, pos2);
				}
				else
					
				{
					PV.VtResText[i].setText("");
				}
			}
			return result;
		}
		catch(Exception e)
		{
			//Fehler beim Erstellen der Response Execption: %1 
			PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[5],new String[]{e.toString()});
			return "";
		}
	}

	public String getLogin()
	{
		return login;
	}

	public void setLogin(String login)
	{
		this.login = login;
	}

	public String getPass()
	{
		return pass;
	}

	public void setPass(String pass)
	{
		this.pass = pass;
	}


}
