package atTools;


import java.text.*;
import java.awt.*;

import javax.swing.ImageIcon;
import javax.swing.table.*;
 
public class BoolIconFormatRenderer2 extends DefaultTableCellRenderer 	 {
    /**
	 * 
	 */
	private static final long serialVersionUID = 7531981586779859504L;
		private Format formatter;
 
    public BoolIconFormatRenderer2(Format formatter) {
        if (formatter==null)
            throw new NullPointerException();
        this.formatter = formatter;
    }
 
    protected void setValue(Object obj) {
        setText(obj==null? "" : formatter.format(obj));
        if ( Integer.valueOf(this.getText().toString())==1)
        {
        	setBackground(Color.WHITE);
        	ImageIcon ii =new ImageIcon(getClass().getResource("/bitmaps/OKklein.png"));
        	this.setIcon(ii);
        	this.setText("");
        }
        else
        {
        	setBackground(Color.WHITE);
        	ImageIcon ii =new ImageIcon(getClass().getResource("/bitmaps/NOKklein.png"));
        	this.setIcon(ii);
        	this.setText("");
        }
        
    }
}