package WDInterface;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import atTools.Strings;

public class textDisplay extends javax.swing.JDialog 
{
	private JPanel panelHauptfeld;
	private JTextArea textAus;
	private int x;
	private int y;
	private JScrollPane sTDirToSave; 
	/**
	 * 
	 */
	private static final long serialVersionUID = -3701418931639887948L;

	public static void main(String[] args) 
	{
		SwingUtilities.invokeLater(new Runnable() 
		{
			public void run() 
			{
				textDisplay inst = new textDisplay();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public textDisplay() 
	{
		/* -------------------------------------------------------
		 * Hauptteil wird bei new aufgerufen
		 * -------------------------------------------------------*/
		super();
		x=1024;
		y=546;
		initGUI();
//		setSize(x, y);
		//TextDisplay ist initialisiert
		PV.ml.writeLog('n', 1, PV.LMeldungen[6]);
	}
	
	private void initGUI() 
	{
		int x=0;
		int y=0;
		try 
		{
			/*-------------------------------------------------------
			 * Fenster Configuration aufbauen
			 * -------------------------------------------------------*/
			this.setTitle("Configuration");
			this.setIconImage(new ImageIcon(getClass().getClassLoader().getResource("WDInterface/atface.png")).getImage());

			pack();
			this.setAlwaysOnTop(false);
			this.setModal(false);
//			this.setPreferredSize(new java.awt.Dimension(x, y));//(800, 600));
			{
				panelHauptfeld = new JPanel();
				FlowLayout layoutHauptfeld = new FlowLayout();
				panelHauptfeld.setLayout(layoutHauptfeld);
				getContentPane().add(panelHauptfeld, BorderLayout.CENTER);
//				panelHauptfeld.setPreferredSize(new java.awt.Dimension(x-10, y-30));
				{
					textAus = new JTextArea();
					sTDirToSave = new JScrollPane(textAus);
//					sTDirToSave.setPreferredSize(new java.awt.Dimension(x-20,y-50));
					
					panelHauptfeld.add(sTDirToSave);
					textAus.setText("TDirToSave");
				}
			}
/*			System.out.println(this.getParent().getWidth()+" "+this.getWidth()+" "+this.getParent().getX());
			x=(int)(this.getParent().getWidth()-this.getWidth())/3+this.getParent().getX();
			y=(int)(this.getParent().getHeight()-this.getHeight())/3+this.getParent().getY();
			this.setLocation(x,y);
*/		}
		catch (Exception e) 
		{
			PV.ml.writeLog('e', 1, e.toString());
		}
	}
	
	public boolean setText(String Titel,String Quelle)
	{
		return setText(Titel,Quelle,"");
	}
	
	public boolean setText(String Titel,String Quelle,String Insert)
	{
		return setText(Titel,Quelle,Insert,"");
	}

	
	public boolean setText(String Titel,String Quelle,String Insert,String Add)
	{
		this.setSize(x,y);
		panelHauptfeld.setPreferredSize(new java.awt.Dimension(x-10, y-30));
  	sTDirToSave.setPreferredSize(new java.awt.Dimension(x-20,y-50));
		
		String strh="";
		//Start Einlesen von %1
		PV.ml.writeLog('n', 1, PV.LMeldungen[7],Titel);
		textAus.setText("");//initialisieren
		try 
		{
//			String cfile=PV.langdir+PV.separator+PV.lang+".hlp";
			this.setTitle(Titel);
			PV.ml.writeLog('n', 0, "Titel gesetzt");
//			System.out.println(Quelle);
			BufferedReader in = new BufferedReader(new FileReader(Quelle));
			String str;
			while ((str = in.readLine()) != null) 
			{
				PV.ml.writeLog('n', 0, str);
				if (str.contains("%1")) str=Strings.mix(str, Insert);
				do
				{
					if (str.length()>PV.maxLenTexDisp)
					{
						strh=Strings.rightstring(str, str.length()-PV.maxLenTexDisp);
						str=Strings.leftstring(str, PV.maxLenTexDisp);
					}
					else
					{
						strh="";
					}
					textAus.append(str+"\n");	
					str=strh;
				}
				while (str.length()>0);
				
			}
			
			textAus.append(Add);
			PV.ml.writeLog('n', 0, "textAus.append(Add)"+Add);
			in.close();
			//Ende Einlesen von %1
			PV.ml.writeLog('n', 0, PV.LMeldungen[8],Titel);
			sTDirToSave.getVerticalScrollBar().setValue(0);
			sTDirToSave.getHorizontalScrollBar().setValue(0);
			return true;
		} 
		catch (IOException e) 
		{
			//Fehler beim Lesen aus Datei %1 Exception %2
			PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[4],new String[]{Quelle,e.toString()});
			return false;
		}
	}

	public void setX(int x2)
	{
		if (x2<x)
		{
			this.x = x2;
		}
	}

	public void setY(int y2)
	{
		if (y2<y)
		{
			this.y = y2;
		}
	}
	
}
