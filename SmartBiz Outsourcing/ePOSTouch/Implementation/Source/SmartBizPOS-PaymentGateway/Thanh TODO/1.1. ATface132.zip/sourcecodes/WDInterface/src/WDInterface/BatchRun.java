package WDInterface;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import atTools.Strings;
import atTools.*;


public class BatchRun
{
BufferedWriter put;
BufferedReader in ;
String cfileWrite;
String cfileRead;
String cfileRenamed;
String response;
boolean found=true;

	public BatchRun(String cfile)
	{
		try
		{
			cfileRead=cfile;
			cfileWrite=Strings.leftstring(cfile, cfile.length()-4)+"_"+String.valueOf(System.currentTimeMillis())+".csv";
			cfileRenamed=Strings.leftstring(cfile, cfile.length()-4)+".inuse";
			if (rename(cfileRead,cfileRenamed))
			{
				cfileRead=cfileRenamed;
				cfileRenamed=Strings.leftstring(cfile, cfileRead.length()-6)+".done";
				put = new BufferedWriter(new FileWriter(cfileWrite,true)); // true=append
				in = new BufferedReader(new FileReader(cfileRead));
			}
			else
			{
		  	JOptionPane.showMessageDialog(new JFrame(),Strings.cutToLen(Strings.mix(PV.LMeldungen[40],cfileRead),40) ,Strings.mix(PV.LMeldungen[40],cfileRead),JOptionPane.ERROR_MESSAGE);
		  	found=false;
			}
			
			
		}
		catch (IOException e) 
		{
			//Fehler beim Öffnen der Batch-Datei %1 Exception: %3 
			PV.ml.writeLog('m', 1,  PV.LFehlerMeldungen[13],new String[]{cfile,e.toString()});
		}

	}

	public void run(String strURL,JButton buttonStart,JButton buttonStop)
	{
		String input;
		PV.tRcRRRes.setText("");
		if (found)
		{
			try
			{
				if ((input = in.readLine()) != null)
				{
					put.write(NewHeader(input));
					put.newLine();
				}
				while ((input = in.readLine()) != null && !PV.stop)
				{
					// create Variables
					createRequest(input);
					// send Request
					send(strURL);
					// read Response Vars
					put.write(input+buildResponse());
					put.newLine();
				}
				put.close();
				in.close();
				//Batch run is finisched  - Succeess
				JOptionPane.showMessageDialog(new JFrame(),Strings.cutToLen(PV.LMeldungen[25],40) ,PV.LMeldungen[25],JOptionPane.INFORMATION_MESSAGE);
				if (rename(cfileRead,cfileRenamed))
				{
					System.out.println("File von "+cfileRead+" nach "+cfileRenamed+" umbenannt");
				}
				else
				{
					System.out.println("File "+cfileRead+" nicht umbenannt");
				}

			}
			catch (IOException e) 
			{
				//Fehler beim Processen  der Datei %1 an URL %2 Exception: %3
				PV.ml.writeLog('m', 1,  PV.LFehlerMeldungen[14], new String[]{cfileRead,strURL,e.toString()});
			}
		}
		buttonStart.setVisible(true);
		buttonStop.setVisible(false);
	}
	
	
	private String NewHeader(String Header)
	{
		int pos3;
		String zw2;
		
		try
		{
			for (int i=1;i<=PV.ResVarNo;i++)
			{
				zw2=PV.ResVar[i];
				pos3=zw2.indexOf("xsi");
				if (pos3>0==true)
				{
					zw2=Strings.leftstring(zw2,pos3);
				}
				pos3=zw2.indexOf("<");
//				System.out.println(zw2 +" "+pos3);
				if ((pos3>=0 && pos3<2)==true)
				{
//					System.out.println(zw2);
					zw2=Strings.rightstring(zw2,zw2.length()-1);
//					System.out.println(zw2);
				}
				pos3=zw2.indexOf(">");
//				System.out.println(zw2 +" "+pos3);
				if ((pos3>=0)==true)
				{
	//				System.out.println(zw2);
					zw2=Strings.leftstring(zw2,pos3);
//					System.out.println(zw2);
				}
	
				Header+=";"+zw2;
			}
			return Header;
		}
		catch(Exception e)
		{
			//New Header couldn't be created from %1 Execption %2
			PV.ml.writeLog('e', 1,  PV.LFehlerMeldungen[15], new String[]{Header,e.toString()});
			//"New Header couldn't be created"
			return PV.LMeldungen[27];
		}
	}
	
	
	private void createRequest(String data)
	{
		String restData=data;
		String aktData="";
		int pos=0;
		int found;
	  PV.BatchReqStringcomplete=PV.BatchReqStringVar;

	  try
	  {
			for (int i=1;i<=PV.ReqVarNo;i++)
			{
				pos=restData.indexOf(";");
				if (pos>-1==true)
				{
				aktData=Strings.leftstring(restData, pos);
				restData=Strings.rightstring(restData, restData.length()-pos-1);
				}
				else
				{
					aktData=restData;
				}
				found=PV.BatchReqStringcomplete.indexOf(PV.ReqVar[i]);
//				System.out.println(PV.ReqVar[i]+" - "+aktData);
				if (found>0)
				{
					PV.BatchReqStringcomplete=Strings.leftstring(PV.BatchReqStringcomplete,found)+aktData+Strings.rightstring(PV.BatchReqStringcomplete, PV.BatchReqStringcomplete.length()-found-PV.ReqVar[i].length());
				}
				else
				{
					if (PV.IR.isoneUser())
					{
						
					}
					else
					{
						if (PV.ReqVar[i].compareTo("httpsuser")==0) PV.BatchUser=aktData;
						if (PV.ReqVar[i].compareTo("httpspw")==0) PV.BatchPass=aktData;
					}
				}
			}
	  }
		catch(Exception e)
		{
			//New Request couldn't be created from %1 Execption %2
			PV.ml.writeLog('e', 1,  PV.LFehlerMeldungen[16], new String[]{data,e.toString()});
		}

	}
	
	private boolean send(String strURL)
	{
		String login;
		String pass;
		String contentype;
		String poststring;
		long start = System.currentTimeMillis();
		
		try 
		{
			login = PV.BatchUser;
			pass = PV.BatchPass;
			contentype="text/xml; charset=\"UTF-8\"";//"text/xml";
	
			poststring = PV.BatchReqStringcomplete;
//			System.out.println("\n"+poststring+"\n");
	    URL url = new URL(strURL);
	    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	    conn.setDoOutput(true);
      conn.setRequestProperty("Content-Type",contentype );
    	PV.tRcRRRes.append("\n##################\nRequest:\n");
    	PV.tRcRRRes.append(poststring+"\n");
    	PV.tRcRRRes.append("Response:\n");
    	PV.Counter ++;
    	PV.tCounter.setText(String.valueOf(PV.Counter));
      if(!conn.getDoOutput())
      {
      	 conn.setDoOutput(true);
      }
      conn.setRequestProperty("Content-Length", String.valueOf(poststring.length() ));
      if ((pass.length()==0)==true)
      {
      	conn.setRequestProperty("SOAPAction", "");
      }
      else
      {
        conn.setRequestProperty("Authorization", "Basic "+ encrypt(login+":"+pass));
      }
      conn.setRequestMethod("POST");
      OutputStream wr = conn.getOutputStream();
      wr.write(poststring.getBytes("UTF8"));
	    wr.flush();
	    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	    String line;
	    response="";

	    while ((line = rd.readLine()) != null ) 
	    {
	    	response+=line;
	        // Process line...
	    	line=replace(line,"><",">\n\r<");
	    	line=replace(line,"> <",">\n\r<");
	    	line=replace(line,"\t","    ");
	    	PV.tRcRRRes.append(line+"\n");
				PV.tRcRRRes.setCaretPosition(PV.tRcRRRes.getDocument().getLength());

    	}
	    wr.close();
	    rd.close();
	    long elapsedTimeMillis = System.currentTimeMillis()-start;
	    //"benötigte Zeit
	    PV.tRcRRRes.append(PV.LMeldungen[10]+ String.valueOf(elapsedTimeMillis)+ "ms\n"); 
		} 
		catch (Exception e) 
		{
			if (e.toString().contains("401"))
			{
			response="ww<GuWID>wrong Password or User</GuWID>";
			//wrong Password or User
			PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[1]);
			}
			else
			{
				//Fehler beim Senden der Anfrage: Exception %1
				PV.ml.writeLog('m', 1, PV.LFehlerMeldungen[17],new String[]{e.toString()});
			}
		}
		return false;
	}
	
	
	private String replace(String str, String pattern, String replace) 
  {
    int s = 0;
    int e = 0;
    StringBuffer result = new StringBuffer();

    while ((e = str.indexOf(pattern, s)) >= 0) 
    {
        result.append(str.substring(s, e));
        result.append(replace);
        s = e+pattern.length();
    }
    result.append(str.substring(s));
    return result.toString();
  }
	
	private String encrypt(String str)
	{
    try 
    {
        // Encode the string into bytes using utf-8
        byte[] utf8 = str.getBytes("UTF8");
        // Encode bytes to base64 to get a string
        return new sun.misc.BASE64Encoder().encode(utf8);
    } 
    catch (UnsupportedEncodingException e) 
    {
    }
    return null;
}


	private String buildResponse()
	{
		String result="";
		String zw;
		
		int pos1,pos2;
		int len;
		int resLen=response.length();
		try
		{
			for (int i=1;i<=PV.ResVarNo;i++)
			{
				pos1=response.indexOf(PV.ResVar[i]);
				if (pos1>0)
				{
					len=PV.ResVar[i].length();
					zw=Strings.rightstring(response, resLen-pos1-len);
					pos2=zw.indexOf('<');
					result+=";"+Strings.leftstring(zw, pos2);
				}
			}
			
			return result;
		}
		catch(Exception e)
		{
			//Fehler beim Erzeugen des Response Stringes aus: %1 Exception %2
			PV.ml.writeLog('m', 1,PV.LFehlerMeldungen[18] ,new String[]{response,e.toString()});
			return "";
		}

	}

	private boolean rename (String from, String to)
	{
		File f_from=new File(from);
		File f_to=new File(to);
		return f_from.renameTo(f_to);
	}
	
}
