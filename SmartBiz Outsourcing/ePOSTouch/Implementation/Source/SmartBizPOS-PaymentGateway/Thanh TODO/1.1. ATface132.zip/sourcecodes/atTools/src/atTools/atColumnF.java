package atTools;

public class atColumnF
{

public String header;

public int width;

public int position;

public String field;

/**
 * @param Position - Column No in Table, starting with 0
 * @param Header - Header of this Column
 * @param Width - Width of this Column
 * @param Field - Name of field from resultset, containing data to be displayed in this Column 
 * @info
 * Constructor of atColumnF
 * creates object to contain information about TableModel
 * array of atColumn or atColumnF is needed for atTable
 * @version 1.0
 * @author Andreas Tritt
 */
public atColumnF(int Position, String Header, int Width, String Field){
	this.header=Header;
	this.width=Width;
	this.position=Position;
	this.field=Field;
}


}
