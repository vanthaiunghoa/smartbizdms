package WDInterface;
import java.io.*;
import atTools.*;

public class langReader 
{
	private String dir;
	private String lang;
	
	public langReader()
	{
		
	}

	
	public void Reader(String dir,String lang)
	{ 
/*-------------------------------------------------------
* gewünschte Sprache und Verzeichnis setzen
* -------------------------------------------------------*/
		PV.ml.writeLog('n', 1, "Übergabe der Parameter Sprache und Verzeichnis");
		this.dir=dir;
		this.lang=lang;
	}
	
	public boolean ReadBereich(String Bereich)
	{
/*-------------------------------------------------------
* Sprachtexte für einen Bereich lesen
* -------------------------------------------------------*/
		try
		{
			PV.ml.writeLog('n', 1, "Start Einlesen der Sprachtexte fuer "+Bereich);
			int laenge=0;
			int counter=1;
			try 
			{
				String cfile=this.dir+PV.separator+this.lang+".lang";
				BufferedReader in = new BufferedReader(new FileReader(cfile));
				String str;
				while (((str = in.readLine()) != null) && !str.contains("["+Bereich+"]"))// Bereich suchen
				{
				}
				while ((str = in.readLine()) != null) // jetzt die Werte einlesen
				{
					if (Strings.leftstring(str, 6).compareTo("Anzahl")==0) // Anzahl der einzulesenden Parameter
					{
						laenge=Integer.parseInt(Strings.rightstring(str,str.length()-7));
						PV.langText=new String[laenge+1];
					}
					else
					{
						if (Strings.leftstring(str, 1).compareTo("[")==0) // hier beginnt ein neuer Bereich
						{
							break; // Alles eingelesen, verlassen
						}
						else
						{
							if  (Strings.leftstring(str, 1).compareTo("{")==0) // keine Überschrift auswerten
							{
								// Dies ist die Sub-Überschrift 
							}
							else
							{
								if (str.length()!=0)
								{
									PV.langText[Integer.parseInt(Strings.leftstring(str, 3))]=Strings.rightstring(str, str.length()-4);
								counter++;
								}
							}
						}
					}
				}
				in.close();
				if (laenge==0) // nichts eingelesen
				{
					PV.ml.writeLog('m', 1, "Datei "+dir+PV.separator+lang+".lang nicht vorhanden bei Bereich "+ Bereich);
					return false;
				}
					
				return true;
			} 
			catch (IOException e) 
			{
				// keine sprachspezifische Meldung, da hier die Sprachtexte erst geladen werden
				PV.ml.writeLog('m', 1, "Datei "+dir+PV.separator+lang+".lang nicht vorhanden bei Bereich "+ Bereich +" Exception: "+e.toString());
				return false;
			}
		}
		catch (RuntimeException  e)
		{
			PV.ml.writeLog('m', 1, e.toString());
			return false;
		}
	}  
}
