package atTools;



public class Strings
{
private static int len;

/**
 * 
 * @param string
 * @param leng
 * @return last (leng) characters of string
 * @version 1.0
 * @author Andreas Tritt
 */
public static String rightstring(String string, int leng)
	{
	if (leng<0)
	{
		return "";
	}
  len=string.length();
  if (len< leng)
  {
  	leng=len;
  }

	return string.substring(string.length()-leng, string.length());
}

/**
 * 
 * @param string
 * @param leng
 * @return first (leng) characters of string
 * @version 1.0
 * @author Andreas Tritt
 */
public static String leftstring(String string, int leng)
{
	len=string.length();
	if (len< leng)
	{
		leng=len;
	}
	return string.substring(0,leng);
}

/**
 * 
 * @param string
 * @param von
 * @param bis
 * @return bis characters of string starting at von
 * @version 1.0
 * @author Andreas Tritt
 */
public static String instring(String string, int von, int bis)
{
	len=string.length();
	if (len< bis)
	{
		bis=len;
	}
	if (von <0)
	{
		von=0;
	}
	return string.substring(von-1,bis);
	
}

/**
 * 
 * @param string
 * @return String converted from Password in string
 * @version 1.0
 * @author Andreas Tritt
 */
public static String toString(char[] pw)
{
	int lenpw=pw.length;
	int i;
	String result="";
	for (i=0; i<lenpw;i++)
	{
		result+=pw[i];
	}
	
	return result;
}

public static String leadString(String string,char lead,int len)
{
	String result="";
	for (int a=1;a<=len;a++)
	{
		result+=lead; // String mit Führungszeichen füllen
	}
	result+=string;
	result=rightstring(result,len);
	
	
	return result;
}

/**
 * 
 * @param MainText string - text to be filled up with Var
 * @param Var string []{"","",""} - text to be filled in MainText
 * @param Sample : Strings.mix(PV.LFehlerMeldungen[1],new String[]{cfile,Bereich,e.toString()})
 * @return String converted from MainText on position %1 ... %n String[n-1] is inserted
 * @version 1.0
 * @author Andreas Tritt
 */
public static String mix(String MainText, String[] Var)
{
//	String Ergebnis="";
	int pos;
	int count=0;
	
	while (Var.length>count)
	{
		pos=MainText.indexOf('%'+Integer.toString(count+1));
		if (pos>-1)
		{
			if (pos==0)
			{
				MainText=Var[count]+rightstring(MainText, MainText.length()-pos-2);
			}
			else
			{
			MainText=leftstring(MainText, pos)+Var[count]+rightstring(MainText, MainText.length()-pos-2);
			}
		}
		else
		{
			MainText=MainText+" "+Var[count];
		}
		count++;
		
	}

	return MainText;
}

public static String mix(String MainText, String Var)
{
	String Ergebnis="";
	int pos;
	pos=MainText.indexOf("%1");
	if (pos>-1)
	{
		if (pos==0)
		{
			Ergebnis=Var+rightstring(MainText, MainText.length()-pos-2);
		}
		else
		{
		Ergebnis=leftstring(MainText, pos)+Var+rightstring(MainText, MainText.length()-pos-2);
		}
	}
	else
	{
		Ergebnis=MainText;
	}
	return Ergebnis;
}

public static String cutToLen(String text, int len)
{
	String ergebnis;
	ergebnis="";
	String hstring="";
	String hstring2="";
	int anzahl=0;
	int found=0;
	text+=" ";
	while (text.length()>0 && anzahl <10)
	{
		found=text.indexOf(" ");

		hstring=atTools.Strings.leftstring(text,found+1);
		text=atTools.Strings.rightstring(text, text.length()-found-1);
		if ((hstring2.length() +hstring.length()>40) && hstring2.length()>0 )
		{
			anzahl++;
			hstring2+="\n";
			ergebnis+=hstring2;
			hstring2="";
		}
		hstring2+=hstring;
	}
	ergebnis+=hstring2;
	return ergebnis;
}

public static String trim(String text)
{
	int pos;
	while(text.indexOf("          ")>-1)
	{
		pos=text.indexOf("          ");
		text=leftstring(text,pos)+rightstring(text,text.length()-pos-9);
	}
	while(text.indexOf("     ")>-1)
	{
		pos=text.indexOf("     ");
		text=leftstring(text,pos)+rightstring(text,text.length()-pos-4);
	}
	while(text.indexOf("  ")>-1)
	{
		pos=text.indexOf("  ");
		text=leftstring(text,pos)+rightstring(text,text.length()-pos-1);
	}
	return text;
}

/**
 * 
 * @param Meldung - Gibt den Text mit System.out.println aus wenn
 * @param ProgMode = 0 ist
 * @return true
 * @version 1.0
 * @author Andreas Tritt
 */
public static boolean meldung (String Meldung, int ProgMode)
{
	if (ProgMode==0)
	{
		System.out.println(Meldung);
	}
	return true;
} 

}

