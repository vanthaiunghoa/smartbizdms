package atTools;

public class atCmbArray
{
/**
 * Column Text for Combobox
 */
public atCmbValue[] value; 




/**
 * @param Position - Column No in Table, starting with 0
 * @param Field - Name of field from resultset, containing data to be displayed in this Column
 * @version 1.0
 * @author Andreas Tritt
 */
public void InfoAboutClass()
{
	
}

public atCmbArray(atCmbValue[] Value){
	this.value=Value;
}


}
