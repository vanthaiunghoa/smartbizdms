package WDInterface;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import WDInterface.PV;
import atTools.Strings;


/**
 * 
 * @author Andreas Tritt
 *
 */


public class RequestReader
{
	String cfile; // file das Konfiguration enthält

	public RequestReader()
	{
	}
	
	
	/**
	 * @param sdir: Filename of file containing XML-Request
	 * @param Wert: true=read defaultWert, false=read VariableName
	 * @info
	 * reads XML-requests<br>
	 * @version 1.0
	 * @author Andreas Tritt
	 */
	public String readReqs(String sdir, boolean Wert)//Wert =true gibt, an dass die defaultWerte gelesen werden sollen, false = Variablennamen
	{
		String help1="";
		//Start Request Reader
		PV.ml.writeLog('n', 1, PV.LMeldungen[14]);
		try 
		{
			//Read Request: %1
			PV.ml.writeLog('n', 1, PV.LMeldungen[15],sdir);
			BufferedReader in = new BufferedReader(new FileReader(sdir));
			String str;
			while (((str = in.readLine()) != null) && !str.contains("[Request]"))// Bereich suchen
			{
			}

			
			while ((str = in.readLine()) != null)
			{
				if (Strings.leftstring(str, 1).compareTo("[")==0) // hier beginnt ein neuer Bereich
				{
					break; // Alles eingelesen, verlassen
				}
				else
				{
					str=deleteString(str, Wert);
					help1+=str+"\n";
				}
			}
			
			in.close();
		} 
		catch (IOException e) 
		{
			//Fehler beim Einlesen der Konfiguration aus Datei %1 für Bereich %2 Exception: %3
			PV.ml.writeLog('m', 1, PV.LFehlerMeldungen[7] ,new String[]{cfile,"readArea",e.toString()});
			return "";
		}
		PV.ml.writeLog('n', 0, " Request gelesen");
		return help1;
	}
	
	
	/**
	 * @param sdir: Filename of file containing XML-Request
	 * @param Area: RequestValue / RequestVars
	 * @info
	 * reads XML-requests<br>
	 * @version 1.0
	 * @author Andreas Tritt
	 */
	public String readReqs(String sdir, String Wert)//Wert =true gibt, an dass die defaultWerte gelesen werden sollen, false = Variablennamen
	{
		String help1="";
	//Start Request Reader
		PV.ml.writeLog('n', 1, PV.LMeldungen[14]);
		try 
		{
			//Read Request: %1
			PV.ml.writeLog('n', 1, PV.LMeldungen[15] ,sdir);
			BufferedReader in = new BufferedReader(new FileReader(sdir));
			String str;
			while (((str = in.readLine()) != null) && !str.contains("["+Wert+"]"))// Bereich suchen
			{
			}

			
			while ((str = in.readLine()) != null)
			{
				if (Strings.leftstring(str, 1).compareTo("[")==0) // hier beginnt ein neuer Bereich
				{
					break; // Alles eingelesen, verlassen
				}
				else
				{
					help1+=str+"\n";
				}
			}
			
			in.close();
		} 
		catch (IOException e) 
		{
			//Fehler beim Einlesen der Konfiguration aus Datei %1 für Bereich %2 Exception: %3
			PV.ml.writeLog('m', 1, PV.LFehlerMeldungen[7],new String[]{cfile,"readArea",e.toString()});
			return "";
		}
		//Request was read
		PV.ml.writeLog('n', 0, PV.LMeldungen[16]);
		return help1;
	}
	
	
	public void readReqVars(String sdir)//
	{
		PV.ReqVarNo=0;
		PV.ResVarNo=0;

		//Start Request Reader Vars
		PV.ml.writeLog('n', 1, PV.LMeldungen[17]);
		//Read Request: %1 
		PV.ml.writeLog('n', 1, PV.LMeldungen[15],sdir);

		try 
		{
			BufferedReader in = new BufferedReader(new FileReader(sdir));
			String str;
			while (((str = in.readLine()) != null) && !str.contains("[VarsReq]"))// Bereich suchen
			{
			}
			while ((str = in.readLine()) != null)
			{
				if (Strings.leftstring(str, 1).compareTo("[")==0 || (str.length()==0)) // hier beginnt ein neuer Bereich
				{
					if (str.contains("[VarsRes]")==true) // richtiger Bereich
					{
						//es braucht nichts getan zu werden 
					}
					else
					{
					  while (((str = in.readLine()) != null) && !str.contains("[VarsRes]"))// Bereich suchen
					  {
					  }
					}
					while ((str = in.readLine()) != null)
					{
						if (Strings.leftstring(str, 1).compareTo("[")==0 || str.length()==0) // hier beginnt ein neuer Bereich
						{
							break; // Alles eingelesen, verlassen
						}
						else
						{
							PV.ResVarNo++;
							PV.ResVar[PV.ResVarNo]=str;
						}
					}
				}
				else
				{
					if (PV.IR.isoneUser() && (str.compareTo("httpsuser")==0 || str.compareTo("httpspw")==00))
					{
						
					}
					else
					{
						PV.ReqVarNo++;
						PV.ReqVar[PV.ReqVarNo]=str;
					}
				}
			}
  		in.close();
		
		
		
		
		} 
		catch (IOException e) 
		{
			//Fehler beim Einlesen RequestReaderVars aus Datei %1 für Bereich %2 Exception: %3
			PV.ml.writeLog('m', 1,  PV.LFehlerMeldungen[8],new String[]{cfile,"readArea",e.toString()});
		}
		// Request Vars gelesen
		PV.ml.writeLog('n', 0, PV.LMeldungen[18]);
	}
	

	
	public String deleteString(String source, boolean Art)
	{
		try
		{
		String help1="";
		String help2="";
		String help3="";
		String helpRest="";
		String result="";
		String trenner="##";
		int pos, len;
		result=source;
		len=trenner.length();
		pos=source.indexOf(trenner);
		if (pos>0==true)
		{
			help1=Strings.leftstring(source, pos);
  		helpRest=Strings.rightstring(source, source.length()-pos-len);
  		pos=helpRest.indexOf(trenner);
  		if (pos>0==true)
  		{
		    len=trenner.length();
		    help2=Strings.leftstring(helpRest, pos);
	  		helpRest=Strings.rightstring(helpRest, helpRest.length()-pos-len);
	  		pos=helpRest.indexOf(trenner);
	  		if (pos>0==true)
	  		{
			    len=trenner.length();
					help3=Strings.leftstring(helpRest, pos);
		  		helpRest=Strings.rightstring(helpRest, helpRest.length()-pos-len);
				
					if (Art)
					{
					  result=help1+help3+helpRest;
					}
					else
					{
						result=help1+"##"+help2+"##"+helpRest;
					}
	  		}
  		}
		}
		return result;
		}
		catch(Exception e)
		{
			//Error while deleting parts of the string %1. Exception %2
			PV.ml.writeLog('m', 1, PV.LFehlerMeldungen[10],new String[]{e.toString()});
			return "";
		}

		
	}

}

	