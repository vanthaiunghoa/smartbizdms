package WDInterface;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.io.File;
import atTools.Strings;
import WDInterface.PV;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class ATface extends javax.swing.JFrame implements ActionListener
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JDesktopPane Hauptfeld;
	private JPanel panelMain;
	private JPanel panelHautfeld;

	// Menue
	private JMenuItem menuItemHelp;
	private JMenuItem menuItemAbout;
	private JMenu menuHelp;
	private JMenuItem menuItemExit;
	private JMenu menuFile;
	private JMenuBar menuBar;
  private JMenu menuEinstellungen;
  private JMenuItem menuItemSprache;
	
	//Tabs
	private JTabbedPane jTabs;

	//Tab Run Request
	private JPanel tabRunRequest;
	private JTextField tPass;
	private JTextField rRrStatus;
	private JLabel lRrRes;
	private JLabel lRrReq;
	private JPanel pRrBeschriftung;
	private JTextArea tRrRRRes;
	private JScrollPane scRrRRResText;
	private JScrollPane scRrRRReqText;
	private JPanel panelRrRRBottom;
	private JComboBox cRequestType;
	private JLabel lRequestType;
	private JLabel lPass;
	private JTextField tUser;
	private JLabel lUser;
	private JTextField tUrl;
	private JLabel lUrl;
	private JComboBox cDestination;
	private JLabel lDestination;
	private JPanel pTop;
	private JTextArea tRrRRReq;
	private JButton bRunRequest;

	//Tab Run CSV
	private JPanel tabRunCSV;
//	private JTextField rRcStatus;
	private JLabel lRcRes;
	private JPanel pRcBeschriftung;
//	private JTextArea tRcRRRes;
	private JScrollPane scRcRRResText;
	private JButton bRunVT;
	private JPanel panelRbootom;
	private JPanel panelRtop;
	private JPanel panelVTleft;
	private JScrollPane scrollVTleft;
	private JPanel panelVTright;
	private JPanel panelVtBottom;
	private JButton bRunBatch;
	private JTextField tBatchFile;
	private JLabel lBatchFile;
	private JButton bSelCsv;
	private JPanel pRcLeft;
	private JPanel panelRcRRBottom;
	private JScrollPane scVTText;
	private JLabel lVarsForBatch; 
	private JTextPane tVarsForBatch;
	private JPanel pPanel3;
	private JPanel pPanel2;
	private JPanel pPanel1;
	private JPanel south;
	private JButton bStopBatch;
	private JLabel lCounter;
	private JEditorPane lProgName;
	private JLabel lVtRightTop;
	private JLabel lVtLeftTop;
	private JPanel panelVtLeftTop;
	private JPanel panelVTleftContainer;
	private JPanel panelRcenter;
	private JScrollPane scrollVTResRight ;
	private JPanel panelVTResRight;

	
	private JPanel tabRunVT;

	private DestinationReader destR;
	private RequestTypeReader reqTypR;
	private RequestReader reqR;



	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				ATface inst = new ATface();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public ATface() 
	{
		super();
		try
		{
			GenerateStandard();
			initGUI();

			cDestination.getSelectedIndex();
		}
		catch (Exception e) 
		{
			System.out.println(e.toString()+" \n"+e.getStackTrace().toString());
		}

	}
	
	public boolean GenerateStandard()
	{
		/*-------------------------------------------------------
		* Standard einstellen
		* -------------------------------------------------------*/
		PV.aUser=System.getProperties().getProperty("user.name");
		PV.separator = System.getProperties().getProperty("file.separator"); // wg Unterschied Linux Windows
	  PV.langdir=System.getProperties().getProperty("user.home")+PV.separator+PV.PrgName;
	  PV.prgdir=System.getProperties().getProperty("user.home")+PV.separator+PV.PrgName;
	  PV.batchdir=PV.prgdir;
	  PV.reqdir=PV.prgdir+PV.separator+"Requests";
		PV.ml = new atTools.Logfile(PV.aUser,PV.PrgName); // controller.Logs(PV.aUser);
//		PV.ml = new atTools.Logfile(PV.aUser,PV.PrgName); // controller.Logs(PV.aUser);
		PV.IR = new IniReader(PV.prgdir,PV.ml);
		if (!PV.IR.ReadIni(PV.prgdir))
		{
      ATface.this.dispose();
		  System.exit(0);
		}
		PV.updateVer=PV.IR.getUpdateV();
		PV.batchdir=PV.IR.getBatchDir();
		PV.lang=PV.IR.getlanguage();
//		PV.viewRequest=PV.IR.isViewRequest();
//		PV.viewBatch=PV.IR.isViewBatch();
//		PV.viewVT=PV.IR.isViewVT();
		PV.ml.setPrgMode(PV.IR.getPrg_Mode()); 		// gibt die anzuwende Protokolltiefe vor 0=development  1=live
		PV.resx=  1224;
		PV.resy= 868;

		readLangFile();
		destR=new DestinationReader();
		destR.readDest();
		PV.ReqTypFile=new String[50];
		PV.ReqTypName=new String[50];
		PV.ReqVar=new String[50];
		PV.ReqVarNo=0;
		PV.ResVar=new String[50];
		PV.ResVarNo=0;
		PV.BatchFile="";
		PV.VtLabel=new JLabel[50];
		PV.VtText=new JTextField[50];
		PV.VtResLabel=new JLabel[50];
		PV.VtResText=new JTextField[50];

		reqTypR=new RequestTypeReader();
		reqR=new RequestReader();

		PV.ml.writeLog('n', 1, "Standard for User %1 is set",PV.aUser);
		update();
		return true; 
	}
	
	public void textP(String text)
	{
		
	}
	
	private void initGUI() 
	{
		PV.ml.writeLog('n', 0, "Start InitGUI" );
		try 
		{
			{
				this.setTitle("ATface "+PV.Version);
				this.setIconImage(new ImageIcon(getClass().getClassLoader().getResource("WDInterface/atface.png")).getImage());
			}
			{
				Hauptfeld = new JDesktopPane();
				
				BorderLayout HauptfeldLayout = new BorderLayout();
				Hauptfeld.setLayout(HauptfeldLayout);
				getContentPane().add(Hauptfeld, BorderLayout.CENTER);
				Hauptfeld.setPreferredSize(new java.awt.Dimension(1224,868));//(PV.resx,PV.resy));
				{
					panelHautfeld = new JPanel();
					BorderLayout layoutHauptfeld = new BorderLayout();
					Hauptfeld.add(panelHautfeld, BorderLayout.CENTER);
					panelHautfeld.setLayout(layoutHauptfeld);
					panelHautfeld.setPreferredSize(new java.awt.Dimension(1224,868));//(PV.resx,PV.resy));
					{
						panelMain = new JPanel();
						BorderLayout layoutProtocoll = new BorderLayout();
						panelHautfeld.add(panelMain, BorderLayout.WEST);
						panelMain.setLayout(layoutProtocoll);
 					  panelMain.setPreferredSize(new java.awt.Dimension(1216, 856));//(PV.resx-160, PV.resy-50));
 					  {
 						  pTop = new JPanel();
 						  panelMain.add(pTop, BorderLayout.NORTH);
 						  pTop.setLayout(null);
 						  pTop.setPreferredSize(new java.awt.Dimension(1049, 60));//(PV.resx-170, 60));
 						  {
 							  lDestination = new JLabel();
 							  pTop.add(lDestination);
 							  //Destination:
 							  lDestination.setText(PV.LBeschriftungen[24]);
 							  lDestination.setBounds(7, 10, 63, 15);
 							  lDestination.setFont(new java.awt.Font("Albany AMT",0,9));
 						  }
 						  {
 							  
										cDestination = new JComboBox(PV.destName);
										pTop.add(cDestination);
										cDestination.setBounds(80, 6, 210, 22);
										
								    class AlDestination implements ActionListener 
								    {
								    	public void actionPerformed(ActionEvent evt) 
								    	{
								    		JComboBox cDestination = (JComboBox)evt.getSource();
								    		int now = cDestination.getSelectedIndex();
								    		ChangeDestination(now);
								    	}
								    	
								    }
								    
								    AlDestination actionListener = new AlDestination();
								    cDestination.addActionListener(actionListener);
								    
 						  }
 						  {
 							  lUrl = new JLabel();
 							  if (!PV.IR.isoneUser()) pTop.add(lUrl);
 							  lUrl.setText("URL:");
 							  lUrl.setBounds(297, 10, 26, 15);
 							  lUrl.setFont(new java.awt.Font("Albany AMT",0,9));
 						  }
 						  {
 							  tUrl = new JTextField();
 							  if (!PV.IR.isoneUser())  							  pTop.add(tUrl);
 							  tUrl.setBounds(328, 6, 391, 22);
 						  }
 						  {
 							  lUser = new JLabel();
 							  pTop.add(lUser);
 							  if (!PV.IR.isoneUser())  							  lUser.setText("Https-User:");
 							  lUser.setBounds(725, 8, 68, 15);
 							  lUser.setFont(new java.awt.Font("Albany AMT",0,9));
 						  }
 						  {
 							  tUser = new JTextField();
 							  tUrl.setNextFocusableComponent(tUser);

 							  if (!PV.IR.isoneUser()) pTop.add(tUser);
 							  tUser.setBounds(798, 4, 157, 22);
 							  tUser.setFocusCycleRoot(true);
 						  }
 						  {
 							  lPass = new JLabel();
 							  if (!PV.IR.isoneUser()) pTop.add(lPass);
 							  //Password:
 							  lPass.setText(PV.LBeschriftungen[15]);
 							  lPass.setBounds(725, 36, 68, 15);
 							  lPass.setFont(new java.awt.Font("Albany AMT",0,9));
 						  }
 						  {
 							  tPass = new JTextField();
 							  tUser.setNextFocusableComponent(tPass);
 							  if (!PV.IR.isoneUser()) pTop.add(tPass);
 							  tPass.setBounds(798, 31, 157, 22);
 							  tPass.setNextFocusableComponent(tUrl);
 						  }
 						  {
 							  lRequestType = new JLabel();
 							  pTop.add(lRequestType);
 							  //RequestType;
 							  lRequestType.setText(PV.LBeschriftungen[16]);
 							  lRequestType.setBounds(7, 37, 63, 15);
 							  lRequestType.setFont(new java.awt.Font("Albany AMT",0,9));
 						  }
 						  {
 							  cRequestType = new JComboBox(new String[] { ""});
 							  pTop.add(cRequestType);
 							  cRequestType.setBounds(80, 31, 210, 22);
 							  class AlRequestType implements ActionListener 
 							  {
 								  public void actionPerformed(ActionEvent evt) 
 								  {
 									  JComboBox cRequestType = (JComboBox)evt.getSource();
 									  int now = cRequestType.getSelectedIndex();
 									  ChangeRequestType(now);
 								  }
 								  
 							  }
 							  
 							  AlRequestType actionListener = new AlRequestType();
 							  cRequestType.addActionListener(actionListener);
 							  
									}
 						  
								}
								{
									lProgName = new JEditorPane();
									pTop.add(lProgName);
									lProgName.setText("ATface " +PV.Version+"\n(C) Andreas Tritt 2009\nno warranty");
									lProgName.setFont(new java.awt.Font("Arial Black",1,10));
									lProgName.setAutoscrolls(false);
									lProgName.setFocusable(false);
									lProgName.setFocusTraversalKeysEnabled(false);
									lProgName.setRequestFocusEnabled(false);
									lProgName.setVerifyInputWhenFocusTarget(false);
									lProgName.setEditable(false);
									lProgName.setBackground(pTop.getBackground());
									lProgName.setAlignmentX(10);
									lProgName.setBounds(971, 4, 233, 49);
								}

						{
							south = new JPanel();
							BorderLayout southLayout = new BorderLayout();
							panelMain.add(south, BorderLayout.CENTER);
							south.setLayout(southLayout);
							{
								pPanel1 = new JPanel();
								south.add(pPanel1, BorderLayout.CENTER);
								BorderLayout jPanel1Layout = new BorderLayout();
								pPanel1.setLayout(jPanel1Layout);
								{
									jTabs = new JTabbedPane();
									pPanel1.add(jTabs, BorderLayout.CENTER);
									jTabs.setPreferredSize(new java.awt.Dimension(1054,748));//(PV.resx-170, PV.resy-60));
									jTabs.addChangeListener(new ChangeListener() {
										public void stateChanged(ChangeEvent evt) {
											visibleTabsChanged(evt);
										}
									});
									// ########## Tab Request ########## 
									{
										tabRunRequest = new JPanel();
										BorderLayout jPanel2Layout = new BorderLayout();
										if (PV.IR.isViewRequest()) jTabs.addTab("run Request", null, tabRunRequest, null);
										tabRunRequest.setLayout(jPanel2Layout);
										tabRunRequest.setPreferredSize(new java.awt.Dimension(1054,768));//(PV.resx-170, PV.resy-60));
										{
											panelRrRRBottom = new JPanel();
											BorderLayout jPanel3Layout = new BorderLayout();
											tabRunRequest.add(panelRrRRBottom, BorderLayout.CENTER);
											panelRrRRBottom.setLayout(jPanel3Layout);
											panelRrRRBottom.setPreferredSize(new java.awt.Dimension(1049, 740));
											{
												scRrRRReqText = new JScrollPane();
												panelRrRRBottom.add(scRrRRReqText, BorderLayout.WEST);
												scRrRRReqText.setPreferredSize(new java.awt.Dimension(510, 70));
												{
													tRrRRReq = new JTextArea();
													scRrRRReqText.setViewportView(tRrRRReq);
													tRrRRReq.setText("");
												}
											}
											
											{
												scRrRRResText = new JScrollPane();
												panelRrRRBottom.add(scRrRRResText, BorderLayout.EAST);
												scRrRRResText.setPreferredSize(new java.awt.Dimension(510, 700));
												{
													tRrRRRes = new JTextArea();
													scRrRRResText.setViewportView(tRrRRRes);
													tRrRRRes.setText("");
													tRrRRRes.setCaretPosition(tRrRRRes.getDocument().getLength());
												}
											}
											{
												pRrBeschriftung = new JPanel();
												panelRrRRBottom.add(pRrBeschriftung, BorderLayout.NORTH);
												pRrBeschriftung.setLayout(null);
												pRrBeschriftung.setPreferredSize(new java.awt.Dimension(1049, 30));
												{
													lRrReq = new JLabel();
													pRrBeschriftung.add(lRrReq);
													//Request:
														lRrReq.setText(PV.LBeschriftungen[17]);
													lRrReq.setBounds(0, 4, 74, 22);
												}
												{
													lRrRes = new JLabel();
													pRrBeschriftung.add(lRrRes);
													//Response:
														lRrRes.setText(PV.LBeschriftungen[18]);
													lRrRes.setBounds(538, 4, 80, 22);
												}
												{
													rRrStatus = new JTextField();
													pRrBeschriftung.add(rRrStatus);
													rRrStatus.setBounds(620, 4, 22, 22);
													rRrStatus.setEditable(false);
												}
												{
													bRunRequest = new JButton();
													pRrBeschriftung.add(bRunRequest);
													bRunRequest.setText("Start");
													bRunRequest.setBounds(967, 4, 65, 22);
													//start.setPreferredSize(new java.awt.Dimension(841, 591));
													bRunRequest.addKeyListener(new KeyAdapter() 
													{
														public void keyPressed(KeyEvent evt) 
														{
															runRequest();
														}
													});
													bRunRequest.addMouseListener(new MouseAdapter() 
													{
														public void mousePressed(MouseEvent evt) 
														{
															runRequest();
														}
													});
												}
												
												
											}
										}
									}
									// ########## Tab CSV ########## 
									{
										tabRunCSV = new JPanel();
										if(PV.IR.isViewBatch()) jTabs.addTab("run CSV", null, tabRunCSV, null);
										tabRunCSV.setPreferredSize(new java.awt.Dimension(1054,808));//(PV.resx-170, PV.resy-60));
										{
											panelRcRRBottom = new JPanel();
											BorderLayout jPanel3Layout = new BorderLayout();
											tabRunCSV.add(panelRcRRBottom, BorderLayout.CENTER);
											panelRcRRBottom.setLayout(jPanel3Layout);
											panelRcRRBottom.setPreferredSize(new java.awt.Dimension(1049, 740));

											{
												scRcRRResText = new JScrollPane();
												panelRcRRBottom.add(scRcRRResText, BorderLayout.EAST);
												scRcRRResText.setPreferredSize(new java.awt.Dimension(510, 672));
												{
													PV.tRcRRRes = new JTextArea();
													scRcRRResText.setViewportView(PV.tRcRRRes);
													PV.tRcRRRes.setText("");
													PV.tRcRRRes.setCaretPosition(PV.tRcRRRes.getDocument().getLength());
												}
											}
											{
												pRcBeschriftung = new JPanel();
												panelRcRRBottom.add(pRcBeschriftung, BorderLayout.NORTH);
												pRcBeschriftung.setLayout(null);
												pRcBeschriftung.setPreferredSize(new java.awt.Dimension(1049, 23));
												{
													lRcRes = new JLabel();
													pRcBeschriftung.add(lRcRes);
													//Protocoll:
													lRcRes.setText(PV.LBeschriftungen[19]);
													lRcRes.setBounds(538, 2, 80, 15);
												}
												/*									{
												rRcStatus = new JTextField();
												pRcBeschriftung.add(rRcStatus);
												rRcStatus.setBounds(604, 0, 22, 22);
												rRcStatus.setEditable(false);
											}
												 */								}
											{
												pRcLeft = new JPanel();
												panelRcRRBottom.add(pRcLeft, BorderLayout.CENTER);
												pRcLeft.setLayout(null);
												{
													lBatchFile = new JLabel();
													pRcLeft.add(lBatchFile);
													//selected Batchfile
													lBatchFile.setText(PV.LBeschriftungen[20]);
													lBatchFile.setBounds(12, 8, 100, 15);
													lBatchFile.setFont(new java.awt.Font("Albany AMT",0,9));
												}
												{
													tBatchFile = new JTextField();
													pRcLeft.add(tBatchFile);
													tBatchFile.setBounds(124, 5, 418, 22);
													tBatchFile.setEditable(false);
												}
												{
													bSelCsv = new JButton();
													pRcLeft.add(bSelCsv);
													//select Batchfile
													bSelCsv.setText(PV.LBeschriftungen[21]);
													bSelCsv.setBounds(13, 29, 130, 22);
													bSelCsv.setFont(new java.awt.Font("Albany AMT",0,9));
													bSelCsv.addKeyListener(new KeyAdapter() 
													{
														public void keyPressed(KeyEvent evt) 
														{
															MakeFileChooser();
															tBatchFile.setText(PV.BatchFile);
														}
													});
													bSelCsv.addMouseListener(new MouseAdapter() 
													{
														public void mousePressed(MouseEvent evt) 
														{
															MakeFileChooser();
															tBatchFile.setText(PV.BatchFile);
														}
													});

												}
												{
													bRunBatch = new JButton();
													pRcLeft.add(bRunBatch);
													bRunBatch.setText("Start Batch");
													bRunBatch.setBounds(13, 62, 130, 22);
													bRunBatch.setFont(new java.awt.Font("Albany AMT",0,9));
													bRunBatch.addKeyListener(new KeyAdapter() 
													{
														public void keyPressed(KeyEvent evt) 
														{
															runBatch();
														}
													});
													bRunBatch.addMouseListener(new MouseAdapter() 
													{
														public void mousePressed(MouseEvent evt) 
														{
															runBatch();
														}
													});
												}
												{
													lCounter = new JLabel();
													pRcLeft.add(lCounter);
													lCounter.setText("Counter");
													lCounter.setBounds(13, 102, 57, 30);
												}
												{
													bStopBatch = new JButton();
													pRcLeft.add(bStopBatch);
													bStopBatch.setText("stop Batch");
													bStopBatch.setBounds(183, 62, 74, 22);
													bStopBatch.setFont(new java.awt.Font("Albany AMT",0,9));
													bStopBatch.setBackground(new java.awt.Color(238,25,25));
													bStopBatch.setVisible(false);
													bStopBatch.addKeyListener(new KeyAdapter() 
													{
														public void keyPressed(KeyEvent evt) 
														{
															stopBatch();
														}
													});
													bStopBatch.addMouseListener(new MouseAdapter() 
													{
														public void mousePressed(MouseEvent evt) 
														{
															stopBatch();
														}
													});


												}
												{
													lVarsForBatch = new JLabel();
													pRcLeft.add(lVarsForBatch);
													lVarsForBatch.setText(PV.LBeschriftungen[26]);
													lVarsForBatch.setFont(new java.awt.Font("Albany AMT",0,9));
													lVarsForBatch.setBounds(13, 142, 300, 10);
												}
												{
													tVarsForBatch = new JTextPane();
													pRcLeft.add(tVarsForBatch);
													tVarsForBatch.setBounds(13, 152, 490, 100);
													tVarsForBatch.setEditable(false);
												}
												{
													PV.tCounter = new JTextField();
													pRcLeft.add(PV.tCounter);
													PV.tCounter.setText("0");
													PV.tCounter.setBounds(83, 102, 90, 30);
													PV.tCounter.setFont(new java.awt.Font("Albany AMT",1,24));
													PV.tCounter.setEditable(false);
													PV.tCounter.setHorizontalAlignment(JTextField.RIGHT);
												}
											}
									}
									}
									// ########## Tab VT ########## 
									{
										tabRunVT = new JPanel();
										BorderLayout jPanel3Layout = new BorderLayout();
										if (PV.IR.isViewVT()) jTabs.addTab("Virtual Terminal", null, tabRunVT, null);
										tabRunVT.setLayout(jPanel3Layout);
										{
											panelVtBottom = new JPanel();
											BorderLayout panelVtBottomLayout = new BorderLayout();
											panelVtBottom.setLayout(panelVtBottomLayout);
											tabRunVT.add(panelVtBottom, BorderLayout.CENTER);
											
											{
												panelVTright = new JPanel();
												BorderLayout panelVTrightLayout = new BorderLayout();
												panelVTright.setLayout(panelVTrightLayout);
												panelVtBottom.add(panelVTright, BorderLayout.EAST);
												panelVTright.setPreferredSize(new java.awt.Dimension(534, 721));
												{
													panelRtop = new JPanel();
													panelVTright.add(panelRtop, BorderLayout.NORTH);
													panelRtop.setPreferredSize(new java.awt.Dimension(534, 32));
													panelRtop.setLayout(null);
													{
														bRunVT = new JButton();
														panelRtop.add(bRunVT);
														bRunVT.setText("Start");
														bRunVT.setBounds(5, 5, 80, 22);
														bRunVT.addKeyListener(new KeyAdapter() 
														{
															public void keyPressed(KeyEvent evt) 
															{
																runVT();
															}
														});
														bRunVT.addMouseListener(new MouseAdapter() 
														{
															public void mousePressed(MouseEvent evt) 
															{
																runVT();
															}
														});
													}
													{
														lVtRightTop = new JLabel();
														panelRtop.add(lVtRightTop);
														//Response Information
														lVtRightTop.setText(PV.LBeschriftungen[22]);
														lVtRightTop.setBounds(125, 8, 257, 15);
													}
													{
														PV.tVtStatus = new JTextField();
														panelRtop.add(PV.tVtStatus);
														PV.tVtStatus.setBounds(90, 5, 22, 22);
														PV.tVtStatus.setEditable(false);
													}
												}
												{
													panelRcenter = new JPanel();
													BorderLayout panelRcenterLayout = new BorderLayout();
													panelVTright.add(panelRcenter, BorderLayout.CENTER);
													panelRcenter.setPreferredSize(new java.awt.Dimension(534, 202));
													panelRcenter.setLayout(panelRcenterLayout);
													panelRcenter.setSize(534, 202);
													{
														scrollVTResRight = new JScrollPane();
														panelRcenter.add(scrollVTResRight, BorderLayout.WEST);
														//											scrollVTResRight.setBounds(0, 0, 522, 270);
														scrollVTResRight.setPreferredSize(new java.awt.Dimension(516, 202));
														scrollVTResRight.setSize(516, 202);
														{
															panelVTResRight = new JPanel();
															scrollVTResRight.setViewportView(panelVTResRight);
															panelVTResRight.setLayout(null);
															panelVTResRight.setPreferredSize(new java.awt.Dimension(394, 0));
															panelVTResRight.setSize(394, 199);
														}
													}
												}
												{
													panelRbootom = new JPanel();
													BorderLayout panelRbootomLayout = new BorderLayout();
													panelRbootom.setLayout(panelRbootomLayout);
													panelVTright.add(panelRbootom, BorderLayout.SOUTH);
													panelRbootom.setPreferredSize(new java.awt.Dimension(534, 419));
													{
														
														scVTText = new JScrollPane();
														panelRbootom.add(scVTText, BorderLayout.WEST);
														scVTText.setPreferredSize(new java.awt.Dimension(516, 419));
														{
															PV.textVT = new JTextArea();
															scVTText.setViewportView(PV.textVT);
															PV.textVT.setText("");
														}
														
														
													}
												}
											}
											{
												panelVTleftContainer = new JPanel();
												BorderLayout panelVTleftContainerLayout = new BorderLayout();
												panelVtBottom.add(panelVTleftContainer, BorderLayout.WEST);
												panelVTleftContainer.setLayout(panelVTleftContainerLayout);
												{
													scrollVTleft = new JScrollPane();
													panelVTleftContainer.add(scrollVTleft, BorderLayout.SOUTH);
													scrollVTleft.setPreferredSize(new java.awt.Dimension(516, 689));
													{
														panelVTleft = new JPanel();
														scrollVTleft.setViewportView(panelVTleft);
														panelVTleft.setLayout(null);
														panelVTleft.setPreferredSize(new java.awt.Dimension(394, 100));
													}
												}
												{
													panelVtLeftTop = new JPanel();
													panelVTleftContainer.add(panelVtLeftTop, BorderLayout.NORTH);
													panelVtLeftTop.setPreferredSize(new java.awt.Dimension(516, 21));
													panelVtLeftTop.setLayout(null);
													{
														lVtLeftTop = new JLabel();
														panelVtLeftTop.add(lVtLeftTop);
														//Fill in Request Data:
															lVtLeftTop.setText(PV.LBeschriftungen[23]);
														lVtLeftTop.setBounds(5, 6, 192, 15);
													}
												}
											}
										}
									}
								}
								{
									pPanel2 = new JPanel();
									pPanel1.add(pPanel2, BorderLayout.WEST);
									pPanel2.setPreferredSize(new java.awt.Dimension(90, 10));
								}
								{
									pPanel3 = new JPanel();
									pPanel1.add(pPanel3, BorderLayout.EAST);
									pPanel3.setPreferredSize(new java.awt.Dimension(90, 10));
								}
							}
						}
					}
					
				}	

			}
			this.setSize(PV.resx, PV.resy);

			{// Menue Leiste
				menuBar = new JMenuBar();
				setJMenuBar(menuBar);
				{//File
					menuFile = new JMenu();
					menuBar.add(menuFile);
					menuFile.setText(PV.LMenue[1]);

					{
						menuItemExit = new JMenuItem();
						menuFile.add(menuItemExit);
						menuItemExit.setText(PV.LMenue[4]);
						menuItemExit.addActionListener(this);
					}
				}
				{//Einstellungen
				  menuEinstellungen = new JMenu();
					menuBar.add(menuEinstellungen);
					menuEinstellungen.setText(PV.LMenue[3]);
					{
						menuItemSprache = new JMenuItem();
						menuEinstellungen.add(menuItemSprache);
						menuItemSprache.setText(PV.LMenue[5]);
						menuItemSprache.addActionListener(this);
					}
				}
				{//Hilfe
					menuHelp = new JMenu();
					menuBar.add(menuHelp);
					menuHelp.setText(PV.LMenue[2]);
					{
						menuItemHelp = new JMenuItem();
						menuHelp.add(menuItemHelp);
						menuItemHelp.setText(PV.LMenue[2]);
						menuItemHelp.addActionListener(this);
					}
					{
						menuItemAbout = new JMenuItem();
						menuHelp.add(menuItemAbout);
						menuItemAbout.setText(PV.LMenue[6]);
						menuItemAbout.addActionListener(this);

					}

				}
			}
			this.addWindowListener(new WindowAdapter() 
			{
				public void windowClosing(WindowEvent evt) 
				{
					miExit();
				}
			});
			
			this.setIconImage(Image.class.cast(createImage("atface.png","Dies")));
			PV.ml.writeLog('n', 1, "End Init GUI");
		}
		catch (Exception e) 
		{
			PV.ml.writeLog('e', 1, "Fehler: %1 Stack Trace %2",new String[]{e.toString(),e.getStackTrace().toString()});
		}
	}

	public void actionPerformed(ActionEvent e)  
	 {
		/*-------------------------------------------------------
		 * Events abfangen
		 * -------------------------------------------------------*/
		 if (e.getSource().equals(menuItemExit)) 
		 {
			 miExit();
		 }
		 if (e.getSource().equals(menuItemHelp)) 
		 {
			 miHelp();
		 }
		 if (e.getSource().equals(menuItemAbout)) 
		 {
			 miAbout();
		 }
		 if (e.getSource().equals(menuItemSprache)) 
		 {
			 miSpracheWaehlen();
		 }
	 }
	

	protected static Image createImage(String path, String description) 
	{
    java.net.URL imgURL = WDInterface.ATface.class.getResource(path); // anpassen!!!
    if (imgURL != null) 
    {
    	
      return new ImageIcon(imgURL, description).getImage();
    } 
    else 
    {
       System.out.println("Couldn't find file: " + path);
       return null;
    }
}
	private void miExit()
	{		
		PV.stopcounter=0;
    closing();
    ATface.this.dispose();
    System.exit(0);
  }

	private void closing()
	{
		/*-------------------------------------------------------
		 * Abgefangenes Closing event verarbeiten
		 * -------------------------------------------------------*/
//		PV.stop=true;
		PV.stopcounter=0;
		//SwingGUI wird beendet
		PV.ml.writeLog('n',1,PV.LMeldungen[28]);
		ATface.this.dispose();
		//Programm beendet
		PV.ml.writeLog('c', 1, PV.LMeldungen[29]);
	}
	
	private void ChangeDestination(int now)
	{
		try
		{
			if (now<1==true) return;
			PV.destSelected=now;
			setFields(PV.destSelected);
			reqTypR.readReqTypes(PV.reqdir+PV.separator+PV.destDir[PV.destSelected]);// Requests aus gewähltem Verzeichniss lesen
			cRequestType.removeAllItems();// Request-Combobox leeren
			cRequestType.addItem("");     // Leerzeile anfügen
			for (int p=1;p<=PV.ReqTypMax;p++)
			{
				cRequestType.addItem(PV.ReqTypName[p]);// Requests anfügen
			}
			//neue Destination %1 gewählt. Dir %2
			PV.ml.writeLog('n', 0, PV.LMeldungen[30], new String[]{PV.destName[PV.destSelected],PV.destDir[PV.destSelected] });
		}
		catch(Exception e)
		{
			//Fehler bei Wechsel der Destination: %1 
			PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[19],new String[]{e.toString()});
		}
	}

	private void miHelp()
	{
		textDisplay help;
		help=new textDisplay();
		help.setVisible(true);
		PV.ml.writeLog('n', 0, PV.LMenue[2]+" "+ PV.prgdir+PV.separator+PV.lang+".hlp "+ PV.Version);
		help.setText(PV.LMenue[2],PV.langdir+PV.separator+PV.lang+".hlp",PV.Version);
	}

	private void miAbout()
	{
		System.out.println(PV.prgdir+"\n"+PV.homedir+"\n"+PV.langdir+"\n"+PV.lang);
		textDisplay about;
		about=new textDisplay();
		about.setX(500);
		about.setY(300);
		about.setVisible(true);
		//über %1 %2
		PV.ml.writeLog('n', 0, PV.LMeldungen[31]+" "+ PV.prgdir+PV.separator+PV.lang+".hlp "+ PV.Version);
		about.setText(Strings.mix(PV.LMeldungen[31],new String[]{PV.PrgName,PV.Version}),PV.langdir+PV.separator+PV.lang+".abt",PV.Version,"\n**************************\nCopyright 2009\nby\nAndreas Tritt");
	}
	 
	private void miSpracheWaehlen()
	{
		/*-------------------------------------------------------
		 * Sprachdatei auswählen
		 * -------------------------------------------------------*/
		 String lang;
		 String fname;
		 // Standard Text überschreiben
		 atUIManager.saveValues();
		 atUIManager.put("FileChooser.openButtonText", PV.LBeschriftungen[1]);
		 atUIManager.put("FileChooser.lookInLabelText", PV.LBeschriftungen[2]);
		 atUIManager.put("FileChooser.upFolderToolTipText", PV.LBeschriftungen[3]);
		 atUIManager.put("FileChooser.newFolderToolTipText", PV.LBeschriftungen[4]);
		 atUIManager.put("FileChooser.fileNameLabelText", PV.LBeschriftungen[5]);
		 atUIManager.put("FileChooser.filesOfTypeLabelText", PV.LBeschriftungen[6]);
		 atUIManager.put("FileChooser.cancelButtonText", PV.LBeschriftungen[7]);
		 atUIManager.put("FileChooser.cancelButtonToolTipText", PV.LBeschriftungen[8]);
		 atUIManager.put("FileChooser.detailsViewButtonToolTipText", PV.LBeschriftungen[9]);
		 atUIManager.put("FileChooser.listViewButtonToolTipText", PV.LBeschriftungen[10]);
		 atUIManager.put("FileChooser.openDialogTitleText", PV.LBeschriftungen[11]);
		 
		 JFileChooser sw=new JFileChooser();
		 sw.setCurrentDirectory(new File(PV.langdir));
		 sw.addChoosableFileFilter(new swFilter());
		 sw.setFileHidingEnabled(true);
		 sw.showOpenDialog(this);
		 atUIManager.restoreValues();
		 try
			{
			 fname=sw.getSelectedFile().getName();// .toString();
			}
			catch (RuntimeException e1)
			{
				// File Chooser Dialog abgebrochen
				fname="Abbruch";
				PV.ml.writeLog('e', 1, e1.toString());
				return;
			}
     // Sprachfile %1 gewählt
		 PV.ml.writeLog('n', 1,PV.LMeldungen[20],fname);
		 
     lang=Strings.leftstring(fname,2);
     if (fname.compareTo(lang+".lang")==0)// Dateinamen auf Gültigkeit prüfen 2buchstabiges Länderkürzel +".lang"
     {
	     PV.IR.setlanguage(lang);
	  	 if (PV.IR.schreiben())
		 	 {
	  		 //Ini Update schreiben OK
				 PV.ml.writeLog('n',0,PV.LMeldungen[21]);
				 JOptionPane.showMessageDialog(new JFrame(), PV.LMeldungen[3]);//Damit die Änderung wirksam wird, muss dass Programm neu gestaret werden
			 }
			 else
			 {
				 //Änderung konnte nicht gespeichert werden
				 PV.ml.writeLog('m',0,PV.LMeldungen[4]);
			 }
     }
     else
     {
    	 // fname ist kein gültiger Dateiname
			 PV.ml.writeLog('m', 1,Strings.mix(PV.LMeldungen[5],fname));
     }
	 }
	
	private void ChangeRequestType (int now)
	{
		try
		{
			PV.BatchUser="";
			PV.BatchPass="";
			if (now<1==true)
			{
				tRrRRReq.setText("");
			}
			else
			{
				PV.ReqSelected=now;
				PV.ml.writeLog('n', 1, "neuen Request "+PV.ReqSelected+" gewählt");
				String reqFile;
				tRrRRReq.setText("");
				reqFile=PV.reqdir+PV.separator+PV.destDir[PV.destSelected]+PV.separator+PV.ReqTypFile[PV.ReqSelected];
				PV.ml.writeLog('n', 1, reqFile+" gewählt");
			  tRrRRReq.setText(reqR.readReqs(reqFile,"RequestValue"));
	  	  PV.BatchReqStringVar=reqR.readReqs(reqFile,"RequestVars");
		    reqR.readReqVars(reqFile);
		    setVtFields();
				//Request %1 gewählt
				PV.ml.writeLog('n', 1, PV.LMeldungen[36],new String[]{reqFile});
				setVarInfo(tVarsForBatch);
			}
		}
		catch(Exception e)
		{
			//Fehler beim Wechsel des Request Typs: %1
			PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[20],new String[]{e.toString()});
		}
	}
	
	private void setVarInfo(JTextPane out)
	{
		out.setText("");
		for (int i=1;i<=PV.ReqVarNo;i++)
		{
			if (i==1)
			{
				out.setText(PV.ReqVar[i]);
			}
			else
			{
				out.setText(out.getText()+";"+PV.ReqVar[i]);
			}
		}
	}
	
	private void setVtFields()
	{
		int j=0;
		int pos;
		
		try
		{
			for (int i=1;i<50;i++)
			{
				if (PV.VtLabel[i]!=null)
				{
					PV.VtLabel[i].setVisible(false);
					panelVTleft.remove(PV.VtLabel[i]);
				}
				if (PV.VtText[i]!=null)
				{
					PV.VtText[i].setVisible(false);
					panelVTleft.remove(PV.VtText[i]);
				}
				
				if (PV.VtResLabel[i]!=null)
				{
					PV.VtResLabel[i].setVisible(false);
					panelVTResRight.remove(PV.VtResLabel[i]);
				}
				if (PV.VtResText[i]!=null)
				{
					PV.VtResText[i].setVisible(false);
					panelVTResRight.remove(PV.VtResText[i]);
				}
				
			}
			panelVTleft.setPreferredSize(new java.awt.Dimension(513, 685));
			panelVTResRight.setPreferredSize(new java.awt.Dimension(394, PV.ResVarNo*20));
		
			
			for (int i=1;i<=PV.ReqVarNo;i++)
			{
				if (PV.ReqVar[i].equals("httpsuser")||PV.ReqVar[i].equals("httpspw"))
				{
					j++;
				}
				else
				{
					PV.VtLabel[i]=new JLabel();
					//panelVTLeft.add(PV.VtLabel[i]);
					
					panelVTleft.add(PV.VtLabel[i]);
					PV.VtLabel[i].setText(PV.ReqVar[i]);
					PV.VtLabel[i].setBounds(5, 5+((i-1-j)*20), 100, 14);
					PV.VtLabel[i].setFont(new java.awt.Font("Albany AMT",0,9));
					
					PV.VtText[i]=new JTextField();
		//			panelVTLeft.add(PV.VtText[i]);
					panelVTleft.add(PV.VtText[i]);
					PV.VtText[i].setText("");
					PV.VtText[i].setBounds(100, 5+((i-1-j)*20), 370, 14);
					PV.VtText[i].setFont(new java.awt.Font("Albany AMT",0,9));
				}
			}
			j=0;
			for (int i=1;i<=PV.ResVarNo;i++)
			{
				if (PV.ResVar[i].equals("httpsuser")||PV.ResVar[i].equals("httpspw"))
				{
					j++;
				}
				else
				{
					PV.VtResLabel[i]=new JLabel();
					//panelVTLeft.add(PV.VtLabel[i]);
					
					panelVTResRight.add(PV.VtResLabel[i]);
					PV.VtResLabel[i].setText(PV.ResVar[i].replace("<", "").replace(">", ""));
					pos=PV.VtResLabel[i].getText().indexOf("xsi");
					if (pos>0==true)
					{
						PV.VtResLabel[i].setText(Strings.leftstring(PV.VtResLabel[i].getText(),pos));
					}
					PV.VtResLabel[i].setBounds(5, 5+((i-1-j)*20), 100, 14);
					PV.VtResLabel[i].setFont(new java.awt.Font("Albany AMT",0,9));
					
					PV.VtResText[i]=new JTextField();
		//			panelVTLeft.add(PV.VtText[i]);
					panelVTResRight.add(PV.VtResText[i]);
					PV.VtResText[i].setText("");
					PV.VtResText[i].setBounds(100, 5+((i-1-j)*20), 370, 14);
					PV.VtResText[i].setFont(new java.awt.Font("Albany AMT",0,9));
				}
			}
		}
		catch(Exception e)
		{
			//Fehler beim Erzeugen des Vitual Terminal-Tabs. Exception %1 
			PV.ml.writeLog('e', 1,PV.LFehlerMeldungen[21],new String[]{e.toString()});
		}

	}
	
	private void setFields(int now)
	{
		String URL;
		String User;
		String Pass;
		try
		{
			if (now>0)
			{
				User=PV.destUser[now];
				Pass=PV.destPass[now];
				URL=toUrl(PV.destPort[now],PV.destHost[now],PV.destPath[now]);
				tUser.setText("");
				tPass.setText("");
			}
			else
			{
				URL="";
				User="";
				Pass="";
			}
			tUrl.setText(URL);
			tUser.setText(User);
			tPass.setText(Pass);
		}
		catch(Exception e)
		{
			//Fehler bei setFields: %1 
			PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[22],new String[]{e.toString()});
		}

	}
	
	private boolean runRequest()
	{
		TheRequest tr0=new TheRequest();
		tr0.setPass(tPass.getText());
		tr0.setUser(tUser.getText());
		tr0.setURL(tUrl.getText());
		tr0.setReqText(tRrRRReq);
		tr0.setResText(tRrRRRes);
		tr0.setStatus(rRrStatus);
		tr0.setButton(bRunRequest);
		tr0.start();
		
		// Request gesendet
		PV.ml.writeLog('n', 1, PV.LMeldungen[37]);
		return true;
	}
	
	
	private void update()
	{
		if (PV.updateVer==0)
		{
			PV.langdir="t"+":\\tech-supp\\ATface";
//			PV.langdir="/X_w1/lang";
			PV.IR.setLangDir(PV.langdir);
			PV.updateVer=1;
			PV.IR.setUpdateV(PV.updateVer);
			PV.IR.schreiben();
		}
		
		if (PV.updateVer==1)
		{
			PV.updateVer=2;
		  PV.batchdir=PV.prgdir;
		  PV.IR.setBatchDir(PV.batchdir);
		  PV.IR.setUpdateV(PV.updateVer);
		  PV.IR.schreiben();
		}
		if (PV.updateVer==2)
		{
			PV.updateVer=3;
			PV.IR.setUpdateV(PV.updateVer);
		  PV.IR.schreiben();
		}
		if (PV.updateVer==3)
		{
			PV.updateVer=4;
			PV.IR.setUpdateV(PV.updateVer);
		  PV.IR.schreiben();
		}

		
	}


	private String toUrl(String Port,String Host,String Path)
	{
		try
		{
			String URL="";
			if (Port.equalsIgnoreCase("443")==true)
			{
				URL="https://";
			}
			else
			{
				URL="http://";
			}
			URL+=Host+Path;
			
			return URL;
		}
		catch(Exception e)
		{
			//Fehler beim Konvertieren in URL von Port %1, Host %2, Path %3 Exception %4 
			PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[24],new String[]{Port,Host,Path,e.toString()});
			return "";
		}

	}

/*  private String replace(String str, String pattern, String replace) 
  {
    int s = 0;
    int e = 0;
    try
    {
	    StringBuffer result = new StringBuffer();
	
	    while ((e = str.indexOf(pattern, s)) >= 0) {
	        result.append(str.substring(s, e));
	        result.append(replace);
	        s = e+pattern.length();
	    }
	    result.append(str.substring(s));
	    return result.toString();
    }
  	catch(Exception es)
  	{
  		//Fehler bei replace von %1 durch %2 in %3 Exception %4 
  		PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[25],new String[]{pattern,replace,str,es.toString()});
  		return "";
  	}

  }
*/
	private boolean readLangFile()
	{
		/*-------------------------------------------------------
		 * Meldunge und Beschriftungen in der jeweils gewählte 
		 * Sprache lesen und zur Verfügung stellen
		 * -------------------------------------------------------*/
		PV.ml.writeLog('n', 1, "Sprache ist "+PV.lang);
		langReader LR = new langReader();
		LR.Reader(PV.langdir,PV.lang);
		/* -------------------------------------------------------
		 * Menuetext
		 * -------------------------------------------------------*/
		if(LR.ReadBereich("LMenue"))
		{
			PV.LMenue= new String[PV.langText.length];
			System.arraycopy(PV.langText,0, PV.LMenue, 0, PV.langText.length);
		}
		else
		{
			return false;
		}
		/*-------------------------------------------------------
		 * Dialog Meldungen
		 * -------------------------------------------------------*/	
		if(LR.ReadBereich("LMeldungen"))
		{
		PV.LMeldungen = new String[PV.langText.length];
		System.arraycopy(PV.langText,0, PV.LMeldungen, 0, PV.langText.length);
		}
		else
		{
			return false;
		}
		/*-------------------------------------------------------
		 * Beschriftungen von Dialogboxen
		 * -------------------------------------------------------*/
		if(LR.ReadBereich("LBeschriftungen"))
		{
		PV.LBeschriftungen = new String[PV.langText.length];
		System.arraycopy(PV.langText,0, PV.LBeschriftungen, 0, PV.langText.length);
		}
		else
		{
			return false;
		}
		/*-------------------------------------------------------
		 * Fehlermeldugen
		 * -------------------------------------------------------*/
		if(LR.ReadBereich("LFehlerMeldungen"))
		{
		PV.LFehlerMeldungen = new String[PV.langText.length];
		System.arraycopy(PV.langText,0, PV.LFehlerMeldungen, 0, PV.langText.length);
		}
		else
		{
			return false;
		}
		return true;
	}

  private boolean MakeFileChooser()
	{
		/*-------------------------------------------------------
		* Fileschoser aufbauen
		* -------------------------------------------------------*/
		int answer ;
	  	atUIManager.saveValues();
		 atUIManager.put("FileChooser.lookInLabelText", PV.LBeschriftungen[2]);
		 atUIManager.put("FileChooser.upFolderToolTipText", PV.LBeschriftungen[3]);
		 atUIManager.put("FileChooser.newFolderToolTipText", PV.LBeschriftungen[4]);
		 atUIManager.put("FileChooser.fileNameLabelText", PV.LBeschriftungen[5]);
		 atUIManager.put("FileChooser.filesOfTypeLabelText", PV.LBeschriftungen[6]);
		 atUIManager.put("FileChooser.cancelButtonText", PV.LBeschriftungen[25]);
		 atUIManager.put("FileChooser.cancelButtonToolTipText", PV.LBeschriftungen[8]);
		 atUIManager.put("FileChooser.detailsViewButtonToolTipText", PV.LBeschriftungen[9]);
		 atUIManager.put("FileChooser.listViewButtonToolTipText", PV.LBeschriftungen[10]);
		 
		 JFileChooser fcBatch=new JFileChooser();
		 fcBatch.setCurrentDirectory(new File(PV.batchdir));
		 fcBatch.addChoosableFileFilter(new lcFilter());
		 fcBatch.setFileHidingEnabled(true);
		 answer=fcBatch.showOpenDialog(this);
		 atUIManager.restoreValues();
		 try
		 {
			 switch (answer)
			 {
				 case JFileChooser.APPROVE_OPTION:
					 PV.BatchFile =fcBatch.getSelectedFile().getPath();
					 PV.batchdir=fcBatch.getSelectedFile().getParent();
					 break;
				 case JFileChooser.CANCEL_OPTION :
					 return true;
			 }
			 if (fcBatch.getSelectedFile().isFile())
			 {
				 PV.BatchFile =fcBatch.getSelectedFile().getPath();
				 //Batch File ausgewählt
				 PV.ml.writeLog('n',0,PV.LMeldungen[32],PV.BatchFile);
				 return true;
			 }
			 else
			 {
				 //%1  ist kein gültiger Dateiname
				 PV.ml.writeLog('m',0,PV.LMeldungen[33],PV.BatchFile);
				 return false;
			 }
		 }
  	 catch (RuntimeException e1)
		 {
  		 //"Fehler beim Auswählen des Batch-Files. Exception %1"
			 PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[26],new String[]{ e1.toString()});
			 return false;
		 }
   	 
	 }

/*  private void runBatch()
  {
  	BatchRun batch;
  	// Prüfen ob alles für batch vorbereitet
  	try
  	{
	  	if ((PV.BatchFile.length()>0 && PV.ReqVarNo>0 && PV.ResVarNo>0)==true)
	  	{
	  		System.out.println("OK");
	    	batch=new BatchRun(PV.BatchFile);
	    	batch.run(tUrl.getText());
	  	}
	  	else
	  	{
	  		//"Please select all Parameters"
	  		PV.ml.writeLog('m', 1, PV.LMeldungen[34]);
	  	}
  	}
  	catch(Exception e)
  	{
  		//Fehler beim %1-run. Exception : %2 
  		PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[27],new String[]{"Batch",e.toString()});
  	}
  }*/
  
  private void stopBatch()
  {
  	PV.stop=true;
  	System.out.println(PV.stop);
  }
 
  private void runBatch()
  {
		if (PV.IR.isoneUser())
		{
			PV.BatchUser=tUser.getText();
			PV.BatchPass=tPass.getText();
		}

  	PV.stop=false;
  	PV.Counter=0;
//  	BatchRun batch;
  	// Prüfen ob alles für batch vorbereitet
  	try
  	{
	  	if ((PV.BatchFile.length()>0 && PV.ReqVarNo>0 && PV.ResVarNo>0)==true)
	  	{
	  		TheBatch tb0=new TheBatch();
	  		tb0.setURL(tUrl.getText());
	  		bRunBatch.setVisible(false);
	  		bStopBatch.setVisible(true);
	  		tb0.setButton(bRunBatch,bStopBatch);
	  		tb0.start();
	  		// Batch gesendet
	  		PV.ml.writeLog('n', 1, PV.LMeldungen[38]);
	  	}
	  	else
	  	{
	  		//"Please select all Parameters"
	  		PV.ml.writeLog('m', 1, PV.LMeldungen[34]);
	  	}
  	}
  	catch(Exception e)
  	{
  		//Fehler beim %1-run. Exception : %2 
  		PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[27],new String[]{"Batch",e.toString()});
  	}
  }
  
/*  private void runVT()
  {
  	try
  	{
    	VTRun vt;
  		System.out.println("OK");
    	vt=new VTRun();
    	vt.setLogin(tUser.getText());
    	vt.setPass(tPass.getText());
    	vt.run(tUrl.getText());
  		System.out.println("runVT");
  	}
  	catch(Exception e)
  	{
  		//Fehler beim %1-run. Exception : %2 
  		PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[27],new String[]{"VT",e.toString()});
  	}
 }*/ 
  
  private void runVT()
  {
  	TheVT tv0=new TheVT();
  	tv0.setURL(tUrl.getText());
  	tv0.setUser(tUser.getText());
  	tv0.setPass(tPass.getText());
  	tv0.setButton(bRunVT);
  	tv0.start();
  	//VT gesendet
  	PV.ml.writeLog('n', 1, PV.LMeldungen[39]);
  }
  

  private void visibleTabsChanged(ChangeEvent evt) 
  {
  	try
  	{
//	  	if (jTabs.getSelectedIndex()==1)
if (jTabs.getTitleAt(jTabs.getSelectedIndex()).compareTo("run CSV")==0)
		  {
		  	this.lPass.setVisible(false);
		  	this.lUser.setVisible(false);
		  	this.tPass.setVisible(false);
		  	this.tUser.setVisible(false);
		  }
		  else
		  {
		  	this.lPass.setVisible(true);
		  	this.lUser.setVisible(true);
		  	this.tPass.setVisible(true);
		  	this.tUser.setVisible(true);
		  }
	  }
		catch(Exception e)
		{
			//Fehler beim Wechsel der Tabs zu Tab %1 Exception %2
			PV.ml.writeLog('e', 1, PV.LFehlerMeldungen[28],new String[]{String.valueOf(jTabs.getSelectedIndex()),e.toString()});
		}
  }
  

  

  
}

class lcFilter extends javax.swing.filechooser.FileFilter 
/*-------------------------------------------------------
* Filter für *.cfg für Filechooser erstellen
* -------------------------------------------------------*/
{
	public boolean accept(File file) 
	{
		String filename = file.getName();
		return filename.endsWith(".csv") || file.isDirectory();
	}
	public String getDescription() 
	{
		return "CSV";
	}
}

class swFilter extends javax.swing.filechooser.FileFilter 
/*-------------------------------------------------------
 * Filter für Sprachauswahl
 * -------------------------------------------------------*/
{
	public boolean accept(File file) 
	{
		String filename = file.getName();
		return filename.endsWith(".lang") && filename.length()==7;
	}
	public String getDescription() 
	{
		return PV.LBeschriftungen[13];
	}
}
