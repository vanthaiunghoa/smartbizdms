package atTools;

import javax.swing.JButton;
import javax.swing.ImageIcon;


public class atButton extends JButton
{

	/**
	 * Class creates Button with addapted Settings 
	 * size 25*25 /n
	 * contains no Text /n/r
	 * contains Image - 
	 * shows ToolTip
	 */
	private static final long serialVersionUID = -4298792112688119995L;

	/**
	 * @param ImageIcon - contains image 24x24 pixel as png
	 * @param ToolTip - 
	 * @info
	 * extends JButton <br>
	 * creates Button with addapted Settings: <br> 
   * size 25*25     -    contains no Text on Button <br> 
   * displays Image -    shows ToolTip
	 * @version 1.0
	 * @author Andreas Tritt
	 */
	public atButton(ImageIcon ImageIcon,String ToolTip)
	{
		super(ImageIcon);
		this.setToolTipText(ToolTip);
		this.setPreferredSize(new java.awt.Dimension(25, 25));
		this.setMinimumSize(new java.awt.Dimension(25, 25));
		this.setMaximumSize(new java.awt.Dimension(25, 25));
		this.setFont(new java.awt.Font("Andale Mono",0,8));
	}

}
