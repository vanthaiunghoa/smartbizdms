package atTools;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;


/**
 * 
 * @author Andreas Tritt
 *
 */
public class IniReader
{
//	private String User;
	private String filename;
	private String separator;
	private atTools.Logfile localml ;
	private boolean writelog;

	/* 
	 * ----------------------------
	 * Constructor IniReader  
	 * ----------------------------
	 */
	
	/**
	 * @param sdir: directory of ini-file
	 * @param mt - Logfile
	 * @info
	 * reads ini.file and stores values locally<br>
	 * writes in logifile
	 * Values are  LogDir, DB_Name, DB_Server,DB_User,DB_PW,Prg_User,Prg_PW
	 * @version 1.0
	 * @author Andreas Tritt
	 */
	public IniReader(String sdir,atTools.Logfile   mt)
	{
		localml=mt;
		writelog=true;
		InitReader(sdir);
	}
	
	/**
	 * @param sdir: directory of ini-file
	 * 
	 * @info
	 * reads ini.file and stores values locally<br>
	 * Values are  LogDir, DB_Name, DB_Server,DB_User,DB_PW,Prg_User,Prg_PW
	 * @version 1.0
	 * @author Andreas Tritt
	 */
	public IniReader(String sdir)
	{
		InitReader(sdir);
		writelog=false; // es gibt kein Logfile Object
	}

	private  void InitReader(String sdir)
	{
		this.separator = System.getProperties().getProperty("file.separator");
		File dir = new File(System.getProperties().getProperty("user.home")+ this.separator + sdir );
		if (!(dir.exists() && dir.isDirectory()))
		{
			dir.mkdir();
		}

		this.filename=System.getProperties().getProperty("user.home")+ this.separator + sdir + this.separator  +"conf.ini";
		File inifile = new File(this.filename);
		if (!(inifile.exists()))
		{
			try
			{
				inifile.createNewFile();
			}
			catch (IOException e)
			{
				this.hardExit=true;
				if (writelog)
				{
					localml.writeLog('e', 1, "ini-File konnte nicht angelegt werden");
					localml.writeLog('e', 1, e.toString());
				}
			}
		}
		if (this.lesen())
		{
			if (writelog)
			{
				localml.writeLog('n', 1, "IniReader wurde initialisiert");
			}
		}
		else
		{
			if (writelog)
			{
				localml.writeLog('e', 1, "Fehler beim Lesen der Ini-Datei");
			}
			this.hardExit=true;
		}

	}

/* 
 * ----------------------------
 * Directory für Logfile  
 * ----------------------------
 */
private String LogDir;
public String getLogDir()
{
	return LogDir;
}
public void setLogDir(String LogDir ){
	this.LogDir = LogDir;
}

/* 
 * ----------------------------
 * Datenbank Name  
 * ----------------------------
 */
private String DB_Name;
public String getDB_Name()
{
	return DB_Name;
}
public void setDB_Name(String DB_Name ){
	this.DB_Name = DB_Name;
}

/* 
 * ----------------------------
 *  Datenbank Server
 * ----------------------------
 */
private String DB_Server;
public String getDB_Server()
{
	return DB_Server;
}
public void setDB_Server(String DB_Server ){
	this.DB_Server = DB_Server;
}

/* 
 * ----------------------------
 *  Datenbank User
 * ----------------------------
 */
private String DB_User;
public String getDB_User()
{
	return DB_User;
}
public void setDB_User(String DB_User ){
	this.DB_User = DB_User;
}

/* 
 * ----------------------------
 *  Datenbank Passwort
 * ----------------------------
 */
private String DB_PW;
public String getDB_PW()
{
	return DB_PW;
}
public void setDB_PW(String DB_PW ){
	this.DB_PW = DB_PW;
}

/* 
 * ----------------------------
 *  Programm User
 * ----------------------------
 */
private String Prg_User;
public String getPrg_User()
{
	return Prg_User;
}
public void setPrg_User(String Prg_User ){
	this.Prg_User = Prg_User;
}

/* 
 * ----------------------------
 *  Programm Passwort
 * ----------------------------
 */
private String Prg_PW;
public String getPrg_PW()
{
	return Prg_PW;
}
public void setPrg_PW(String Prg_PW ){
	this.Prg_PW = Prg_PW;
}

private int Prg_Mode;
public int getPrg_Mode()
{
	return Prg_Mode;
}
public void setPrg_Mode(int Prg_Mode ){
	this.Prg_Mode = Prg_Mode;
}

/* 
 * ----------------------------
 * Fehler daher Hauptprogramm beenden
 * ----------------------------
 */
private boolean hardExit;
public boolean gethardExit()
{
	return hardExit;
}
public void sethardExit(boolean hardExit ){
	this.hardExit = hardExit;
}

/* 
 * ----------------------------
 * Einlesen der Daten aus der Konfigurations Datei 
 * ----------------------------
 */
/**
 * re-reads ini-file
 */
public boolean lesen(){
	boolean result =true;
	FileInputStream input;
	Properties props = new Properties();

	try
	{
	  input = new FileInputStream(filename);
	  props.load(input);
		this.LogDir = props.getProperty("LogDir","");
		this.DB_Name = props.getProperty("DB_Name","");
		this.DB_User = props.getProperty("DB_User","");
		this.DB_PW = props.getProperty("DB_PW","");
		this.DB_Server = props.getProperty("DB_Server","");
		this.Prg_User = props.getProperty("Prg_User","");
		this.Prg_PW = props.getProperty("Prg_PW","");
		this.Prg_Mode = Integer.parseInt(props.getProperty("Prg_Mode","0"));

		if (writelog)
		{
			localml.writeLog('n', 1, "Ini-Datei erfolgreich gelesen");
		}
	}
	catch (Exception d){
		 if (writelog)
		{
			localml.writeLog('e', 1, d.toString());
		}
		 else
		 {
			 System.out.println(d.toString());
		 }
		result=false;
	} 
	return result;
}

/* 
 * ----------------------------
 * Schreiben der Daten in die Konfiguration Datei 
 * ----------------------------
 */
/**
 * write ini-file on disk
 */
public boolean schreiben(){
	boolean result =true;
	 FileOutputStream output;
	 Properties props = new Properties();
  try
	{
		output = new FileOutputStream(filename);
		props.put("LogDir", this.LogDir);
		props.put("DB_Name", this.DB_Name);
		props.put("DB_User", this.DB_User);
		props.put("DB_Server", this.DB_Server);
		props.put("DB_PW", this.DB_PW);
		props.put("Prg_User",this.Prg_User);
		props.put("Prg_PW",this.Prg_PW);
		props.put("Prg_Mode",Integer.toString(this.Prg_Mode));
		
		localml.writeLog('e',1, "Passwort nicht in Ini Datei schreiben, wenn Programm fertig ist");
		props.store(output, "Config file fuer Besitz" );
		if (writelog)
		{
			localml.writeLog('n', 1, "Properties geschrieben");
		}

	}
	catch (Exception e)
	{
		localml.writeLog('n', 0, "e.toString()");
		 if (writelog)
		{
			localml.writeLog('e', 1, e.toString());
		}
		 else
		 {
			 System.out.println(e.toString());
		 }
		result=false;
	}
	return result;
}



}
