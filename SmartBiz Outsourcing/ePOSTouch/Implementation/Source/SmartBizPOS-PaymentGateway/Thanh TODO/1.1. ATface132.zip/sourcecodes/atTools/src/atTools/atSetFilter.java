package atTools;

public class atSetFilter
{
/**Will contain Dialog, and return in some way parameteres
 * 
 * 
 * @param ImageIcon - contains image 24x24 pixel as png
 * @param ToolTip - 
 * @info
 * extends JButton <br>
 * creates Button with addapted Settings: <br> 
 * size 25*25     -    contains no Text on Button <br> 
 * displays Image -    shows ToolTip
 * @version 1.0
 * @author Andreas Tritt
 */


	public atSetFilter(atTools.atSearchParam[] param){
	
	}


}
