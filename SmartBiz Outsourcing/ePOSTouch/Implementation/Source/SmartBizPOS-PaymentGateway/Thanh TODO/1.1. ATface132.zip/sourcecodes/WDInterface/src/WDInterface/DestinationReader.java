package WDInterface;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import WDInterface.PV;
import atTools.Strings;


/**
 * 
 * @author Andreas Tritt
 *
 */
public class DestinationReader
{
	private String filename;
	String cfile; // file das Konfiguration enthält
	private boolean writelog;

	
	public DestinationReader()
	{
		writelog=true;
		
	}
	
	public boolean readDest()
	{
		try
			{
			int max=0;
			String Area;
			//Start Destination Reader
			PV.ml.writeLog('n', 1, PV.LMeldungen[22]);
			max=readAnzahl();
			PV.destNr=max;
			PV.destName = new String[max+1];
	    PV.destHost = new String[max+1]; 
	    PV.destPort = new String[max+1];
	    PV.destPath = new String[max+1];
	    PV.destUser = new String[max+1];
	    PV.destPass = new String[max+1]; 
	    PV.destBC_SIG = new String[max+1];
	    PV.destDir=new String[max+1];
		  
	    for (int i=0;i<=max;i++) //initialisieren
	    {
	  		PV.destName[i]="";
	      PV.destHost[i]=""; 
	      PV.destPort[i]="";
	      PV.destPath[i]="";
	      PV.destUser[i]="";
	      PV.destPass [i]="";
	      PV.destBC_SIG[i]="";
	      PV.destDir[i]="";
	    	
	    }
	    
			for (int i=1;i<=max;i++)
			{
				Area="Area"+String.valueOf(i);
				readArea(Area,i);
			}
			
			
			return true;
		}
		catch(Exception e)
		{
			//Initialisierung DestinationReader fehlgeschlagen
			PV.ml.writeLog('m', 1, PV.LFehlerMeldungen[11]);
			return false;
		}
	}
	
	
	
	
	public int readAnzahl()
	{
		int Ergebnis=0;
		try 
		{
			cfile=PV.reqdir+PV.separator+"destinations.ini";
			BufferedReader in = new BufferedReader(new FileReader(cfile));
			String str;
			while (((str = in.readLine()) != null) && !str.contains("[Headers]"))// Bereich suchen
			{
			}
			while ((str = in.readLine()) != null) // jetzt die Werte einlesen
			{
					if (Strings.leftstring(str, 1).compareTo("[")==0) // hier beginnt ein neuer Bereich
					{
						break; // Alles eingelesen, verlassen
					}
					else
					{
							if (str.length()!=0)
							{
								if (Strings.leftstring(str, 7).compareTo("numbers")==0)
								{
									Ergebnis=Integer.parseInt(Strings.rightstring(str, str.length()-8));
								}
							}
					}
			}
			in.close();
			//Anzahl der Destinations = %1
			PV.ml.writeLog('n', 0, PV.LMeldungen[23],String.valueOf(Ergebnis ));
		} 
		catch (IOException e) 
		{
			//Fehler in ReqeustReader beim Einlesen aus Datei %1 für Bereich %2 Exception: %3
			PV.ml.writeLog('m', 1,  PV.LFehlerMeldungen[12],new String[]{cfile,"Headers einlesen",e.toString()});
			return Ergebnis;
		}
		
		return Ergebnis;
	}
	
	
	
	public int readArea(String Bereich, int index)
	{
		int Ergebnis=0;
		try 
		{
			cfile=PV.reqdir+PV.separator+"destinations.ini";
			BufferedReader in = new BufferedReader(new FileReader(cfile));
			String str;
			while (((str = in.readLine()) != null) && !str.contains("["+Bereich+"]"))// Bereich suchen
			{
			}
			while ((str = in.readLine()) != null) // jetzt die Werte einlesen
			{
					if (Strings.leftstring(str, 1).compareTo("[")==0) // hier beginnt ein neuer Bereich
					{
						break; // Alles eingelesen, verlassen
					}
					else
					{
							if (str.length()!=0)
							{
								if (Strings.leftstring(str, 4).compareTo("Name")==0)
								{
									PV.destName[index]=Strings.rightstring(str, str.length()-5);
								}
								if (Strings.leftstring(str, 4).compareTo("host")==0)
								{
									PV.destHost[index]=Strings.rightstring(str, str.length()-5);
								}
								if (Strings.leftstring(str, 4).compareTo("port")==0)
								{
									PV.destPort[index]=Strings.rightstring(str, str.length()-5);
								}
								if (Strings.leftstring(str, 4).compareTo("path")==0)
								{
									PV.destPath[index]=Strings.rightstring(str, str.length()-5);
								}
								if (Strings.leftstring(str, 4).compareTo("user")==0)
								{
									PV.destUser[index]=Strings.rightstring(str, str.length()-5);
								}
								if (Strings.leftstring(str, 4).compareTo("pass")==0)
								{
									PV.destPass[index]=Strings.rightstring(str, str.length()-5);
								}
								if (Strings.leftstring(str, 6).compareTo("BC_SIG")==0)
								{
									PV.destBC_SIG[index]=Strings.rightstring(str, str.length()-7);
								}
								if (Strings.leftstring(str, 3).compareTo("dir")==0)
								{
									PV.destDir[index]=Strings.rightstring(str, str.length()-4);
								}
							}
					}
			}
			in.close();
			PV.ml.writeLog('n', 0, "Name = "+PV.destName );
		} 
		catch (IOException e) 
		{
			//Fehler in ReqeustReader beim Einlesen aus Datei %1 für Bereich %2 Exception: %3
			PV.ml.writeLog('m', 1,  PV.LFehlerMeldungen[12],new String[]{cfile,"readArea",e.toString()});
			return Ergebnis;
		}
		
		return Ergebnis;
	}
	
	
	
	
	
	
	
	
	
	/**
	 * @param sdir: directory of ini-file
	 * @param mt - Logfile
	 * @info
	 * reads ini.file and stores values locally<br>
	 * writes in logifile
	 * Values are  LogDir, DB_Name, DB_Server,DB_User,DB_PW,Prg_User,Prg_PW
	 * @version 1.0
	 * @author Andreas Tritt
	 */
	public DestinationReader(String sdir,atTools.Logfile   mt)
	{
		/*----------------------------
		 * Constructor IniReader  
		 * ----------------------------*/
		writelog=true;
	}
	
	/**
	 * @param sdir: directory of ini-file
	 * 
	 * @info
	 * reads ini.file and stores values locally<br>
	 * Values are  LogDir, DB_Name, DB_Server,DB_User,DB_PW,Prg_User,Prg_PW
	 * @version 1.0
	 * @author Andreas Tritt
	 */

	
/* ----------------------------
 * Directory für Logfile  
 * ----------------------------*/
	private String LogDir;
	public String getLogDir()
	{
		return LogDir;
	}
	public void setLogDir(String LogDir ){
		this.LogDir = LogDir;
	}
	
	/* ----------------------------
	 * Sprache
	 * ----------------------------*/
	private String language;
	public String getlanguage()
	{
		return language;
	}
	public void setlanguage(String language)
	{
		this.language = language;
	}
	
	/* ----------------------------
	 * Programm Mode
	 * 0=development
	 * 1=live
	 * ----------------------------*/
	private int Prg_Mode;
	public int getPrg_Mode()
	{
		return Prg_Mode;
	}
	public void setPrg_Mode(int Prg_Mode ){
		this.Prg_Mode = Prg_Mode;
	}
	
	
	/* ----------------------------
	 * Fehler daher Hauptprogramm beenden
	 * ----------------------------*/
	private boolean hardExit;
	public boolean gethardExit()
	{
		return hardExit;
	}
	public void sethardExit(boolean hardExit ){
		this.hardExit = hardExit;
	}
	
	public boolean lesen()
	{
		/*----------------------------
		 * Einlesen der Daten aus der Konfigurations Datei 
		 * ----------------------------*/
		boolean result =true;
		FileInputStream input;
		Properties props = new Properties();
		try
		{
		  input = new FileInputStream(filename);
		  props.load(input);
			this.LogDir = props.getProperty("LogDir","");
			this.language = props.getProperty("Lang","");
			this.Prg_Mode = Integer.parseInt(props.getProperty("Prg_Mode","0"));
			if (writelog)
			{
				PV.ml.writeLog('n', 1, "Ini-Datei erfolgreich gelesen");
			}
		}
		catch (Exception d){
			if (writelog)
			{
				 //ini-File %1 konnte nicht geschrieben werden. Exception: %2
				PV.ml.writeLog('m', 1, PV.LFehlerMeldungen[9],new String[]{filename,d.toString()});
			}
			 else
			 {
				 //Keine Ausgabe ins Log möglich
				 System.out.println(Strings.mix(PV.LFehlerMeldungen[9], new String[]{filename,d.toString()}));
			 }
			result=false;
		} 
		return result;
	}
	
	public boolean schreiben()
	{
		/* ----------------------------
		 * Schreiben der Daten in die Konfiguration Datei 
		 * ---------------------------- */
	   boolean result =true;
		 FileOutputStream output;
		 Properties props = new Properties();
	  try
		{
			output = new FileOutputStream(filename);
			props.put("LogDir", this.LogDir);
			props.put("Lang", this.language);
			props.put("Prg_Mode",Integer.toString(this.Prg_Mode));
			props.store(output, "Config file fuer ATface" );
			if (writelog)
			{
				//Config-Datei erfolgreich geschrieben
				PV.ml.writeLog('n', 1, PV.LMeldungen[24]);
			}
		}
		catch (Exception e)
		{
			if (writelog)
			{
				PV.ml.writeLog('e', 1, e.toString());
			}
			 else
			 {
				 //Keine Ausgabe ins Log möglich
				 System.out.println(e.toString());
			 }
			result=false;
		}
		return result;
	}

	
}
