package atTools;

public class atSearchParam
{

	/*
 * (non-javadoc)
 */
public String field;
 
/**
 * Getter of the property <tt>field</tt>
 *
 * @return Returns the field.
 * 
 */
public String getField()
{
	return field;
}

/**
 * Setter of the property <tt>field</tt>
 *
 * @param field The field to set.
 *
 */
public void setField(String field ){
	this.field = field;
}

/*
 * (non-javadoc)
 */
public String value;
 
/**
 * Getter of the property <tt>value</tt>
 *
 * @return Returns the value.
 * 
 */
public String getValue()
{
	return value;
}

/**
 * Setter of the property <tt>value</tt>
 *
 * @param value The value to set.
 *
 */
public void setValue(String value ){
	this.value = value;
}

/*
 * (non-javadoc)
 */
public boolean method;
 
/**
 * Getter of the property <tt>method</tt>
 *
 * @return Returns the method.
 * 
 */
public boolean getMethod()
{
	return method;
}

/**
 * Setter of the property <tt>method</tt>
 *
 * @param method The method to set.
 *
 */
public void setMethod(boolean method ){
	this.method = method;
}


/*
 * (non-javadoc)
 */
public int comparetype;
 
/**
 * Getter of the property <tt>method</tt>
 *
 * @return Returns the method.
 * 
 */
public int getcomparetype()
{
	return comparetype;
}

/**
 * Setter of the property <tt>method</tt>
 *
 * @param method The method to set.
 *
 */
public void setcomparetype(int comparetype ){
	this.comparetype = comparetype;
}



/**
 * @param value - contains Value to be find in field
 * @param field - field of resultset in which value should be found
 * @param method - false: field contains value   
 * @param method - true: field is exactly value  
 * @param comparetype - -1: Wert ist kleiner als Feldinhalt   
 * @param comparetype -  0: Wert ist gleich Feldinhalt   
 * @param comparetype - +1: Wert ist groesser als Feldinhalt   
 * @info
 
 * @version 1.0
 * @author Andreas Tritt
 */
public atSearchParam(String value,String field,boolean method,int comparetype)
{
	this.field=field;
	this.value=value;
	this.method=method;
	this.comparetype = comparetype;
}

}
