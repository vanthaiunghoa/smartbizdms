package atTools;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;
import java.util.*;


public class atTableModel extends DefaultTableModel implements TableModel
{
  
    /**
	 * 
	 */
	private static final long serialVersionUID = 1757871168167341098L;
	private int sortcol=0;
	private int order=1;

	/**
	 * @param rowData
	 * @param headers
	 * @info
	 * extends DefaultTableMOdel <br>
	 * creates TableModel with header, but without data <br>
	 * contains function sort-by-click-on-header  
	 * @version 1.0
	 * @author Andreas Tritt
	 */
		public atTableModel(Object[][] rowData, Object[] headers) 
		{
      super(rowData, headers);
    }

		/**
		 * @param clm: Spaltennummer
		 * contains function sort-by-click-on-header 
		 */
    @SuppressWarnings("unchecked")
		public void sortByColumn(final int clm) {
    	if (sortcol==clm)
    	{
    		order*=-1;
    	}
    	else
    	{
    		order=1;
    		sortcol=clm;
    	}
        Collections.sort(this.dataVector, new Comparator() {
            public int compare(Object o1, Object o2) {
                Vector v1 = (Vector) o1;
                Vector v2 = (Vector) o2;

                int size1 = v1.size();
                if (clm >= size1)
                    throw new IllegalArgumentException("max column idx: "+ size1);
                
               try
                {
                	Integer i1= (Integer) v1.get(clm);
                	Integer i2= (Integer) v2.get(clm);
                  return i1.compareTo(i2)*order;
                }
                catch (Exception e) // zu sortierende Spalte war nicht Integer
                {
	                try
	                {
	                	String s1 = (String) v1.get(clm);
	                	s1=s1.toUpperCase();
		                String s2 = (String) v2.get(clm);
	                	s2=s2.toUpperCase();
		                return s1.compareTo(s2)*order;
	                }
	                catch (Exception f) // zu sortierende Spalte war nicht String
	                {
	                	try
	                	{
		                	Date d1 = (Date) v1.get(clm);
		                	Date d2 = (Date) v2.get(clm);
		                	return d1.compareTo(d2)*order;
	                	}
	                	catch (Exception g) // zu sortierende Spalte war nicht Date
	                	{
	                		try
	                		{
	                			Float d1 = Float.valueOf(v1.get(clm).toString());
	                			Float d2 =Float.valueOf(v2.get(clm).toString());
	                			return d1.compareTo(d2)*order;
	                		}
		                	catch (Exception h) // zu sortierende Spalte war nicht Date
		                	{
		                	  System.out.println("weitere Datentypen in Sortierroutine einbauen");
		                	  return 0;
		                	}
	                	}
	                }
                }
            }
        });
    }
}
