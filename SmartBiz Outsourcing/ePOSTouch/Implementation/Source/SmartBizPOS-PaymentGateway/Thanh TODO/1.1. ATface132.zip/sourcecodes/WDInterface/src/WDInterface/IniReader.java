package WDInterface;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import atTools.Strings;


/**
 * 
 * @author Andreas Tritt
 *
 */
public class IniReader
{
	private String filename;
//	private atTools.Logfile localml ;
	private boolean writelog;

	
	/**
	 * @param sdir: directory of ini-file
	 * @param mt - Logfile
	 * @info
	 * reads ini.file and stores values locally<br>
	 * writes in logifile
	 * @version 1.0
	 * @author Andreas Tritt
	 */
	public IniReader(String sdir,atTools.Logfile   mt)
	{
		/*----------------------------
		 * Constructor IniReader  
		 * ----------------------------*/
		writelog=true;
	}
	
	/**
	 * @param sdir: directory of ini-file
	 * 
	 * @info
	 * reads ini.file and stores values locally<br>
	 * Values are  LogDir, DB_Name, DB_Server,DB_User,DB_PW,Prg_User,Prg_PW
	 * @version 1.0
	 * @author Andreas Tritt
	 */

	public  boolean ReadIni(String sdir)
	{
/*-------------------------------------------------------
* Ini file lesen
* -------------------------------------------------------*/
		File dir = new File(PV.prgdir);
		if (!(dir.exists() && dir.isDirectory()))
		{
			dir.mkdir();
		}
		this.filename=sdir+PV.separator+"conf.ini";
		File inifile = new File(this.filename);
		if (!(inifile.exists()))
		{
			try
			{
				inifile.createNewFile();
			}
			catch (IOException e)
			{
				this.hardExit=true;
				if (writelog)
				{
					//ini-File %1 konnte nicht angelegt werden. Exception: %2
					PV.ml.writeLog('e', 1, "ini-File %1 konnte nicht angelegt werden. Exception: %2",new String[]{sdir,e.toString()});
					return false;
				}
			}
		}
		if (this.lesen())
		{
			if (writelog)
			{
				PV.ml.writeLog('n', 1, "IniReader wurde initialisiert");
			}
		}
		else
		{
			if (writelog)
			{
				PV.ml.writeLog('e', 1, "Fehler beim Lesen der Ini-Datei");
				return false;
			}
			this.hardExit=true;
		}
		return true;
	}

/* ----------------------------
 * Directory für Logfile  
 * ----------------------------*/
	private String LogDir;
	public String getLogDir()
	{
		return LogDir;
	}
	public void setLogDir(String LogDir ){
		this.LogDir = LogDir;
	}
	
	/* ----------------------------
	 * Sprache
	 * ----------------------------*/
	private String language;
	public String getlanguage()
	{
		return language;
	}
	public void setlanguage(String language)
	{
		this.language = language;
	}
	
	/* ----------------------------
	 * Programm Mode
	 * 0=development
	 * 1=live
	 * ----------------------------*/
	private int Prg_Mode;
	public int getPrg_Mode()
	{
		return Prg_Mode;
	}
	
	public void setPrg_Mode(int Prg_Mode ){
		this.Prg_Mode = Prg_Mode;
	}
	
	private String ReqDir;
	public String getReqDir()
	{
		return ReqDir;
	}

	private String LangDir;
	public String getLangDir()
	{
		return LangDir;
	}
	public void setLangDir(String LangDir)
	{
		this.LangDir=LangDir;
	}
	
	private String BatchDir;
	public String getBatchDir()
	{
		return BatchDir;
	}
	public void setBatchDir(String batchDir)
	{
		BatchDir = batchDir;
	}

	private int UpdateV;
	public int getUpdateV()
	{
		return UpdateV;
	}
	public void setUpdateV(int uV)
	{
		this.UpdateV=uV;
	}

	private boolean ViewRequest;
	public boolean isViewRequest()
	{
		return ViewRequest;
	}
	public void setViewRequest(boolean viewRequest)
	{
		ViewRequest = viewRequest;
	}

	private boolean ViewBatch;
	public boolean isViewBatch()
	{
		return ViewBatch;
	}
	public void setViewBatch(boolean viewBatch)
	{
		ViewBatch = viewBatch;
	}

	private boolean ViewVT;
	public boolean isViewVT()
	{
		return ViewVT;
	}
	public void setViewVT(boolean viewVT)
	{
		ViewVT = viewVT;
	}
	
	public boolean oneUser;
	public boolean isoneUser()
	{
		return this.oneUser;
	}
	public void oneUser(boolean oneUser)
	{
		this.oneUser = oneUser;
	}
	
	
	/* ----------------------------
	 * Fehler daher Hauptprogramm beenden
	 * ----------------------------*/
	private boolean hardExit;
	public boolean gethardExit()
	{
		return hardExit;
	}
	public void sethardExit(boolean hardExit ){
		this.hardExit = hardExit;
	}
	
	public boolean lesen()
	{
		/*----------------------------
		 * Einlesen der Daten aus der Konfigurations Datei 
		 * ----------------------------*/
		boolean result =true;
		FileInputStream input;
		Properties props = new Properties();
		try
		{
		  input = new FileInputStream(filename);
		  props.load(input);
			this.LogDir = props.getProperty("LogDir","");
			this.ReqDir = props.getProperty("ReqDir","");
			this.LangDir=props.getProperty("LangDir","");
			this.BatchDir=props.getProperty("BatchDir","");
			this.ViewRequest=Boolean.parseBoolean(props.getProperty("ViewRequest","true"));
			
			this.ViewBatch=Boolean.parseBoolean(props.getProperty("ViewBatch","true"));
			this.ViewVT=Boolean.parseBoolean(props.getProperty("ViewVT","true"));
			this.UpdateV=Integer.parseInt(props.getProperty("UpdateV","0"));
			this.oneUser=Boolean.parseBoolean(props.getProperty("OneUser","false"));
			System.out.println(this.UpdateV);
			if (this.ReqDir.length()>2)
			{
				// anderes Verzeichnis
				PV.reqdir=this.ReqDir;
			}
			if (this.LangDir.length()>2)
			{
				// anderes Verzeichnis
				PV.langdir=this.LangDir;
			}
			
//			System.out.println("X"+this.ReqDir);
			this.language = props.getProperty("Lang","");
			this.Prg_Mode = Integer.parseInt(props.getProperty("Prg_Mode","0"));
			if (writelog)
			{
				PV.ml.writeLog('n', 1, "Ini-Datei erfolgreich gelesen");
			}
			
//			schreiben();
		}
		catch (Exception d){
			if (writelog)
			{
				 //noch keine Sprache geladen
				PV.ml.writeLog('m', 1, "ini-File %1 konnte nicht geschrieben werden. Exception: %2",new String[]{filename,d.toString()});
			}
			 else
			 {
				 //noch keine Sprache geladen
				 //Keine Ausgabe ins Log möglich
				 System.out.println(Strings.mix("ini-File %1 konnte nicht geschrieben werden. Exception: %2", new String[]{filename,d.toString()}));
			 }
			result=false;
		} 
		return result;
	}
	
	public boolean schreiben()
	{
		/* ----------------------------
		 * Schreiben der Daten in die Konfiguration Datei 
		 * ---------------------------- */
	   boolean result =true;
		 FileOutputStream output;
		 Properties props = new Properties();
	  try
		{
			output = new FileOutputStream(filename);
			props.put("LogDir", this.LogDir);
			props.put("Lang", this.language);
			props.put("Prg_Mode",Integer.toString(this.Prg_Mode));
			props.put("ReqDir",this.ReqDir);
			props.put("LangDir",this.LangDir);
			props.put("BatchDir",this.BatchDir);
			props.put("ViewRequest",Boolean.toString(this.ViewRequest));
			props.put("ViewBatch",Boolean.toString(this.ViewBatch));
			props.put("ViewVT",Boolean.toString(this.ViewVT));
			props.put("OneUser",Boolean.toString(this.oneUser));
			props.put("UpdateV", String.valueOf(this.UpdateV));
			props.store(output, "Config file fuer ATface" );
			if (writelog)
			{
				//Ini-Datei erfolgreich geschrieben
				PV.ml.writeLog('n', 1, PV.LMeldungen[19]);
			}
		}
		catch (Exception e)
		{
			if (writelog)
			{
				PV.ml.writeLog('e', 1, e.toString());
			}
			 else
			 {
				 //Keine Ausgabe ins Log möglich
				 System.out.println(e.toString());
			 }
			result=false;
		}
		return result;
	}



	
}
