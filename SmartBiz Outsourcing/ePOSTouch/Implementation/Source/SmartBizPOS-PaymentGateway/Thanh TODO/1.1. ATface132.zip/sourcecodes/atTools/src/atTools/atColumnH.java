package atTools;

public class atColumnH
{
/**
 * Column Header for table
 */
public String header; 

/**
 * Column Width for table
 */
public int width;

/**
 * Column No in Table, starting with 0
 */
public int position;

/**
 * result set field displayed in Column for table
 */
public String field;

/**
 * TabPosition of Field in Input Aera
 */
public int tabNr;

/**
 * label of Field in Input Aera
 */
public String label;

/**
 * Typ of InputField<br>
 * Str = String <br>
 * Int = Integer<br>
 * CmB = ComboBox<br>
 * Bol = Boolean<br>
 * TxP = TextPane<br>
 * Prc = Price<br>
 */
public String type;

/**
 * PosX Column No in GridBag of Input area
 */
public int PosX;

/**
 * PosY Row No in GridBag of Input area
 */
public int PosY;

/**
 * Resultset aus dem Comboboxen gefüllt werden
 */
public atCmbValue[] rs;

/**
 * is entry editable
 */
public boolean editable;

/**
 * @param Position - Column No in Table, starting with 0
 * @param Header - Header of this Column
 * @param Width - Width of this Column
 * @param Field - Name of field from resultset, containing data to be displayed in this Column
 * @param tabNr - TabPosition of connected Field in Input Area 
 * @param lable - label of Field in Input Area
 * @param type - Typ of InputField<br> 
 * Str = String<br>
 * Int = Integer<br>
 * CmB = ComboBox<br>
 * Bol = Boolean<br>
 * Prc = Price<br>
 * Dat = Date<br>
 * @param PosX - Column No in GridBag of Input area
 * @param PosY - Row No in GridBag of Input area
 * @param rs - resultset to fill Comboboxes
 * @param editable - is entry editable
 * 
 * @info
 * Constructor of atColumnG
 * creates object to contain information about TableModel
 * array of atColumn or atColumnF is needed for atTable
 * @version 1.0
 * @author Andreas Tritt
 */
public void InfoAboutClass()
{
	
}

public atColumnH(int Position, String Header, int Width, String Field,
		int tabNr, String lable, String type,int PosX, int PosY,atCmbValue[] rs, boolean editable){
	this.header=Header;
	this.width=Width;
	this.position=Position;
	this.field=Field;
	this.tabNr=tabNr;
	this.label=lable;
	this.type=type;
	this.PosX=PosX;
	this.PosY=PosY;
	this.rs=rs;
	this.editable=editable;
}


}
